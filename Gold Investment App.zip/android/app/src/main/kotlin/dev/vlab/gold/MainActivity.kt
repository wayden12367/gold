package dev.vlab.gold

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
