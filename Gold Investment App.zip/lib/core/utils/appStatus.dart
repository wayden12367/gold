// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';

class AppStatus {
  static const String PENDING = "0";
  static const String APPROVE = "1";
  static const String TYPE_AMOUNT = "1";
  static const String TYPE_GRAM = "2";

  static const String PAYMENT_INITIATE = "0";
  static const String PAYMENT_SUCCESS = "1";
  static const String PAYMENT_PENDING = "2";
  static const String PAYMENT_REJECT = "3";

  static const String TICKET_OPEN = "0";
  static const String TICKET_ANSWER = "1";
  static const String TICKET_REPLY = "2";
  static const String TICKET_CLOSE = "3";

  static const String PRIORITY_LOW = "1";
  static const String PRIORITY_MEDIUM = "2";
  static const String PRIORITY_HIGH = "3";

  static const String USER_ACTIVE = "1";
  static const String USER_BAN = "0";

  static const String KYC_UNVERIFIED = "0";
  static const String KYC_PENDING = "2";
  static const String KYC_VERIFIED = "1";

  // Redeem
  static const String REDEEM_STATUS_PROCESSING = "1";
  static const String REDEEM_STATUS_SHIPPED = "2";
  static const String REDEEM_STATUS_DELIVERED = "3";
  static const String REDEEM_STATUS_CANCELLED = "4";

  static String getRedeemStatus(String status) {
    if (status == REDEEM_STATUS_PROCESSING) {
      return MyStrings.processing;
    } else if (status == REDEEM_STATUS_SHIPPED) {
      return MyStrings.shipped;
    } else if (status == REDEEM_STATUS_DELIVERED) {
      return MyStrings.delivered;
    } else if (status == REDEEM_STATUS_CANCELLED) {
      return MyStrings.cancelled;
    }
    return '';
  }

  static Color getRedeemStatusColor(String status) {
    if (status == REDEEM_STATUS_PROCESSING) {
      return MyColor.pendingColor;
    } else if (status == REDEEM_STATUS_SHIPPED) {
      return Colors.blueAccent;
    } else if (status == REDEEM_STATUS_DELIVERED) {
      return Colors.green;
    } else if (status == REDEEM_STATUS_CANCELLED) {
      return MyColor.colorRed;
    }
    return MyColor.primaryColor;
  }

//
  static String getDepositStatus(String status) {
    if (status == PAYMENT_INITIATE) {
      return MyStrings.initiated;
    } else if (status == PAYMENT_SUCCESS) {
      return MyStrings.succeed;
    } else if (status == PAYMENT_PENDING) {
      return MyStrings.pending;
    } else if (status == PAYMENT_REJECT) {
      return MyStrings.rejected;
    }
    return '';
  }

  static Color getDepositStatusColor(String status) {
    if (status == PAYMENT_INITIATE) {
      return MyColor.highPriorityPurpleColor;
    } else if (status == PAYMENT_SUCCESS) {
      return MyColor.greenSuccessColor;
    } else if (status == PAYMENT_PENDING) {
      return MyColor.pendingColor;
    } else if (status == PAYMENT_REJECT) {
      return MyColor.colorRed;
    }
    return MyColor.colorRed;
  }
}
