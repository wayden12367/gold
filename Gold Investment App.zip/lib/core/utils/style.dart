import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';

TextStyle lightDefault = TextStyle(fontFamily: 'Poppins', color: MyColor.textColor, fontWeight: FontWeight.w300, fontSize: Dimensions.fontDefault);

const TextStyle regularDefault = TextStyle(fontFamily: 'Poppins', color: MyColor.textColor, fontWeight: FontWeight.w400, fontSize: Dimensions.fontDefault);

TextStyle mediumDefault = TextStyle(fontFamily: 'Poppins', color: MyColor.textColor, fontWeight: FontWeight.w500, fontSize: Dimensions.fontDefault);

TextStyle semiBoldDefault = TextStyle(fontFamily: 'Poppins', color: MyColor.textColor, fontWeight: FontWeight.w600, fontSize: Dimensions.fontDefault);

TextStyle boldDefault = TextStyle(fontFamily: 'Inter', color: MyColor.textColor, fontWeight: FontWeight.w700, fontSize: Dimensions.fontDefault);

TextStyle title = TextStyle(fontFamily: 'Poppins', color: MyColor.textColor, fontWeight: FontWeight.w700, fontSize: Dimensions.fontOverLarge, letterSpacing: .9);
