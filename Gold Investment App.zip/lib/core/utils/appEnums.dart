enum GradientIntensity { accent, soft, medium, hard }
