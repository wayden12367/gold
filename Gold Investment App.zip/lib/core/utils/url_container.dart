class UrlContainer {
  static const String domainUrl = 'https://script.viserlab.com/visergold';
  static const String baseUrl = '$domainUrl/api/';

  static const String socialLoginEndPoint = 'social-login';
  static const String onBoardEndPoint = 'onboarding';
  static const String depositHistoryUrl = 'deposit/history';
  static const String depositMethodUrl = 'deposit/methods';
  static const String depositInsertUrl = 'deposit/insert';

  static const String accountDisable = "delete-account";
  static const String notificationEndPoint = 'push-notifications';

  static const String registrationEndPoint = 'register';
  static const String loginEndPoint = 'login';
  static const String logoutUrl = 'logout';
  static const String forgetPasswordEndPoint = 'password/email';
  static const String passwordVerifyEndPoint = 'password/verify-code';
  static const String resetPasswordEndPoint = 'password/reset';
  static const String verify2FAUrl = 'verify-g2fa';

  static const String deviceTokenUrl = 'add-device-token';
  static const String otpVerify = 'otp-verify';
  static const String otpResend = 'otp-resend';

  static const String verifyEmailEndPoint = 'verify-email';
  static const String verifySmsEndPoint = 'verify-mobile';
  static const String resendVerifyCodeEndPoint = 'resend-verify/';
  static const String authorizationCodeEndPoint = 'authorization';

  static const String dashboard = 'dashboard';
  static const String transactionEndpoint = 'transactions';
  //buy gold
  static const String buyGoldForm = 'buy/form';
  static const String buyGoldStore = 'buy/save';
  static const String buyGoldHistory = 'buy/history';
  // sell gold
  static const String sellGoldHistory = 'sell/history';
  static const String sellGoldForm = 'sell/form';
  static const String sellGoldStore = 'sell/save';
  // gift gold
  static const String giftGoldForm = 'gift/form';
  static const String sendGift = 'gift/save';
  static const String giftGoldCheckRecipient = 'gift/check-recipient';
  static const String giftGoldHistory = 'gift/history';
  //redeem
  static const String redeemData = 'redeem/form';
  static const String redeemHistory = 'redeem/history';
  static const String redeem = 'redeem/save';

  //withdraw
  static const String addWithdrawRequestUrl = 'withdraw-request';
  static const String withdrawMethodUrl = 'withdraw-method';
  static const String withdrawRequestConfirm = 'withdraw-request/confirm';
  static const String withdrawHistoryUrl = 'withdraw/history';
  static const String withdrawStoreUrl = 'withdraw/store/';
  static const String withdrawConfirmScreenUrl = 'withdraw/preview/';

  static const String kycFormUrl = 'kyc-form';
  static const String kycSubmitUrl = 'kyc-submit';

  static const String generalSettingEndPoint = 'general-setting';

  static const String privacyPolicyEndPoint = 'policies';
  static const String getProfileEndPoint = 'user-info';
  static const String updateProfileEndPoint = 'profile-setting';
  static const String profileCompleteEndPoint = 'user-data-submit';

  static const String changePasswordEndPoint = 'change-password';
  static const String countryEndPoint = 'get-countries';

  static const String deviceTokenEndPoint = 'add-device-token';
  static const String languageUrl = 'language/';

  static const String twoFactor = "twofactor";
  static const String twoFactorEnable = "twofactor/enable";
  static const String twoFactorDisable = "twofactor/disable";

  static const String supportMethodsEndPoint = 'support/method';
  static const String supportListEndPoint = 'ticket';
  static const String storeSupportEndPoint = 'ticket/create';
  static const String supportViewEndPoint = 'ticket/view';
  static const String supportReplyEndPoint = 'ticket/reply';
  static const String supportCloseEndPoint = 'ticket/close';
  static const String supportDownloadEndPoint = 'ticket/download';
  static const String countryFlagImageLink = 'https://flagpedia.net/data/flags/h24/{countryCode}.webp';
  static const String faqEndPoint = 'faq';

  static const String supportImagePath = '$domainUrl/assets/support/';
  static const String withDrawImagePath = '$domainUrl/assets/images/withdraw_method/';

  //
  static const String downloadAttachmentsUrl = '${baseUrl}download-attachments';

  static const String onboardImageUrl = '$domainUrl/assets/images/frontend/app_onboarding';
}
