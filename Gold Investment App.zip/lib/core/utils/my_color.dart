import 'package:flutter/material.dart';

class MyColor {
  //Primary Color Pallet based on shades
  static const Color primaryColor = Color(0xffEAAE06);

  static const Color primaryColor50 = Color(0xffFEFBE8);
  static const Color primaryColor100 = Color(0xffFFF8C2);
  static const Color primaryColor200 = Color(0xffFFEE89);
  static const Color primaryColor300 = Color(0xffFFDE4D);
  static const Color primaryColor400 = Color(0xffFDB332);
  static const Color primaryColor500 = Color(0xffEAAE06);
  static const Color primaryColor600 = Color(0xffC88E02);
  static const Color primaryColor700 = Color(0xffA56E05);
  static const Color primaryColor800 = Color(0xff864A0D);
  static const Color primaryColor900 = Color(0xff723C11);
  static const Color primaryColor950 = Color(0xff4B2816);
  static const Color primaryColor960 = Color(0xFFFFB22C);
  static const Color systemNavBarColor = Color(0xff392F0B);

  // text
  static const Color textColor = Color(0xffF5F5F5);
  static const Color bodyTextColor = Color(0xffA3A3A3);

  // background
  static const Color backgroundColor = Color(0xff121212);
  static const Color shadowColor = Color(0xffF5F5F5);
  static const Color cardBgColor = Color(0xff171717);
  static const Color iconColor = Color(0xffA3A3A3);
  static const Color dropdownBgColor = Color(0xff232323);

  //status
  static const Color colorWhite = Color(0xffFFFFFF);
  static const Color colorBlack = Color(0xff262626);
  static const Color colorGreen = Color(0xff35C75A);
  static const Color colorRed = Color(0xFFF6465D);
  static const Color colorGrey = Colors.grey;
  static const Color transparentColor = Colors.transparent;
  static const Color borderColor = Color(0xff404040);

  //support
  static const Color greenSuccessColor = Color(0xFF35C75A);
  static const Color redCancelTextColor = Color(0xFFF93E2C);
  static const Color highPriorityPurpleColor = Color(0xFF7367F0);
  static const Color pendingColor = Colors.orange;

  // symbol plate
  static List<Color> symbolPlate = [
    const Color(0xffDE3163),
    const Color(0xffC70039),
    const Color(0xff900C3F),
    const Color(0xff581845),
    const Color(0xffFF7F50),
    const Color(0xffFF5733),
    const Color(0xff6495ED),
    const Color(0xffCD5C5C),
    const Color(0xffF08080),
    const Color(0xffFA8072),
    const Color(0xffE9967A),
    const Color(0xff9FE2BF),
  ];

  static getSymbolColor(int index) {
    int colorIndex = index > 10 ? index % 10 : index;
    return symbolPlate[colorIndex];
  }

  static getPrimaryColor() {
    return primaryColor;
  }

  static Gradient gradientBorder = LinearGradient(
    colors: [
      primaryColor300.withValues(alpha: 0.80),
      primaryColor100.withValues(alpha: 0.80),
    ],
    transform: GradientRotation(180),
  );
  static Gradient gradientBorder2 = LinearGradient(
    colors: [primaryColor300, primaryColor960],
    transform: GradientRotation(180),
  );
  static Gradient bgGradient = LinearGradient(
    colors: [
      Color(0xFFFFDE4D).withValues(alpha: 0.15),
      MyColor.primaryColor960.withValues(alpha: 0.15),
    ],
    transform: GradientRotation(180),
  );
  static Gradient textGradient = LinearGradient(
    colors: [
      primaryColor300,
      primaryColor960,
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    transform: GradientRotation(180),
  );
}
