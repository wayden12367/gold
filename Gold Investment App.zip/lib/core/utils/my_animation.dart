class MyAnimation {
  static const String noData = "assets/animation/no-data.json";
  static const String email = "assets/animation/email.json";
  static const String sms = "assets/animation/sms.json";
  static const String time = "assets/animation/time.json";
  static const String support = "assets/animation/support.json";
}
