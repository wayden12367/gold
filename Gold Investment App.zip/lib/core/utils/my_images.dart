class MyImages {
  static const String appLogo = "assets/images/logo/appLogo.png";
  static const String google = "assets/images/social/google.png";
  static const String facebook = "assets/images/social/facebook.png";
  static const String apple = "assets/images/social/apple.png";
  static const String linkedin = "assets/images/social/linkedin.png";
  static const String userdeleteImage = "assets/images/userdeleteImage.png";

  static const String menuPortfolio = "assets/images/menu/portfolio.svg";
  static const String menuTransaction = "assets/images/menu/transaction.svg";
  static const String menuMenu = "assets/images/menu/menu.svg";
  static const String home = "assets/images/menu/home.svg";

  static const String successBg = "assets/images/success_bg.png";
  static const String gift = "assets/images/gift.png";
  static const String coin = "assets/images/coin.png";
  static const String coinBag = "assets/images/coinbag.png";
  static const String car = "assets/images/car.png";
  static const String goldBar = "assets/images/gold_bar.png";
  static const String appBarBg = "assets/images/app_bar_bg.png";
  static const String bgShape = "assets/images/bgShape.png";
  static const String arrowRight = "assets/images/arrow_right.png";
  static const String faceLock = "assets/images/face_lock.svg";
  static const String lock = "assets/images/lock.svg";
  static const String back = "assets/images/back.svg";
  static const String authBG = "assets/images/auth_bg.jpeg";
  static const String bgSwipe = "assets/images/bg_swipe.jpeg";
  static const String qrCode = "assets/images/qr_code.svg";
  static const String user = "assets/images/user.png";
  static const String list = "assets/images/list.svg";
  static const String wallet = "assets/images/wallet.svg";

  static const String add = "assets/images/add.svg";
  static const String remove = "assets/images/remove.svg";
  static const String history = "assets/images/history.png";

  static const String menuKyc = "assets/icons/menu_kyc.svg";
  static const String menuUser = "assets/icons/menu_user.svg";
  static const String menuLock = "assets/icons/menu_lock.svg";
  static const String menu2fa = "assets/icons/menu_2fa.svg";
  static const String menuNotification = "assets/icons/menu_notification.svg";
  static const String menuDepositHistoryIcon = "assets/icons/menu_deposit_history.svg";
  static const String menuWithdrawHistoryIcon = "assets/icons/menu_withdraw_history.svg";
  static const String menuTransactionIcon = "assets/icons/menu_transaction.svg";
  static const String menuLanguageIcon = "assets/icons/menu_language.svg";
  static const String menuFaqIcon = "assets/icons/menu_faq.svg";
  static const String menuSupportTicketIcon = "assets/icons/menu_support_ticket.svg";
  static const String menuPrivacyPolicyIcon = "assets/icons/menu_policies.svg";
  static const String menuLogoutIcon = "assets/icons/menu_logout.svg";
  static const String kycPendingIcon = "assets/icons/kyc_pending.svg";
  static const String kycVerifiedIcon = "assets/icons/kyc_verified.svg";
}
