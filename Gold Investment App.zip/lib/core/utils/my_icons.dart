class MyIcons {
  static const String pdfFile = "assets/icons/pdf.svg";
  static const String file = "assets/icons/folder.svg";
  static const String doc = "assets/icons/doc.svg";
  static const String xlsx = "assets/icons/xlsx.svg";
}
//attention: add your .svg icons here 
 