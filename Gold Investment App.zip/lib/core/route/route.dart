import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/services/push_notification_service.dart';
import 'package:viser_gold/view/components/preview_image.dart';
import 'package:viser_gold/view/screens/auth/authentication_screen.dart';
import 'package:viser_gold/view/screens/auth/email_verification/email_verification_screen.dart';
import 'package:viser_gold/view/screens/auth/forget_password/forget_password/forget_password_screen.dart';
import 'package:viser_gold/view/screens/auth/forget_password/reset_password/reset_password_screen.dart';
import 'package:viser_gold/view/screens/auth/forget_password/verify_forget_password/verify_forgot_screen.dart';
import 'package:viser_gold/view/screens/auth/kyc/kyc_verification_screen.dart';
import 'package:viser_gold/view/screens/auth/profile_complete/profile_complete_screen.dart';
import 'package:viser_gold/view/screens/auth/sms_verification/sms_verification_screen.dart';
import 'package:viser_gold/view/screens/auth/two_factor_screen/two_factor_setup_screen.dart';
import 'package:viser_gold/view/screens/auth/two_factor_screen/two_factor_verification_screen.dart';
import 'package:viser_gold/view/screens/buy_screens/buy_gold_history_screen.dart';
import 'package:viser_gold/view/screens/buy_screens/buy_gold_screen.dart';
import 'package:viser_gold/view/screens/buy_screens/buy_gold_success_screen.dart';
import 'package:viser_gold/view/screens/change_password_screen/change_password_screen.dart';
import 'package:viser_gold/view/screens/components_preview/components_preview_screen.dart';
import 'package:viser_gold/view/screens/dashboard/dashboard_screen.dart';
import 'package:viser_gold/view/screens/dashboard/transaction/transaction_screen.dart';
import 'package:viser_gold/view/screens/deposit/deposit_history_screen.dart';
import 'package:viser_gold/view/screens/deposit/new_deposit_screen.dart';
import 'package:viser_gold/view/screens/faq/faq_screen.dart';
import 'package:viser_gold/view/screens/gift_screen/gift_gold_screen.dart';
import 'package:viser_gold/view/screens/gift_screen/gift_history_screen.dart';
import 'package:viser_gold/view/screens/language/language_screen.dart';
import 'package:viser_gold/view/screens/my_qr/my_qr_code_screen.dart';
import 'package:viser_gold/view/screens/my_qr/qr_code_scanner.dart';
import 'package:viser_gold/view/screens/notification/notification_screen.dart';
import 'package:viser_gold/view/screens/onboard_screen/onboard_screen.dart';
import 'package:viser_gold/view/screens/privacy_policy/privacy_policy_screen.dart';
import 'package:viser_gold/view/screens/profile/edit_profile_screen.dart';
import 'package:viser_gold/view/screens/profile/profile_screen.dart';
import 'package:viser_gold/view/screens/redeem/history/redeem_history_screen.dart';
import 'package:viser_gold/view/screens/redeem/redeem_screen.dart';
import 'package:viser_gold/view/screens/sell_screens/sell_gold_history_screen.dart';
import 'package:viser_gold/view/screens/sell_screens/sell_gold_success_screen.dart';
import 'package:viser_gold/view/screens/sell_screens/sell_screens.dart';
import 'package:viser_gold/view/screens/splash_screen.dart';
import 'package:viser_gold/view/screens/support/new_ticket_screen.dart';
import 'package:viser_gold/view/screens/support/support_ticket_screen.dart';
import 'package:viser_gold/view/screens/support/ticket_details_screen.dart';
import 'package:viser_gold/view/screens/web_view_screen.dart';
import 'package:viser_gold/view/screens/withdraw/add_withdraw_screen/add_withdraw_screen.dart';
import 'package:viser_gold/view/screens/withdraw/confirm_withdraw_screen/confirm_withdraw_screen.dart';
import 'package:viser_gold/view/screens/withdraw/withdraw_history/withdraw_history_screen.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helper/shared_preference_helper.dart';

class RouteHelper {
  //use screen in screen name and route name
  static const String componentPreviewScreen = "/component_preview_screen"; //info: remove before production
  static const String splashScreen = "/splash_screen";
  static const String onboardScreen = "/onboard_screen";
//auth
  static const String authenticationScreen = "/authentication_screen";
  static const String forgetPasswordScreen = "/forget_password_screen";
  static const String verifyForgetPasswordScreen = "/verify_forget_password_screen";
  static const String resetPasswordScreen = "/reset_password_screen";
  static const String emailVerificationScreen = "/email_verification_screen";
  static const String smsVerificationScreen = "/sms_verification_screen";
  static const String kycVerificationScreen = "/kyc_verification_screen";
  static const String profileCompleteScreen = "/profile_complete_screen";
  static const String twoFactorSetupScreen = "/two_factor_setup_screen";
  static const String twoFactorVerificationScreen = "/two_factor_verification_screen";
  static const String profileScreen = "/profile_screen";
  static const String editProfileScreen = "/edit_profile_screen";
  static const String notificationScreen = "/notification_screen";
  static const String changePasswordScreen = "/change_password_screen";
  static const String privacyScreen = "/privacy_screen";
  static const String faqScreen = "/faq_screen";
  static const String languageScreen = "/language_screen";
  static const String webViewScreen = "/web_view_screen";
  static const String previewImageScreen = "/preview_image_screen";
//dashboard
  static const String transactionScreen = "/transaction_screen";
  static const String dashboardScreen = "/dashboard_screen";
  // deposit
  static const String newDepositScreen = "/deposit_screen";
  static const String depositHistoryScreen = "/deposit_history_screen";
  // withdraw
  static const String addWithdrawScreen = "/add_withdraw_screen";
  static const String confirmWithdrawScreen = "/confirm_withdraw_screen";
  static const String withdrawHistoryScreen = "/withdraw_history_screen";
// buy gold
  static const String buyGoldScreen = "/buy_gold_screen";
  static const String buyGoldSuccessScreen = "/buy_gold_success_screen";
  static const String buyGoldHistoryScreen = "/buy_gold_history_screen";
  // sell gold
  static const String sellGoldScreen = "/sell_gold_screen";
  static const String sellGoldHistoryScreen = "/sell_gold_history_screen";
  static const String sellGoldSuccessScreen = "/sell_gold_success_screen";
  // gift gold
  static const String giftGoldScreen = "/gift_gold_screen";
  static const String giftHistoryScreen = "/gift_history_screen";
  // redeem
  static const String redeemScreen = "/redeem_screen";
  static const String redeemHistoryScreen = "/redeem_history_screen";

  //
  static const String supportTicketScreen = "/support_ticket_screen";
  static const String newTicketScreen = "/new_ticket_screen";
  static const String ticketDetailScreen = "/ticket_detail_screen";

  //
  static const String myQrCodeScreen = "/my_qr_code_screen";
  static const String qrCodeScanner = "/qr_code_scanner_screen";
  //
  List<GetPage> routes = [
    GetPage(name: splashScreen, page: () => const SplashScreen()),
    GetPage(name: onboardScreen, page: () => const OnboardScreen()),
    GetPage(name: componentPreviewScreen, page: () => const ComponentPreviewScreen()),
    GetPage(name: authenticationScreen, page: () => const AuthenticationScreen()),
    GetPage(name: forgetPasswordScreen, page: () => const ForgetPasswordScreen()),
    GetPage(name: verifyForgetPasswordScreen, page: () => const VerifyForgetPassScreen()),
    GetPage(name: resetPasswordScreen, page: () => const ResetPasswordScreen()),
    GetPage(name: emailVerificationScreen, page: () => const EmailVerificationScreen()),
    GetPage(name: smsVerificationScreen, page: () => const SmsVerificationScreen()),
    GetPage(name: kycVerificationScreen, page: () => const KycVerificationScreen()),
    GetPage(name: profileCompleteScreen, page: () => const ProfileCompleteScreen()),
    GetPage(name: twoFactorSetupScreen, page: () => const TwoFactorSetupScreen()),
    GetPage(name: twoFactorVerificationScreen, page: () => const TwoFactorVerificationScreen()),
    GetPage(name: profileScreen, page: () => const ProfileScreen()),
    GetPage(name: editProfileScreen, page: () => const EditProfileScreen()),
    GetPage(name: changePasswordScreen, page: () => const ChangePasswordScreen()),
    GetPage(name: previewImageScreen, page: () => PreviewImage(url: Get.arguments)),
    GetPage(name: webViewScreen, page: () => WebViewScreen(url: Get.arguments)),
    GetPage(name: faqScreen, page: () => const FaqScreen()),
    GetPage(name: languageScreen, page: () => const LanguageScreen()),
    //
    GetPage(name: notificationScreen, page: () => const NotificationScreen()),
    GetPage(name: dashboardScreen, page: () => const DashboardScreen()),
    GetPage(name: transactionScreen, page: () => const TransactionScreen()),
    GetPage(name: privacyScreen, page: () => const PrivacyPolicyScreen()),
    // deposit
    GetPage(name: newDepositScreen, page: () => const NewDepositScreen()),
    GetPage(name: depositHistoryScreen, page: () => const DepositHistoryScreen()),
    // withdraw
    GetPage(name: addWithdrawScreen, page: () => const AddWithdrawScreen()),
    GetPage(name: confirmWithdrawScreen, page: () => const ConfirmWithdrawScreen()),
    GetPage(name: withdrawHistoryScreen, page: () => const WithdrawHistoryScreen()),

    // buy Gold
    GetPage(name: buyGoldScreen, page: () => const BuyGoldScreen()),
    GetPage(name: buyGoldSuccessScreen, page: () => const BuyGoldSuccessScreen()),
    GetPage(name: buyGoldHistoryScreen, page: () => const BuyGoldHistoryScreen()),
    // sell Gold
    GetPage(name: sellGoldScreen, page: () => const SellGoldScreen()),
    GetPage(name: sellGoldHistoryScreen, page: () => const SellGoldHistoryScreen()),
    GetPage(name: sellGoldSuccessScreen, page: () => const SellGoldSuccessScreen()),
    // gift Gold
    GetPage(name: giftGoldScreen, page: () => const GiftGoldScreen()),
    GetPage(name: giftHistoryScreen, page: () => const GiftHistoryScreen()),
    // redeem
    GetPage(name: redeemScreen, page: () => const RedeemScreen()),
    GetPage(name: redeemHistoryScreen, page: () => const RedeemHistoryScreen()),
    //
    GetPage(name: supportTicketScreen, page: () => const SupportTicketScreen()),
    GetPage(name: newTicketScreen, page: () => const NewTicketScreen()),
    GetPage(name: ticketDetailScreen, page: () => const TicketDetailsScreen()),
    //
    GetPage(name: myQrCodeScreen, page: () => const MyQrCodeScreen()),
    GetPage(name: qrCodeScanner, page: () => const QrCodeScannerScreen()),
  ];

  static Future<void> checkUserStatusAndGoToNextStep(GlobalUser? user, {bool isRemember = false, String accessToken = "", String tokenType = ""}) async {
    bool needEmailVerification = user?.ev == "1" ? false : true;
    bool needSmsVerification = user?.sv == '1' ? false : true;
    bool isTwoFactorEnable = user?.tv == '1' ? false : true;
    bool isKycVerificationEnable = user?.kv == '1' ? false : true;

    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    if (isRemember) {
      await sharedPreferences.setBool(SharedPreferenceHelper.rememberMeKey, true);
    } else {
      await sharedPreferences.setBool(SharedPreferenceHelper.rememberMeKey, false);
    }

    await sharedPreferences.setString(SharedPreferenceHelper.userIdKey, user?.id.toString() ?? '-1');
    await sharedPreferences.setString(SharedPreferenceHelper.userEmailKey, user?.email ?? '');
    await sharedPreferences.setString(SharedPreferenceHelper.userPhoneNumberKey, user?.mobile ?? '');
    await sharedPreferences.setString(SharedPreferenceHelper.userNameKey, user?.username ?? '');

    if (accessToken.isNotEmpty) {
      await sharedPreferences.setString(SharedPreferenceHelper.accessTokenKey, accessToken);
      await sharedPreferences.setString(SharedPreferenceHelper.accessTokenType, tokenType);
    }

    bool isProfileCompleteEnable = user?.profileComplete == '0' ? true : false;

    if (isProfileCompleteEnable) {
      Get.offAndToNamed(RouteHelper.profileCompleteScreen);
    } else if (needEmailVerification) {
      Get.offAndToNamed(RouteHelper.emailVerificationScreen);
    } else if (needSmsVerification) {
      Get.offAndToNamed(RouteHelper.smsVerificationScreen);
    } else if (isKycVerificationEnable) {
      Get.offAndToNamed(RouteHelper.kycVerificationScreen);
    } else if (isTwoFactorEnable) {
      Get.offAndToNamed(RouteHelper.twoFactorVerificationScreen);
    } else {
      PushNotificationService(apiClient: Get.find()).sendUserToken().then((v) {
        Get.offAndToNamed(RouteHelper.dashboardScreen);
      });
    }
  }
}
