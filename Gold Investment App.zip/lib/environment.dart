class Environment {
//info: ATTENTION Please update your desired data
  static const String appName = 'Viser Gold';
  static const String version = '1.0.0';

  static String defaultCurrency = "USD";
  static String defaultCurrencySymbol = "\$";

  static String defaultLangCode = "en";
  static String defaultLanguageName = "English";

  static String defaultPhoneCode = "1"; //don't use + here
  static String defaultCountryCode = "US";
  static int otpTime = 60;
}
