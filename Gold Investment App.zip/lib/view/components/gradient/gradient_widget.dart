import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:get/get.dart';

class GradientWidget extends StatelessWidget {
  final Widget child;
  final Gradient? gradient;
  const GradientWidget({super.key, required this.child, this.gradient});

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (rect) {
        return gradient?.createShader(rect) ??
            LinearGradient(
              colors: [MyColor.primaryColor, MyColor.primaryColor300],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(rect);
      },
      child: child,
    );
  }
}

class GradientText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final Gradient? gradient;
  const GradientText({super.key, required this.text, this.style, this.gradient});

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (rect) {
        return gradient?.createShader(rect) ??
            LinearGradient(
              colors: [MyColor.primaryColor, MyColor.primaryColor300],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ).createShader(rect);
      },
      child: Text(text.tr, style: style ?? boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
    );
  }
}
