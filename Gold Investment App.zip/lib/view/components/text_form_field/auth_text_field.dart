import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:get/get.dart';

class AuthTextField extends StatelessWidget {
  final String label;
  final String? hintText;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final TextEditingController controller;
  final FocusNode? focusNode;
  final bool isObscure;
  final ValueChanged<String> onChanged;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  const AuthTextField({super.key, required this.label, this.prefixIcon, this.suffixIcon, required this.controller, this.isObscure = false, required this.onChanged, this.keyboardType = TextInputType.text, this.textInputAction = TextInputAction.next, this.hintText = '', this.focusNode});

  @override
  Widget build(BuildContext context) {
    return CustomContainer(
      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10),
      radius: 16,
      color: MyColor.colorWhite.withValues(alpha: 0.04),
      border: Border.all(color: MyColor.borderColor, width: 1),
      child: Row(
        children: [
          if (prefixIcon != null) ...[
            prefixIcon!,
            SizedBox(width: Dimensions.space12),
          ],
          Expanded(
            child: TextFormField(
              controller: controller,
              focusNode: focusNode,
              onChanged: onChanged,
              obscureText: isObscure,
              textInputAction: textInputAction,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                hintText: hintText,
                hintStyle: regularDefault.copyWith(color: MyColor.bodyTextColor, fontSize: 12),
                labelStyle: regularDefault.copyWith(color: MyColor.bodyTextColor, fontSize: 12),
                labelText: label.tr,
                border: InputBorder.none,
                enabled: true,
              ),
              style: regularDefault.copyWith(fontSize: 17),
              cursorColor: MyColor.colorWhite,
              canRequestFocus: true,
              autofocus: true,
              enabled: true,
            ),
          ),
          if (suffixIcon != null) ...[
            SizedBox(width: Dimensions.space10),
            suffixIcon!,
          ],
        ],
      ),
    );
  }
}
