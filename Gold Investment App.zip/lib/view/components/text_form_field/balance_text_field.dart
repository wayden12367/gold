import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:get/get.dart';

class BalanceTextField extends StatefulWidget {
  final String label;
  final String? hintText, minText;
  final TextEditingController textEditingController;
  final FocusNode? focusNode;
  final Function(String) onChanged;
  final bool? isGramTextField;
  final Widget? minTextWidget;
  const BalanceTextField({
    super.key,
    required this.label,
    required this.hintText,
    required this.textEditingController,
    this.focusNode,
    required this.onChanged,
    this.minText,
    this.isGramTextField = false,
    this.minTextWidget,
  });

  @override
  State<BalanceTextField> createState() => _BalanceTextFieldState();
}

class _BalanceTextFieldState extends State<BalanceTextField> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: Dimensions.space30, horizontal: Dimensions.space16),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: MyColor.colorWhite.withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              IntrinsicWidth(
                child: TextFormField(
                  onChanged: widget.onChanged,
                  expands: false,
                  focusNode: widget.focusNode,
                  controller: widget.textEditingController,
                  scrollPadding: EdgeInsets.zero,
                  inputFormatters: [LengthLimitingTextInputFormatter(8)],
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: widget.hintText,
                    hintStyle: semiBoldDefault.copyWith(fontSize: 48, color: MyColor.bodyTextColor.withValues(alpha: 0.40)),
                  ),
                  style: semiBoldDefault.copyWith(fontSize: 48, color: MyColor.colorWhite),
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  selectionHeightStyle: BoxHeightStyle.includeLineSpacingTop,
                  keyboardType: TextInputType.number,
                  cursorColor: MyColor.bodyTextColor,
                  textAlign: TextAlign.center,
                  cursorRadius: Radius.zero,
                ),
              ),
              widget.minTextWidget ?? SizedBox.shrink(),
              widget.minText != null ? Text("${MyStrings.minimumPurchase.tr}: ${widget.minText}", style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)) : const SizedBox.shrink(),
            ],
          ),
        ),
        if (widget.isGramTextField == true) ...[
          Positioned(
            bottom: 10,
            right: 10,
            child: Text(widget.label.tr, style: semiBoldDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor)),
          )
        ] else ...[
          Positioned(
            top: 10,
            left: 10,
            child: Text(widget.label.tr, style: semiBoldDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor)),
          )
        ],
      ],
    );
  }
}
