import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/text/label_text.dart';

class CustomLabelTextFiled extends StatelessWidget {
  final String label;
  final String hintText;
  final String? instruction;
  final TextStyle? hintTextStyle;
  final TextStyle? textStyle;
  final TextStyle? labelStyle;
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final TextInputType keyboardType;
  final TextInputAction textInputAction;
  final FormFieldValidator? validator;
  final Function(String)? onChanged;
  final EdgeInsets? padding;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final VoidCallback? onTap;
  final VoidCallback? onSubmit;
  final bool enabled;
  final bool isReadOnly;
  final bool isShowLabel;
  final bool isRequired;
  final int? maxLines;
  final InputBorder? enabledBorder;
  final Color? fillColor, cursorColor;
  final TextAlign? textAlign;
  final List<TextInputFormatter>? inputFormatters;
  final BoxConstraints? prefixIconConstraints, suffixIconConstraints;

  const CustomLabelTextFiled({
    super.key,
    required this.label,
    this.hintText = "",
    this.instruction,
    this.hintTextStyle,
    this.textStyle,
    this.labelStyle,
    this.controller,
    this.focusNode,
    this.keyboardType = TextInputType.text,
    this.textInputAction = TextInputAction.next,
    this.validator,
    required this.onChanged,
    this.padding,
    this.suffixIcon,
    this.prefixIcon,
    this.onTap,
    this.enabled = true,
    this.onSubmit,
    this.isReadOnly = false,
    this.isShowLabel = true,
    this.isRequired = false,
    this.maxLines = 1,
    this.enabledBorder,
    this.fillColor,
    this.textAlign,
    this.cursorColor,
    this.inputFormatters,
    this.prefixIconConstraints,
    this.suffixIconConstraints,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (isShowLabel) LabelText(text: label, style: labelStyle, instruction: instruction ?? '', isRequired: isRequired),
        if (isShowLabel) SizedBox(height: Dimensions.space5),
        TextFormField(
            controller: controller,
            focusNode: focusNode,
            keyboardType: keyboardType,
            textInputAction: textInputAction,
            validator: validator,
            style: textStyle ?? lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
            cursorColor: cursorColor ?? MyColor.primaryColor,
            onChanged: onChanged,
            enabled: enabled,
            readOnly: isReadOnly,
            maxLines: maxLines,
            inputFormatters: inputFormatters,
            decoration: InputDecoration(
              contentPadding: padding ?? EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
              fillColor: fillColor ?? MyColor.colorWhite.withValues(alpha: 0.1),
              filled: true,
              hintText: hintText,
              hintStyle: hintTextStyle ?? lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1)),
              enabledBorder: enabledBorder ?? OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1)),
              errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorRed, width: 1)),
              focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorRed, width: 1)),
              suffixIcon: suffixIcon,
              prefixIcon: prefixIcon,
              suffixIconConstraints: suffixIconConstraints ?? BoxConstraints(maxHeight: 40, maxWidth: 40),
              prefixIconConstraints: prefixIconConstraints ?? BoxConstraints(maxHeight: 40, maxWidth: 40),
            ),
            cursorOpacityAnimates: true,
            onTap: onTap,
            textAlign: textAlign ?? TextAlign.start,
            onFieldSubmitted: (text) => onSubmit != null),
      ],
    );
  }
}
