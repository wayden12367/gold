import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';

class CustomBodyContainer extends StatelessWidget {
  final Widget child;
  final double? height, width;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? borderRadius;
  const CustomBodyContainer({super.key, required this.child, this.height, this.width, this.padding, this.borderRadius});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? Dimensions.screenPadding,
      width: width ?? MediaQuery.of(context).size.width,
      constraints: BoxConstraints(minHeight: height ?? MediaQuery.of(context).size.height, minWidth: width ?? MediaQuery.of(context).size.width),
      decoration: BoxDecoration(
        borderRadius: borderRadius ?? BorderRadius.circular(0),
        gradient: LinearGradient(
          colors: [MyColor.backgroundColor, MyColor.backgroundColor.withValues(alpha: 0.01)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          stops: [0.0, 0.1],
        ),
        image: DecorationImage(
          image: AssetImage(MyImages.bgShape),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver),
        ),
      ),
      child: child,
    );
  }
}
