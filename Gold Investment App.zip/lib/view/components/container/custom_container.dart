import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_color.dart';

class CustomContainer extends StatelessWidget {
  final EdgeInsets? padding;
  final EdgeInsets? margin;
  final Color? color;
  final double? radius;
  final BorderRadiusGeometry? borderRadius;
  final BoxBorder? border;
  final Widget child;
  final double? width;
  final double? height;
  final List<BoxShadow>? boxShadow;
  const CustomContainer({super.key, this.padding, this.margin, this.color, this.radius, this.borderRadius, this.border, required this.child, this.width, this.height, this.boxShadow});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      margin: margin,
      width: width,
      height: height,
      decoration: BoxDecoration(
        color: color ?? MyColor.colorWhite.withValues(alpha: 0.10),
        borderRadius: borderRadius ?? BorderRadius.circular(radius ?? 20),
        border: border ??
            Border(
              bottom: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: .5),
              left: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: .5),
              right: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.10), width: .5),
            ),
        boxShadow: boxShadow,
      ),
      child: child,
    );
  }
}
