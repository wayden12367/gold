import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:get/get.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/services/api_service.dart';

class CustomAppBar extends StatefulWidget implements PreferredSizeWidget {
  final String title;
  final bool isShowBackBtn;
  final Color? bgColor;
  final double? appBarHeight;
  final List<Widget>? action;
  final VoidCallback? backButtonOnPress;
  final bool isGradient;
  final double? paddingVertical;
  final double? paddingHorizontal;
  final TextStyle? titleStyle;
  final MainAxisAlignment mainAxisAlignment;
  const CustomAppBar({
    super.key,
    this.bgColor,
    this.isShowBackBtn = true,
    required this.title,
    this.action,
    this.backButtonOnPress,
    this.appBarHeight = 80,
    this.isGradient = true,
    this.paddingVertical = 10,
    this.paddingHorizontal = 15,
    this.titleStyle,
    this.mainAxisAlignment = MainAxisAlignment.spaceBetween,
  });

  @override
  State<CustomAppBar> createState() => _CustomAppBarState();

  @override
  Size get preferredSize => Size.fromHeight(60);
}

class _CustomAppBarState extends State<CustomAppBar> {
  bool hasNotification = false;
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PreferredSize(
      preferredSize: Size.fromHeight(widget.appBarHeight!),
      child: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: widget.paddingHorizontal!, vertical: widget.paddingVertical!),
          color: widget.bgColor ?? MyColor.backgroundColor,
          child: Row(
            mainAxisAlignment: widget.mainAxisAlignment,
            children: [
              Row(
                children: [
                  if (widget.isShowBackBtn) ...[
                    IconButton(
                      onPressed: () {
                        if (widget.backButtonOnPress != null) {
                          widget.backButtonOnPress!();
                        } else {
                          Get.back();
                        }
                      },
                      color: MyColor.colorWhite.withValues(alpha: 0.1),
                      icon: Icon(Icons.arrow_back_ios, size: 20, color: MyColor.colorWhite),
                    ),
                    const SizedBox(width: Dimensions.space10),
                  ],
                  if (widget.isGradient) ...[
                    GradientText(
                      text: widget.title,
                      style: widget.titleStyle ?? semiBoldDefault.copyWith(fontSize: 18),
                    ),
                  ] else ...[
                    Text(
                      widget.title,
                      style: widget.titleStyle ?? semiBoldDefault.copyWith(fontSize: 18),
                    ),
                  ],
                ],
              ),
              if (widget.action != null) ...[
                ...widget.action!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
