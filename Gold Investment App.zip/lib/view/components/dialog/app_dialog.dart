import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:get/get.dart';

class AppDialog {
  void warningAlertDialog(
    BuildContext context,
    VoidCallback press, {
    required String title,
    required String subTitle,
    TextStyle? titleStyle,
    TextStyle? subTitleStyle,
  }) {
    showDialog(
      context: context,
      barrierColor: MyColor.backgroundColor.withValues(alpha: .9),
      useSafeArea: true,
      barrierDismissible: false,
      builder: (context) => Dialog(
        surfaceTintColor: MyColor.cardBgColor,
        backgroundColor: MyColor.cardBgColor,
        insetPadding: const EdgeInsets.symmetric(horizontal: Dimensions.space40),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 6,
        shadowColor: MyColor.bodyTextColor,
        insetAnimationDuration: Duration(microseconds: 700),
        child: SingleChildScrollView(
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              CustomContainer(
                color: MyColor.cardBgColor,
                padding: EdgeInsets.symmetric(vertical: Dimensions.space40, horizontal: Dimensions.space10),
                border: GradientBoxBorder(gradient: MyColor.gradientBorder),
                borderRadius: BorderRadius.circular(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: Dimensions.space15),
                    Align(alignment: Alignment.center, child: Text(title.tr, style: titleStyle ?? semiBoldDefault.copyWith(fontSize: 20, color: MyColor.redCancelTextColor), textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, maxLines: 2)),
                    const SizedBox(height: Dimensions.space5),
                    Text(subTitle.tr, style: subTitleStyle ?? lightDefault.copyWith(color: MyColor.bodyTextColor), textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, maxLines: 5),
                    const SizedBox(height: Dimensions.space20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const SizedBox(width: Dimensions.space20),
                        Expanded(
                          child: ZoomTapAnimation(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                              decoration: BoxDecoration(color: MyColor.colorGreen, borderRadius: BorderRadius.circular(Dimensions.mediumRadius)),
                              child: Center(child: Text(MyStrings.no.tr, style: regularDefault.copyWith(color: MyColor.colorWhite))),
                            ),
                          ),
                        ),
                        const SizedBox(width: Dimensions.space20),
                        Expanded(
                          child: ZoomTapAnimation(
                            onTap: press,
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                              decoration: BoxDecoration(color: MyColor.redCancelTextColor, borderRadius: BorderRadius.circular(Dimensions.mediumRadius)),
                              child: Center(child: Text(MyStrings.yes.tr, style: regularDefault.copyWith(color: MyColor.colorWhite))),
                            ),
                          ),
                        ),
                        const SizedBox(width: Dimensions.space20),
                      ],
                    )
                  ],
                ),
              ),
              Positioned(
                top: -30,
                left: MediaQuery.of(context).padding.left,
                right: MediaQuery.of(context).padding.right,
                child: Container(
                  decoration: BoxDecoration(
                    color: MyColor.redCancelTextColor,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.dangerous, size: 60, color: MyColor.colorWhite),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
