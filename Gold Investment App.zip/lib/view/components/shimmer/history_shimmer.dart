import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/environment.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:skeletonizer/skeletonizer.dart';

class HistoryShimmer extends StatelessWidget {
  final int itemCount;
  final bool isRow;
  const HistoryShimmer({super.key, this.itemCount = 10, this.isRow = false});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: List.generate(
          itemCount,
          (index) => Skeletonizer(
              enabled: true,
              containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
              effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
              child: CustomContainer(
                padding: isRow ? EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space10) : EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                color: MyColor.colorWhite.withValues(alpha: 0.05),
                radius: isRow ? 10 : 20,
                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                width: double.infinity,
                margin: EdgeInsets.only(bottom: Dimensions.space10),
                child: isRow
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.all(Dimensions.space5),
                                  decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                  child: Container(
                                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                                    width: 30,
                                    height: 30,
                                  ),
                                ),
                                SizedBox(width: Dimensions.space5),
                                Expanded(
                                  child: Text("Payment Method", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                ),
                              ],
                            ),
                          ),
                          Radio(
                            value: false,
                            groupValue: false,
                            activeColor: MyColor.primaryColor,
                            fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                            onChanged: (value) {},
                          ),
                        ],
                      )
                    : Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Gold Category", style: boldDefault.copyWith(fontSize: 17)),
                              Text("12/12/2024", style: lightDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor)),
                            ],
                          ),
                          SizedBox(height: Dimensions.space16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                  child: CardColumn(
                                header: MyStrings.quantity,
                                body: "${AppConverter.formatNumber('1000', precision: 4)} Gram",
                                maxLine: 1,
                                alignmentCenter: true,
                              )),
                              Expanded(
                                child: CardColumn(
                                  header: MyStrings.price,
                                  body: "${Environment.defaultCurrencySymbol}${AppConverter.formatNumber('1000', precision: 2)} ${Environment.defaultCurrency}",
                                  maxLine: 1,
                                  alignmentCenter: true,
                                ),
                              ),
                              Expanded(child: CardColumn(header: MyStrings.charge, body: "${Environment.defaultCurrencySymbol}${AppConverter.formatNumber('1000', precision: 2)}", alignmentCenter: true, maxLine: 1)),
                            ],
                          )
                        ],
                      ),
              )),
        ),
      ),
    );
  }
}
