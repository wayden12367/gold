import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';

class CircleIconButton extends StatelessWidget {
  final Widget icon;
  final EdgeInsets? padding;
  final Color? color;
  final BoxShape? shape;
  final BorderRadiusGeometry? borderRadius;
  final BoxBorder? border;
  const CircleIconButton({super.key, required this.icon, this.padding, this.color, this.shape, this.borderRadius, this.border});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? EdgeInsets.all(Dimensions.space8),
      decoration: BoxDecoration(
        border: border,
        shape: shape ?? BoxShape.circle,
        color: color ?? MyColor.cardBgColor.withValues(alpha: 0.10),
        borderRadius: borderRadius,
      ),
      child: icon,
    );
  }
}
