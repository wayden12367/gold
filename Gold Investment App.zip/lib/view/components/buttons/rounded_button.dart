import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class RoundedButton extends StatelessWidget {
  final String text;
  final void Function() onTap;
  final bool isLoading;
  final TextStyle? textStyle;
  final Color? loadingColor;
  final double? radius;
  final double? paddingHorizontal;
  final double? paddingVertical;
  final Gradient? gradient;
  final EdgeInsets? margin;
  final bool? isOutline;
  const RoundedButton({
    super.key,
    required this.text,
    required this.onTap,
    this.isLoading = false,
    this.textStyle,
    this.loadingColor,
    this.radius = 12,
    this.paddingHorizontal,
    this.paddingVertical,
    this.gradient,
    this.margin,
    this.isOutline = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: isOutline!
          ? Container(
              margin: margin,
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: paddingHorizontal ?? Dimensions.space20, vertical: paddingVertical ?? 18),
              decoration: BoxDecoration(
                color: MyColor.transparentColor,
                borderRadius: BorderRadius.circular(radius!),
                border: GradientBoxBorder(gradient: LinearGradient(colors: [Color(0xFFFFDE4D), MyColor.primaryColor960], begin: Alignment.topCenter, end: Alignment.bottomCenter), width: 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  isLoading ? SizedBox(width: Dimensions.space20, child: SpinKitFadingCircle(color: loadingColor ?? MyColor.colorBlack, size: 20)) : GradientText(text: text, style: textStyle ?? boldDefault.copyWith(fontSize: 18)),
                ],
              ),
            )
          : Container(
              margin: margin,
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: paddingHorizontal ?? Dimensions.space20, vertical: paddingVertical ?? 18),
              decoration: BoxDecoration(
                gradient: gradient ?? LinearGradient(colors: [Color(0xFFFFDE4D), MyColor.primaryColor960], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                borderRadius: BorderRadius.circular(radius!),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  isLoading ? SizedBox(width: Dimensions.space20, child: SpinKitFadingCircle(color: loadingColor ?? MyColor.colorBlack, size: 20)) : Text(text.tr, style: textStyle ?? boldDefault.copyWith(fontSize: 18, color: MyColor.colorBlack)),
                ],
              ),
            ),
    );
  }
}
