import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/dialog/app_dialog.dart';
import 'package:get/get.dart';

class WillPopWidget extends StatelessWidget {
  final Widget child;
  final String nextRoute;

  const WillPopWidget({super.key, required this.child, this.nextRoute = ''});

  @override
  Widget build(BuildContext context) {
    return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, v) async {
          if (didPop) return;
          if (nextRoute.isEmpty) {
            AppDialog().warningAlertDialog(
              context,
              () {
                SystemNavigator.pop();
              },
              title: MyStrings.exitTitle.tr,
              subTitle: "".tr,
              titleStyle: regularDefault.copyWith(fontSize: Dimensions.fontLarge),
            );
          } else {
            Get.offAndToNamed(nextRoute);
          }
        },
        child: child);
  }
}
