import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class FullScreenLoader extends StatelessWidget {
  final Color? bgColor;
  final Color? loaderColor;
  final double? size;
  const FullScreenLoader({super.key, this.bgColor, this.loaderColor, this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: bgColor ?? MyColor.backgroundColor,
      child: Center(child: SpinKitFadingCircle(color: loaderColor ?? MyColor.primaryColor, size: size ?? 20.0)),
    );
  }
}
