import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:get/get.dart';

class LabelText extends StatefulWidget {
  final String text, instruction;
  final TextStyle? style;
  final bool isRequired;

  const LabelText({super.key, required this.text, this.style, this.instruction = '', this.isRequired = false});

  @override
  State<LabelText> createState() => _LabelTextState();
}

class _LabelTextState extends State<LabelText> {
  final GlobalKey<TooltipState> _tooltipKey = GlobalKey<TooltipState>();

  @override
  Widget build(BuildContext context) {
    return widget.isRequired
        ? Row(
            children: [
              Text(
                widget.text.tr,
                style: widget.style ?? lightDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor),
              ),
              const SizedBox(width: 2),
              if (widget.instruction != '') ...[
                Padding(
                  padding: const EdgeInsetsDirectional.only(start: Dimensions.space2, end: Dimensions.space10),
                  child: Tooltip(
                      key: _tooltipKey,
                      message: widget.instruction,
                      child: GestureDetector(
                        onTap: () {
                          _tooltipKey.currentState?.ensureTooltipVisible();
                        },
                        child: Icon(Icons.info_outline_rounded, size: Dimensions.space15, color: MyColor.colorWhite),
                      )),
                ),
              ],
              Text(
                '*',
                style: semiBoldDefault.copyWith(color: MyColor.colorRed),
              )
            ],
          )
        : Text(widget.text.tr, style: widget.style ?? lightDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor));
  }
}
