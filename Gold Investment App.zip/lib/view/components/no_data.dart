import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:lottie/lottie.dart';

class NoDataWidget extends StatelessWidget {
  final double margin;
  String? text;
  NoDataWidget({
    super.key,
    this.margin = 4,
    this.text,
  });

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size.height / margin;
    return Container(
      alignment: Alignment.center,
      margin: EdgeInsets.symmetric(vertical: size),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset("assets/animation/empty.json", height: size, width: double.infinity),
          const SizedBox(height: Dimensions.space3),
          Text(
            (text ?? MyStrings.noDataToShow).tr,
            style: regularDefault.copyWith(color: MyColor.colorWhite),
          )
        ],
      ),
    );
  }
}
