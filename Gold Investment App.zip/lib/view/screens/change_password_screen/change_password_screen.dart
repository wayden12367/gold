import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/auth/change_password_controller.dart';
import 'package:viser_gold/data/model/model/error_model.dart';
import 'package:viser_gold/data/repo/account/change_password_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/password_validation/validation_widget.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/auth_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final TextEditingController oldPasswordController = TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  String? email, code;
  bool isObscure = true;
  bool isNewObscure = true;
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(ChangePasswordRepo(apiClient: Get.find()));
    Get.put(ChangePasswordController(changePasswordRepo: Get.find()));
    super.initState();
  }

  List<ErrorModel> passwordValidationRules = [
    ErrorModel(text: MyStrings.hasUpperLetter.tr, hasError: true),
    ErrorModel(text: MyStrings.hasLowerLetter.tr, hasError: true),
    ErrorModel(text: MyStrings.hasDigit.tr, hasError: true),
    ErrorModel(text: MyStrings.hasSpecialChar.tr, hasError: true),
    ErrorModel(text: MyStrings.minSixChar.tr, hasError: true),
  ];

  void updateValidationList(String value) {
    passwordValidationRules[0].hasError =
        value.contains(RegExp(r'[A-Z]')) ? false : true;
    passwordValidationRules[1].hasError =
        value.contains(RegExp(r'[a-z]')) ? false : true;
    passwordValidationRules[2].hasError =
        value.contains(RegExp(r'[0-9]')) ? false : true;
    passwordValidationRules[3].hasError =
        value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')) ? false : true;
    passwordValidationRules[4].hasError = value.length >= 6 ? false : true;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        resizeToAvoidBottomInset: true,
        appBar: CustomAppBar(
            title: MyStrings.changePassword,
            bgColor: MyColor.transparentColor,
            isShowBackBtn: true),
        body: SingleChildScrollView(
          child: CustomBodyContainer(
            child: GetBuilder<ChangePasswordController>(
              builder: (controller) {
                return Column(
                  children: [
                    //  SizedBox(height: MediaQuery.of(context).size.height * 0.2),
                    Container(
                      padding: EdgeInsets.only(
                          left: Dimensions.space20,
                          right: Dimensions.space20,
                          top: Dimensions.space15),
                      decoration: BoxDecoration(
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                            color: MyColor.colorWhite.withValues(alpha: 0.1),
                            width: .5),
                      ),
                      child: Form(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(height: Dimensions.space15),
                            Text(MyStrings.createPasswordSubText.tr,
                                style: lightDefault.copyWith(
                                    fontSize: 12, color: MyColor.colorWhite),
                                textAlign: TextAlign.center),
                            SizedBox(height: Dimensions.space20),
                            AuthTextField(
                              label: MyStrings.password.tr,
                              prefixIcon: SvgPicture.asset(MyImages.lock),
                              controller: oldPasswordController,
                              onChanged: (value) {
                                // updateValidationList(value);
                              },
                              isObscure: isObscure,
                              suffixIcon: IconButton(
                                onPressed: () {
                                  isObscure = !isObscure;
                                  setState(() {});
                                },
                                icon: Icon(
                                    isObscure
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    color: MyColor.iconColor),
                              ),
                              textInputAction: TextInputAction.next,
                            ),
                            SizedBox(height: Dimensions.space16),
                            AuthTextField(
                              label: MyStrings.newPassword.tr,
                              prefixIcon: SvgPicture.asset(MyImages.lock),
                              controller: newPasswordController,
                              onChanged: (value) {
                                updateValidationList(value);
                              },
                              isObscure: isNewObscure,
                              suffixIcon: IconButton(
                                onPressed: () {
                                  isNewObscure = !isNewObscure;
                                  setState(() {});
                                },
                                icon: Icon(
                                    isNewObscure
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    color: MyColor.iconColor),
                              ),
                              textInputAction: TextInputAction.next,
                            ),
                            Visibility(
                              visible:
                                  Get.find<ApiClient>().isStrongPassEnabled(),
                              child: ValidationWidget(
                                  list: passwordValidationRules),
                            ),
                            SizedBox(height: Dimensions.space16),
                            AuthTextField(
                              label: MyStrings.confirmPassword.tr,
                              prefixIcon: SvgPicture.asset(MyImages.lock),
                              controller: confirmPasswordController,
                              onChanged: (value) {},
                              isObscure: true,
                              textInputAction: TextInputAction.done,
                            ),
                            SizedBox(height: Dimensions.space40),
                            RoundedButton(
                              text: MyStrings.submit,
                              isLoading: controller.submitLoading,
                              onTap: () {
                                if (newPasswordController.text.isEmpty) {
                                  CustomSnackBar.error(errorList: [
                                    MyStrings.enterYourPassword_.tr
                                  ]);
                                  return;
                                }
                                if (confirmPasswordController.text
                                        .toLowerCase() !=
                                    newPasswordController.text.toLowerCase()) {
                                  CustomSnackBar.error(errorList: [
                                    MyStrings.kMatchPassError.tr
                                  ]);
                                  return;
                                }
                                if (Get.find<ApiClient>()
                                        .isStrongPassEnabled() &&
                                    !MyUtils.regex
                                        .hasMatch(newPasswordController.text)) {
                                  CustomSnackBar.error(
                                      errorList: [MyStrings.invalidPassMsg.tr]);
                                  return;
                                } else {
                                  controller.changePassword(
                                      currentPass: oldPasswordController.text,
                                      password: newPasswordController.text);
                                }
                              },
                            ),
                            SizedBox(height: Dimensions.space40),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
