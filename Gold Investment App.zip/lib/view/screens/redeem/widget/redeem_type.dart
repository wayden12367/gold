import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/reedem/redeem_controller.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:get/get.dart';

class RedeemType extends StatelessWidget {
  const RedeemType({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RedeemController>(builder: (controller) {
      return Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
        decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(200), border: Border.all(color: MyColor.borderColor, width: 1)),
        child: Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () {
                  controller.changeRedeemType("1");
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space25, vertical: Dimensions.space8),
                  decoration: BoxDecoration(
                    color: controller.redeemType == "1" ? MyColor.dropdownBgColor : MyColor.transparentColor,
                    borderRadius: BorderRadius.circular(22),
                    border: controller.redeemType == "1" ? GradientBoxBorder(gradient: LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)), width: 2) : null,
                  ),
                  child: Center(
                    child: FittedBox(
                      child: GradientText(
                        text: MyStrings.goldInBar,
                        style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                        gradient: controller.redeemType == "1" ? LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)) : LinearGradient(colors: [MyColor.bodyTextColor, MyColor.bodyTextColor]),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: Dimensions.space10),
            Expanded(
              child: InkWell(
                onTap: () {
                  controller.changeRedeemType("2");
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space25, vertical: Dimensions.space8),
                  decoration: BoxDecoration(
                    color: controller.redeemType == "2" ? MyColor.dropdownBgColor : MyColor.transparentColor,
                    borderRadius: BorderRadius.circular(22),
                    border: controller.redeemType == "2" ? GradientBoxBorder(gradient: LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)), width: 2) : null,
                  ),
                  child: Center(child: controller.redeemType == "2" ? FittedBox(child: GradientText(text: MyStrings.goldInCoin.tr, style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite))) : FittedBox(child: Text(MyStrings.goldInCoin.tr, style: boldDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)))),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }
}
