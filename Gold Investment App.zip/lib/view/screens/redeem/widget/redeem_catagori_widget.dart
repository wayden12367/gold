import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/reedem/redeem_controller.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/view/components/dropdown/generic_drop_down.dart';
import 'package:get/get.dart';

class RedeemGoldCategory extends StatelessWidget {
  const RedeemGoldCategory({super.key});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 130,
      left: 15,
      right: 15,
      child: GetBuilder<RedeemController>(
        builder: (controller) {
          return Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
            decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor, width: 1)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                IgnorePointer(
                  ignoring: controller.currentPage == 1,
                  child: GenericDropdown<UserGoldCategory>(
                    title: "",
                    isShowTitle: false,
                    list: controller.assetList,
                    displayItem: (value) => value.category?.name ?? "",
                    selectedValue: controller.selectedAsset,
                    onChanged: (value) {
                      if (value != null) {
                        controller.selectAsset(value);
                      }
                    },
                  ),
                ),
                SizedBox(height: Dimensions.space10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(AppConverter.formatNumber(controller.selectedAsset.quantity ?? "0", precision: 4), style: boldDefault.copyWith(fontSize: 28, color: MyColor.colorWhite)),
                    SizedBox(width: Dimensions.space5),
                    Text(MyStrings.gramGold.tr, style: boldDefault.copyWith(fontSize: 18, color: MyColor.colorWhite)),
                  ],
                ),
                Text("${controller.currencySym}${AppConverter.mul(controller.selectedAsset.category?.price ?? "0", controller.selectedAsset.quantity ?? "0")} ${controller.currency}", style: semiBoldDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
              ],
            ),
          );
        },
      ),
    );
  }
}
