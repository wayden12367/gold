import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/reedem/redeem_controller.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class RedeemGoldInBar extends StatelessWidget {
  const RedeemGoldInBar({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<RedeemController>(
      builder: (controller) {
        return CustomContainer(
          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.03), width: 1),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Image.asset(MyImages.goldBar),
                  SizedBox(width: Dimensions.space20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: List.generate(
                        controller.barUnitList.length,
                        (index) {
                          final unit = controller.barUnitList[index];
                          return Container(
                            margin: EdgeInsets.symmetric(vertical: Dimensions.space5),
                            padding: EdgeInsets.only(left: 10, right: 5, top: 5, bottom: 5),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: MyColor.colorWhite.withValues(alpha: 0.03),
                              border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 1),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 1,
                                  child: Text("${AppConverter.formatNumber(unit.quantity ?? "0", precision: 1)} ${MyStrings.gram.tr}", style: semiBoldDefault.copyWith()),
                                ),
                                SizedBox(width: Dimensions.space20),
                                Expanded(
                                  flex: 2,
                                  child: CustomLabelTextFiled(
                                    label: "",
                                    isShowLabel: false,
                                    controller: unit.value,
                                    onChanged: (value) {
                                      printX("value>>>>>>>>>>: ${unit.value.text}");
                                    },
                                    inputFormatters: [LengthLimitingTextInputFormatter(12), FilteringTextInputFormatter.digitsOnly],
                                    keyboardType: TextInputType.number,
                                    prefixIcon: InkWell(
                                      onTap: () => controller.incrementAndDecrement(unit.id ?? "", false),
                                      customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                      child: Container(
                                        padding: EdgeInsets.all(5),
                                        decoration: BoxDecoration(border: Border(right: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 1))),
                                        child: SvgPicture.asset(MyImages.remove, width: 30, height: 30),
                                      ),
                                    ),
                                    suffixIcon: InkWell(
                                      onTap: () => controller.incrementAndDecrement(unit.id ?? "", true),
                                      customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                      child: Container(
                                        padding: EdgeInsets.all(5),
                                        decoration: BoxDecoration(border: Border(left: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 1))),
                                        child: SvgPicture.asset(MyImages.add, width: 30, height: 30),
                                      ),
                                    ),
                                    isReadOnly: true,
                                    textStyle: boldDefault.copyWith(color: MyColor.colorWhite, fontSize: 21),
                                    fillColor: MyColor.colorWhite.withValues(alpha: 0.05),
                                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.colorWhite.withValues(alpha: 0.2), width: 1)),
                                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                                    textAlign: TextAlign.center,
                                    cursorColor: MyColor.transparentColor,
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
