import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:get/get.dart';

class RedeemHistoryBottomSheet extends StatefulWidget {
  final GiftHistory giftHistory;
  const RedeemHistoryBottomSheet({super.key, required this.giftHistory});

  @override
  State<RedeemHistoryBottomSheet> createState() =>
      _RedeemHistoryBottomSheetState();
}

class _RedeemHistoryBottomSheetState extends State<RedeemHistoryBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          padding: EdgeInsets.symmetric(
              horizontal: Dimensions.space20, vertical: Dimensions.space15),
          decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                  color: MyColor.primaryColor.withValues(alpha: 0.1),
                  blurRadius: 10,
                  offset: Offset(0, -10))
            ],
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20), topRight: Radius.circular(20)),
            gradient: LinearGradient(
                colors: [
                  MyColor.colorBlack,
                  MyColor.colorBlack.withValues(alpha: 0.01)
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                stops: [0.0, 0.1]),
            image: DecorationImage(
                image: AssetImage(MyImages.bgShape),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(
                    Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.center,
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                      color: MyColor.colorGrey,
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
              SizedBox(height: Dimensions.space20),
              Text(MyStrings.orderDetails.tr,
                  style: semiBoldDefault.copyWith(
                      fontSize: 20, color: MyColor.colorWhite)),
              SizedBox(height: Dimensions.space10),
              CustomContainer(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(
                    horizontal: Dimensions.space20,
                    vertical: Dimensions.space15),
                color: MyColor.colorWhite.withValues(alpha: 0.05),
                radius: 12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: List.generate(
                    widget.giftHistory.redeemData?.orderDetails?.items
                            ?.length ??
                        0,
                    (index) {
                      var detail = widget
                          .giftHistory.redeemData?.orderDetails?.items?[index];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${index + 1}. ${detail?.text ?? ''}',
                            style: regularDefault.copyWith(
                                color: MyColor.primaryColor),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                          ),
                          if (index !=
                              (widget.giftHistory.redeemData?.orderDetails
                                          ?.items?.length ??
                                      0) -
                                  1) ...[
                            SizedBox(
                              height: Dimensions.space10,
                            )
                          ],
                        ],
                      );
                    },
                  ),
                ),
              ),
              SizedBox(height: Dimensions.space20),
              Text(MyStrings.deliveryDetails.tr,
                  style: semiBoldDefault.copyWith(
                      fontSize: 20, color: MyColor.colorWhite)),
              SizedBox(height: Dimensions.space10),
              CustomContainer(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.symmetric(
                    horizontal: Dimensions.space20,
                    vertical: Dimensions.space15),
                color: MyColor.colorWhite.withValues(alpha: 0.05),
                radius: 12,
                child: Text(
                  widget.giftHistory.redeemData?.deliveryAddress ?? '',
                  style: regularDefault.copyWith(color: MyColor.colorWhite),
                  maxLines: 10,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.start,
                ),
              ),
              SizedBox(height: Dimensions.space20),
              RoundedButton(
                text: MyStrings.back,
                onTap: () => Get.back(),
              ),
            ],
          ),
        ),
        Positioned(
          top: -20,
          right: 10,
          child: GestureDetector(
            onTap: () => Get.back(),
            child: CircleIconButton(
              color: MyColor.cardBgColor,
              icon: Icon(Icons.keyboard_double_arrow_down,
                  color: MyColor.redCancelTextColor),
            ).animate().fadeIn(
                delay: 100.ms,
                duration: 300.ms,
                begin: 0,
                curve: Curves.easeInOut),
          ),
        ),
      ],
    );
  }
}
