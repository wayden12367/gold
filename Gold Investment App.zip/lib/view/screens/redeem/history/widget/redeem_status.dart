import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/style.dart';

class RedeemStatus extends StatelessWidget {
  final String status;
  const RedeemStatus({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
      decoration: BoxDecoration(
        color: AppStatus.getRedeemStatusColor(status).withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppStatus.getRedeemStatusColor(status).withValues(alpha: 0.5), width: .5),
      ),
      child: Text(
        AppStatus.getRedeemStatus(status),
        style: regularDefault.copyWith(color: AppStatus.getRedeemStatusColor(status)),
      ),
    );
  }
}
