import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/reedem/redeem_history_controller.dart';
import 'package:viser_gold/data/repo/redeem_repo/redeem_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/redeem/history/widget/redeem_bottom_sheet_body.dart';
import 'package:viser_gold/view/screens/redeem/history/widget/redeem_status.dart';
import 'package:get/get.dart';

class RedeemHistoryScreen extends StatefulWidget {
  const RedeemHistoryScreen({super.key});

  @override
  State<RedeemHistoryScreen> createState() => _RedeemHistoryScreenState();
}

class _RedeemHistoryScreenState extends State<RedeemHistoryScreen> {
  final ScrollController scrollController = ScrollController();

  fetchData() {
    Get.find<RedeemHistoryController>().getRedeemHistory();
  }

  void scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<RedeemHistoryController>().hasNext()) {
        fetchData();
      }
    }
  }

  @override
  void initState() {
    Get.put(RedeemRepo());
    final controller = Get.put(RedeemHistoryController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
      scrollController.addListener(scrollListener);
    });
  }

  @override
  void dispose() {
    scrollController.removeListener(scrollListener);
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.redeemHistory, isShowBackBtn: true),
        body: Container(
          padding: Dimensions.screenPadding,
          constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
            image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
          ),
          child: GetBuilder<RedeemHistoryController>(
            builder: (controller) {
              return controller.isLoading
                  ? HistoryShimmer()
                  : controller.history.isEmpty && !controller.isLoading
                      ? NoDataWidget(text: MyStrings.emptyRedeemHistoryMsg)
                      : ListView.separated(
                          controller: scrollController,
                          addAutomaticKeepAlives: true,
                          separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                          itemCount: controller.history.length + 1,
                          itemBuilder: (context, index) {
                            if (index == controller.history.length) {
                              return controller.hasNext() ? CustomLoader(isPagination: true) : SizedBox.shrink();
                            }
                            final history = controller.history[index];
                            return CustomContainer(
                              padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                              color: MyColor.colorWhite.withValues(alpha: 0.05),
                              radius: 20,
                              border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            GradientText(text: history.goldCategory?.name ?? '', style: boldDefault.copyWith(fontSize: 17)),
                                            Text(DateConverter.formatDate(history.createdAt ?? ''), style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)),
                                          ],
                                        ),
                                      ),
                                      RedeemStatus(status: history.redeemData?.status ?? ''),
                                    ],
                                  ),
                                  SizedBox(height: Dimensions.space5),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CardColumn(
                                        header: MyStrings.quantity,
                                        body: "${AppConverter.formatNumber(history.quantity ?? '0', precision: 2)} ${MyStrings.gram.tr}",
                                        maxLine: 1,
                                      ),
                                      CardColumn(
                                        header: MyStrings.price,
                                        body: "${controller.currencySym}${AppConverter.formatNumber(history.amount ?? '0', precision: 2)} ${controller.currency}",
                                        maxLine: 1,
                                        alignmentEnd: true,
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: Dimensions.space5),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      CardColumn(
                                        header: MyStrings.charge,
                                        body: "${controller.currencySym}${AppConverter.formatNumber(history.charge ?? '0')}",
                                        maxLine: 1,
                                      ),
                                      ZoomTapAnimation(
                                        onTap: () {
                                          CustomBottomSheet(isNeedPadding: false, bgColor: MyColor.backgroundColor, child: RedeemHistoryBottomSheet(giftHistory: history)).show(context);
                                        },
                                        child: Container(
                                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                          decoration: BoxDecoration(
                                            color: MyColor.colorWhite.withValues(alpha: 0.1),
                                            borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
                                            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                          ),
                                          child: Text(
                                            MyStrings.details.tr,
                                            style: regularDefault.copyWith(fontSize: 12, color: MyColor.colorWhite),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          },
                        );
            },
          ),
        ),
      ),
    );
  }
}
