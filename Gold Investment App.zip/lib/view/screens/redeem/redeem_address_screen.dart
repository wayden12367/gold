import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/reedem/redeem_controller.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:get/get.dart';

class RedeemAddressScreen extends StatefulWidget {
  const RedeemAddressScreen({super.key});

  @override
  State<RedeemAddressScreen> createState() => _RedeemAddressScreenState();
}

class _RedeemAddressScreenState extends State<RedeemAddressScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController streetController = TextEditingController();
  final TextEditingController cityController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController zipCodeController = TextEditingController();
  final TextEditingController addressController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 290),
      padding: Dimensions.screenPadding,
      child: GetBuilder<RedeemController>(builder: (controller) {
        return SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: Dimensions.space20),
                CustomLabelTextFiled(
                  label: MyStrings.street,
                  hintText: "",
                  controller: streetController,
                  onChanged: (value) {},
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "${MyStrings.street.tr} ${MyStrings.isRequired.tr}";
                    }
                    return null;
                  },
                ),
                SizedBox(height: Dimensions.space15),
                CustomLabelTextFiled(
                  label: MyStrings.city,
                  hintText: "",
                  controller: cityController,
                  onChanged: (value) {},
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "${MyStrings.city.tr} ${MyStrings.isRequired.tr}";
                    }
                    return null;
                  },
                ),
                SizedBox(height: Dimensions.space15),
                CustomLabelTextFiled(
                  label: MyStrings.zipCode,
                  hintText: "",
                  controller: zipCodeController,
                  onChanged: (value) {},
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "${MyStrings.zipCode.tr} ${MyStrings.isRequired.tr}";
                    }
                    return null;
                  },
                ),
                SizedBox(height: Dimensions.space15),
                CustomLabelTextFiled(
                  label: MyStrings.address,
                  hintText: "",
                  controller: addressController,
                  onChanged: (value) {},
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "${MyStrings.address.tr} ${MyStrings.isRequired.tr}";
                    }
                    return null;
                  },
                  maxLines: 3,
                ),
                SizedBox(height: Dimensions.space40),
                RoundedButton(
                  text: MyStrings.submit,
                  isLoading: controller.isSubmitLoading,
                  onTap: () async {
                    if (_formKey.currentState!.validate()) {
                      bool isSuccess = await controller.redeemGold(
                        address: {
                          "street": streetController.text,
                          "city": cityController.text,
                          "state": stateController.text,
                          "zip_code": zipCodeController.text,
                          "address": addressController.text,
                        },
                      );
                      if (isSuccess) {
                        streetController.clear();
                        cityController.clear();
                        stateController.clear();
                        zipCodeController.clear();
                        addressController.clear();
                        controller.resetUnitList();
                        controller.changePage(0);
                      }
                    }
                  },
                )
              ],
            ),
          ),
        );
      }),
    );
  }
}
