import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/reedem/redeem_controller.dart';
import 'package:viser_gold/data/repo/redeem_repo/redeem_repo.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:viser_gold/view/screens/redeem/redeem_address_screen.dart';
import 'package:viser_gold/view/screens/redeem/widget/redeem_catagori_widget.dart';
import 'package:viser_gold/view/screens/redeem/widget/redeem_gold_in_bar.dart';
import 'package:viser_gold/view/screens/redeem/widget/redeem_gold_in_coin.dart';
import 'package:viser_gold/view/screens/redeem/widget/redeem_type.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class RedeemScreen extends StatefulWidget {
  const RedeemScreen({super.key});

  @override
  State<RedeemScreen> createState() => _RedeemScreenState();
}

class _RedeemScreenState extends State<RedeemScreen> {
  @override
  void initState() {
    Get.put(RedeemRepo());
    final controller = Get.put(RedeemController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((t) {
      controller.initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: GetBuilder<RedeemController>(
        builder: (controller) {
          return PopScope(
            canPop: false,
            onPopInvokedWithResult: (didPop, result) {
              if (didPop) return;
              if (controller.currentPage == 0) {
                Get.back();
              } else {
                controller.changePage(0);
              }
            },
            child: Skeletonizer(
              enabled: controller.isLoading,
              containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
              effect: ShimmerEffect(highlightColor: MyColor.colorWhite.withValues(alpha: 0.05), baseColor: MyColor.colorWhite.withValues(alpha: 0.05)),
              child: CustomScaffold(
                title: MyStrings.redeemGold,
                actionWidget: Row(
                  children: [
                    if (controller.currentPage == 0) ...[
                      ZoomTapAnimation(
                        onTap: () => Get.toNamed(RouteHelper.redeemHistoryScreen),
                        child: CircleIconButton(icon: Image.asset(MyImages.history, width: 25, height: 25, color: MyColor.colorWhite)),
                      ),
                    ]
                  ],
                ),
                topForm: RedeemGoldCategory(),
                body: SizedBox(
                  height: MediaQuery.of(context).size.height,
                  child: PageView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: 2,
                    controller: controller.pageController,
                    onPageChanged: (index) {},
                    itemBuilder: (context, index) {
                      return index == 0
                          ? SingleChildScrollView(
                              padding: Dimensions.screenPadding,
                              child: Container(
                                margin: EdgeInsets.only(top: 290),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: Dimensions.space10),
                                    RedeemType(),
                                    SizedBox(height: Dimensions.space20),
                                    Builder(
                                      builder: (context) {
                                        return controller.redeemType == "1" ? RedeemGoldInBar() : RedeemGoldInCoin();
                                      },
                                    ),
                                    SizedBox(height: Dimensions.space5),
                                    Text(
                                      "${MyStrings.totalCharge.tr}: ${controller.getTotalCharge()} (${controller.currencySym}${AppConverter.formatNumber(controller.charge?.fixedCharge ?? "0")}-${AppConverter.formatNumber(controller.charge?.percentCharge ?? "0")}%)",
                                      style: regularDefault.copyWith(color: MyColor.colorWhite, fontSize: 12),
                                    ),
                                    SizedBox(height: Dimensions.space40),
                                    RoundedButton(
                                      text: MyStrings.continue_,
                                      onTap: () {
                                        if (controller.isValidForRedeem()) {
                                          controller.changePage(1);
                                        } else {
                                          CustomSnackBar.error(
                                            errorList: ["${MyStrings.minimumRedeemAmountIs} ${controller.currencySym}${AppConverter.formatNumber(controller.charge?.minAmount ?? "0")}"],
                                          );
                                        }
                                      },
                                    ),
                                    SizedBox(height: Dimensions.space40),
                                  ],
                                ),
                              ),
                            )
                          : RedeemAddressScreen();
                    },
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
