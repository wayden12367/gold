import 'package:flutter/material.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class ActivityWidget extends StatefulWidget {
  final HomeController homeController;
  const ActivityWidget({super.key, required this.homeController});

  @override
  State<ActivityWidget> createState() => _ActivityWidgetState();
}

class _ActivityWidgetState extends State<ActivityWidget> {
  final List<Map<String, dynamic>> activityList = [
    {"img": MyImages.goldBar, "title": MyStrings.buyGold, "route": RouteHelper.buyGoldScreen},
    {"img": MyImages.coin, "title": MyStrings.sellGold, "route": RouteHelper.sellGoldScreen},
    {"img": MyImages.gift, "title": MyStrings.giftGold, "route": RouteHelper.giftGoldScreen},
    {"img": MyImages.car, "title": MyStrings.redeem, "route": RouteHelper.redeemScreen},
  ];
  @override
  Widget build(BuildContext context) {
    return Skeletonizer(
      enabled: widget.homeController.isLoading,
      containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
      effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: List.generate(
            activityList.length,
            (index) => index == 3 && Get.find<ApiClient>().isRedeemEnabled() == false
                ? SizedBox.shrink()
                : InkWell(
                    onTap: () {
                      if (activityList[index]["route"] != "-1") {
                        Get.toNamed(activityList[index]["route"]);
                      }
                    },
                    child: Container(
                      margin: EdgeInsets.only(right: Dimensions.space10),
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(colors: [MyColor.primaryColor300.withValues(alpha: 0.15), MyColor.primaryColor960.withValues(alpha: 0.15)], begin: Alignment.centerLeft, end: Alignment.centerRight, transform: GradientRotation(180)),
                        border: GradientBoxBorder(width: 1, gradient: LinearGradient(colors: [MyColor.primaryColor300.withValues(alpha: 0.80), MyColor.primaryColor960.withValues(alpha: 0.80)], begin: Alignment.centerLeft, end: Alignment.centerRight)),
                        boxShadow: [
                          BoxShadow(color: Color.fromRGBO(0, 0, 0, 0.04), offset: Offset(0, 0), blurRadius: 4),
                          BoxShadow(color: Color.fromRGBO(0, 0, 0, 0.08), offset: Offset(0, 8), blurRadius: 16),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset(activityList[index]["img"], height: 50, width: 50),
                          const SizedBox(height: Dimensions.space5),
                          Text(activityList[index]["title"].toString().tr, style: semiBoldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)),
                        ],
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
