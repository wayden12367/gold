import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:flutter_animate/flutter_animate.dart' as animate;
import 'package:skeletonizer/skeletonizer.dart';

class HomeCarouselWidget extends StatelessWidget {
  final HomeController homeController;
  const HomeCarouselWidget({super.key, required this.homeController});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 160,
          child: homeController.isLoading
              ? Skeletonizer(
                  enabled: true,
                  containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
                  effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
                  child: Container(
                    decoration: BoxDecoration(
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: 1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    margin: EdgeInsets.only(right: Dimensions.space8),
                    height: 160,
                    width: MediaQuery.of(context).size.width,
                  ),
                )
              : PageView.builder(
                  itemCount: homeController.sliders.length,
                  physics: BouncingScrollPhysics(),
                  onPageChanged: (value) {
                    homeController.changeCurrentSlideIndex(value);
                  },
                  itemBuilder: (context, index) => Container(
                    decoration: BoxDecoration(border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: 1), borderRadius: BorderRadius.circular(20)),
                    margin: EdgeInsets.only(right: Dimensions.space8),
                    child: MyImageWidget(
                      imageUrl: "${UrlContainer.domainUrl}/${homeController.sliderImagePath}/${homeController.sliders[index].dataValues?.image ?? ""}",
                      height: 160,
                      width: MediaQuery.of(context).size.width,
                      boxFit: BoxFit.cover,
                      radius: 20,
                    ),
                  ).animate().fadeIn(delay: 100.milliseconds, duration: 1000.milliseconds),
                ),
        ),
        SizedBox(height: Dimensions.space20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: List.generate(
            homeController.sliders.length,
            (index) => AnimatedContainer(
              duration: 700.milliseconds,
              height: index == homeController.currentSlideIndex ? 10 : 10,
              width: index == homeController.currentSlideIndex ? 30 : 10,
              margin: EdgeInsets.only(right: Dimensions.space8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: index == homeController.currentSlideIndex ? MyColor.primaryColor : MyColor.borderColor,
                gradient: index == homeController.currentSlideIndex ? MyColor.gradientBorder2 : null,
              ),
            ),
          ),
        )
      ],
    );
  }
}
