import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';

class HomeIconButton extends StatelessWidget {
  final String image;
  final String text;
  const HomeIconButton({super.key, required this.image, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space17),
      decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor), boxShadow: [
        BoxShadow(
          color: Color.fromRGBO(0, 0, 0, 0.04),
          offset: Offset(0, 0),
          blurRadius: 4,
        ),
        BoxShadow(
          color: Color.fromRGBO(0, 0, 0, 0.08),
          offset: Offset(0, 8),
          blurRadius: 16,
        ),
      ]),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(image, height: 20, width: 20),
          const SizedBox(width: Dimensions.space10),
          GradientText(text: text, style: boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
