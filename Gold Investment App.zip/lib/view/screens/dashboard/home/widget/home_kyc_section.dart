import 'package:flutter/material.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class HomeKycSection extends StatelessWidget {
  const HomeKycSection({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(builder: (homeController) {
      return Skeletonizer(
        enabled: homeController.isLoading,
        containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
        effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
        child: Column(
          children: [
            ZoomTapAnimation(
              onTap: () {
                Get.toNamed(RouteHelper.kycVerificationScreen)?.then((value) => homeController.loadInitialData());
              },
              child: CustomContainer(
                width: double.infinity,
                color: MyColor.colorWhite.withValues(alpha: 0.10),
                padding: EdgeInsets.all(Dimensions.space15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(homeController.user.kv == "2" ? MyStrings.kycVerificationPending.tr : MyStrings.kycVerificationRequired.tr, style: semiBoldDefault.copyWith(color: homeController.user.kv == "2" ? MyColor.pendingColor : MyColor.colorRed)),
                    SizedBox(height: Dimensions.space5),
                    Text(homeController.user.kv == "2" ? MyStrings.kycVerificationPendingMSg.tr : MyStrings.kycVerificationMsg.tr, style: lightDefault.copyWith(color: homeController.user.kv == "2" ? MyColor.pendingColor : MyColor.redCancelTextColor)),
                  ],
                ),
              ),
            ),
            SizedBox(height: Dimensions.space20),
          ],
        ),
      );
    });
  }
}
