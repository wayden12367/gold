import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/view/screens/dashboard/home/widget/asset_card.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class HomeTopForm extends StatelessWidget {
  const HomeTopForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 150,
      left: 15,
      right: 15,
      child: GetBuilder<HomeController>(builder: (controller) {
        return Skeletonizer(
          enabled: controller.isLoading,
          containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
          effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: BouncingScrollPhysics(),
            child: controller.assets.isEmpty
                ? const EmptyAssetCard()
                : Row(
                    children: [
                      EmptyAssetCard(),
                      Row(children: List.generate(controller.assets.length, (index) => AssetCard(index: index))),
                    ],
                  ),
          ),
        );
      }),
    );
  }
}
