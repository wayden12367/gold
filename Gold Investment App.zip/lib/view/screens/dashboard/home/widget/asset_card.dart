import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:get/get.dart';

class AssetCard extends StatelessWidget {
  final int index;
  const AssetCard({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(builder: (controller) {
      return Container(
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
        margin: EdgeInsets.only(right: Dimensions.space10),
        width: controller.assets.length > 1 ? MediaQuery.of(context).size.width - 50 : MediaQuery.of(context).size.width - 30,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), image: DecorationImage(image: AssetImage(MyImages.appBarBg), fit: BoxFit.cover), boxShadow: [BoxShadow(color: MyColor.cardBgColor, blurRadius: .1, offset: Offset(0, 0))], border: GradientBoxBorder(width: .5, gradient: MyColor.gradientBorder)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
              decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(MyImages.goldBar, height: 20, width: 20),
                  const SizedBox(width: Dimensions.space10),
                  Text(controller.assets[index].category?.name ?? "", style: regularDefault.copyWith(fontSize: 16)),
                ],
              ),
            ),
            const SizedBox(height: Dimensions.space10),
            Row(
              children: [
                Text(AppConverter.formatNumber(controller.assets[index].quantity ?? "0.00"), style: boldDefault.copyWith(fontSize: 38)),
                const SizedBox(width: Dimensions.space4),
                Text(MyStrings.gramGold.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
              ],
            ),
            const SizedBox(height: Dimensions.space10),
            Row(
              children: [
                Text(MyStrings.marketToday.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                Icon(Icons.arrow_right_alt_outlined, color: MyColor.bodyTextColor),
                const SizedBox(width: Dimensions.space10),
                Expanded(
                  child: Text(
                    "${controller.currencySym}${AppConverter.mul(controller.assets[index].category?.price ?? "0.00", controller.assets[index].quantity ?? "0.00")} ${controller.currency}",
                    style: boldDefault.copyWith(fontSize: 22),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }
}

class EmptyAssetCard extends StatelessWidget {
  const EmptyAssetCard({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(builder: (controller) {
      return Container(
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
        margin: EdgeInsets.only(right: Dimensions.space10),
        width: controller.assets.isNotEmpty ? MediaQuery.of(context).size.width - 50 : MediaQuery.of(context).size.width - 30,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), image: DecorationImage(image: AssetImage(MyImages.appBarBg), fit: BoxFit.cover), boxShadow: [BoxShadow(color: MyColor.cardBgColor, blurRadius: .1, offset: Offset(0, 0))], border: GradientBoxBorder(width: .5, gradient: MyColor.gradientBorder)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
              decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(MyImages.goldBar, height: 20, width: 20),
                  const SizedBox(width: Dimensions.space10),
                  Text(MyStrings.myBalance.tr, style: regularDefault.copyWith(fontSize: 16)),
                ],
              ),
            ),
            const SizedBox(height: Dimensions.space10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text("${controller.currencySym}${AppConverter.formatNumber(controller.user.balance ?? "0.00")}", style: boldDefault.copyWith(fontSize: 38)),
                const SizedBox(width: Dimensions.space4),
                Text(controller.currency, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
              ],
            ),
            const SizedBox(height: Dimensions.space10),
            Row(
              children: [
                Text(MyStrings.myAssets.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                Icon(Icons.arrow_right_alt_outlined, color: MyColor.bodyTextColor),
                const SizedBox(width: Dimensions.space10),
                Text("${controller.currencySym}${AppConverter.formatNumber(controller.getTotalAssetAmount())} ${controller.currency}", style: boldDefault.copyWith(fontSize: 22)),
              ],
            ),
          ],
        ),
      );
    });
  }
}
