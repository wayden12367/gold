import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/data/repo/home/home_repo.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:viser_gold/view/screens/dashboard/home/widget/activity_widget.dart';
import 'package:viser_gold/view/screens/dashboard/home/widget/home_carousel.dart';
import 'package:viser_gold/view/screens/dashboard/home/widget/home_kyc_section.dart';
import 'package:viser_gold/view/screens/dashboard/home/widget/home_top_form.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    Get.put(HomeRepo(apiClient: Get.find()));
    final controller = Get.put(HomeController(homeRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (homeController) {
        return AnoNateWidget(
          navigationBarColor: MyColor.cardBgColor,
          systemNavigationBarDividerColor: MyColor.cardBgColor,
          child: CustomScaffold(
            title: "",
            appBarHeight: 250,
            bgDecoration: BoxDecoration(color: MyColor.backgroundColor),
            titleWidget: Skeletonizer(
              enabled: homeController.isLoading,
              containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
              effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
              child: Column(
                children: [
                  SizedBox(height: Dimensions.space20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        padding: EdgeInsets.only(left: Dimensions.space2, right: Dimensions.space15, top: Dimensions.space2 + 1, bottom: Dimensions.space2 + 1),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                          border: GradientBoxBorder(gradient: MyColor.gradientBorder, width: 2),
                          color: MyColor.cardBgColor.withValues(alpha: 0.10),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircleAvatar(
                              radius: 20,
                              backgroundColor: MyColor.transparentColor,
                              child: MyImageWidget(
                                imageUrl: "${UrlContainer.domainUrl}/assets/images/user/profile/${homeController.user.image ?? ""}",
                                isProfile: true,
                                radius: 20,
                                height: 40,
                                width: 40,
                              ),
                            ),
                            const SizedBox(width: Dimensions.space10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(homeController.user.username ?? "", style: boldDefault.copyWith(fontSize: 17, fontWeight: FontWeight.w600)),
                                Text(homeController.user.email ?? "", style: lightDefault.copyWith(fontSize: 12, color: MyColor.colorWhite)),
                              ],
                            )
                          ],
                        ),
                      ),
                      ZoomTapAnimation(
                        onTap: () => Get.toNamed(RouteHelper.notificationScreen),
                        child: Container(
                          padding: EdgeInsets.all(Dimensions.space12),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: MyColor.cardBgColor.withValues(alpha: 0.10),
                          ),
                          child: Icon(CupertinoIcons.bell, color: MyColor.colorWhite, size: 20),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            topForm: HomeTopForm(),
            body: Container(
              margin: EdgeInsets.only(top: 340),
              padding: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, top: Dimensions.space15),
              height: MediaQuery.of(context).size.height / 2,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Visibility(visible: homeController.user.kv != AppStatus.KYC_VERIFIED, child: HomeKycSection()),
                    ActivityWidget(homeController: homeController),
                    SizedBox(height: Dimensions.space20),
                    HomeCarouselWidget(homeController: homeController),
                    SizedBox(height: Dimensions.space30),
                    if (homeController.transactions.isNotEmpty)
                      Text(
                        MyStrings.transaction,
                        style: boldDefault.copyWith(fontSize: Dimensions.fontExtraLarge),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    SizedBox(height: Dimensions.space15),
                    homeController.isLoading
                        ? HistoryShimmer(itemCount: 5)
                        : ListView.separated(
                            shrinkWrap: true,
                            itemCount: homeController.transactions.length,
                            physics: NeverScrollableScrollPhysics(),
                            padding: EdgeInsets.zero,
                            separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                            itemBuilder: (context, index) {
                              final transaction = homeController.transactions[index];
                              return CustomContainer(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                                color: MyColor.backgroundColor,
                                radius: 20,
                                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                //border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: 1),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Expanded(
                                            child: Text(
                                          transaction.trx ?? '',
                                          style: boldDefault.copyWith(fontSize: 16),
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        )),
                                        SizedBox(width: Dimensions.space10),
                                        Expanded(
                                          child: Text(
                                            DateConverter.formatDate(transaction.createdAt ?? ''),
                                            style: lightDefault.copyWith(fontSize: 10, color: MyColor.bodyTextColor),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            textAlign: TextAlign.end,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: CardColumn(
                                            header: MyStrings.amount,
                                            body: "${transaction.trxType == "+" ? "+" : "-"}${homeController.currencySym}${AppConverter.formatNumber(transaction.amount ?? '', precision: 2)} ${homeController.currency} ",
                                            maxLine: 1,
                                            bodyTextStyle: regularDefault.copyWith(color: transaction.trxType == "+" ? MyColor.colorGreen : MyColor.colorRed, fontWeight: FontWeight.w500),
                                          ),
                                        ),
                                        Expanded(
                                            child: CardColumn(
                                          header: MyStrings.postBalance,
                                          body: "${homeController.currencySym}${AppConverter.formatNumber(transaction.postBalance ?? '', precision: 2)} ${homeController.currency} ",
                                          alignmentEnd: true,
                                          maxLine: 1,
                                        )),
                                      ],
                                    ),
                                    CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: 1, space: 5),
                                    CardColumn(
                                      header: MyStrings.details,
                                      body: transaction.details ?? '',
                                      maxLine: 5,
                                      bodyTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                    SizedBox(height: Dimensions.space20 * 2),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
