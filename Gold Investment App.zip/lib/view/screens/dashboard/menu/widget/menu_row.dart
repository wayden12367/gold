import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/image/custom_svg_picture.dart';
import 'package:get/get.dart';

class MenuRow extends StatelessWidget {
  final dynamic icon;
  final String title;
  final String route;
  final TextStyle? titleStyle;
  final Function()? onTap;
  final Widget? trailing;
  final bool isDeleteAccount;
  const MenuRow({super.key, required this.icon, required this.title, required this.route, this.titleStyle, this.onTap, this.trailing, this.isDeleteAccount = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        if (onTap != null) {
          onTap!();
        } else {
          Get.toNamed(route);
        }
      },
      customBorder: CircleBorder(),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space5, vertical: Dimensions.space2),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(14)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Row(
                children: [
                  isDeleteAccount ? CustomSvgPicture(image: icon, color: MyColor.redCancelTextColor, width: 24, height: 24) : GradientWidget(child: CustomSvgPicture(image: icon, color: MyColor.colorWhite, width: 24, height: 24)),
                  const SizedBox(width: Dimensions.space4),
                  Expanded(child: Text(title.tr, style: titleStyle ?? regularDefault.copyWith(fontSize: 16, color: isDeleteAccount ? MyColor.redCancelTextColor : MyColor.bodyTextColor), maxLines: 2, overflow: TextOverflow.ellipsis)),
                ],
              ),
            ),
            trailing ?? Icon(Icons.arrow_forward_ios, color: isDeleteAccount ? MyColor.redCancelTextColor : MyColor.iconColor, size: 12),
          ],
        ),
      ),
    );
  }
}
