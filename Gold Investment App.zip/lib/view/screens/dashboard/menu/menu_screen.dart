import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/menu/my_menu_controller.dart';
import 'package:viser_gold/data/controller/profile/profile_controller.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/data/repo/menu_repo/menu_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/dialog/app_dialog.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/dashboard/menu/widget/menu_row.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final List<Map<String, dynamic>> menuItem1 = [
    {"icon": MyImages.menuUser, "title": MyStrings.profile, "route": RouteHelper.profileScreen},
    {"icon": MyImages.menuLock, "title": MyStrings.changePassword, "route": RouteHelper.changePasswordScreen},
    {"icon": MyImages.menuKyc, "title": MyStrings.kycVerification, "route": RouteHelper.kycVerificationScreen},
    {"icon": MyImages.menu2fa, "title": MyStrings.twoFactorAuth, "route": RouteHelper.twoFactorSetupScreen},
    {"icon": MyImages.menuNotification, "title": MyStrings.notifications, "route": RouteHelper.notificationScreen},
  ];

  final List<Map<String, dynamic>> menuItem2 = [
    {"icon": MyImages.qrCode, "title": MyStrings.myQrCode, "route": RouteHelper.myQrCodeScreen},
    {"icon": MyImages.menuDepositHistoryIcon, "title": MyStrings.depositHistory, "route": RouteHelper.depositHistoryScreen},
    {"icon": MyImages.menuWithdrawHistoryIcon, "title": MyStrings.myWithdrawals, "route": RouteHelper.withdrawHistoryScreen},
    {"icon": MyImages.menuTransactionIcon, "title": MyStrings.transaction, "route": RouteHelper.transactionScreen},
  ];
  final List<Map<String, dynamic>> menuItem3 = [
    {"icon": MyImages.menuLanguageIcon, "title": MyStrings.language, "route": RouteHelper.languageScreen},
    {"icon": MyImages.menuFaqIcon, "title": MyStrings.faq, "route": RouteHelper.faqScreen},
    {"icon": MyImages.menuSupportTicketIcon, "title": MyStrings.supportTicket, "route": RouteHelper.supportTicketScreen},
    {"icon": MyImages.menuPrivacyPolicyIcon, "title": MyStrings.privacyPolicy, "route": RouteHelper.privacyScreen},
    {"icon": MyImages.menuLogoutIcon, "title": MyStrings.logout, "route": "-1"},
  ];

  @override
  void initState() {
    Get.put(ProfileRepo(apiClient: Get.find()));
    Get.put(ProfileController(profileRepo: Get.find()));
    Get.put(MenuRepo(apiClient: Get.find()));
    final controller = Get.put(MyMenuController(menuRepo: Get.find(), profileController: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(
          title: MyStrings.settings,
          titleStyle: semiBoldDefault.copyWith(fontSize: 28),
          isShowBackBtn: false,
        ),
        body: SingleChildScrollView(
          child: CustomBodyContainer(
            child: GetBuilder<MyMenuController>(builder: (controller) {
              return Column(
                children: [
                  SizedBox(height: Dimensions.space20),
                  GetBuilder<ProfileController>(builder: (pController) {
                    return Skeletonizer(
                      enabled: controller.isLoading,
                      containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
                      effect: ShimmerEffect(
                        highlightColor: MyColor.colorWhite.withValues(alpha: 0.05),
                        baseColor: MyColor.colorWhite.withValues(alpha: 0.05),
                      ),
                      child: InkWell(
                        onTap: () {
                          Get.toNamed(RouteHelper.profileScreen);
                        },
                        customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        child: CustomContainer(
                          width: double.infinity,
                          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                          color: MyColor.colorWhite.withValues(alpha: 0.05),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 20,
                                      backgroundColor: MyColor.transparentColor,
                                      child: MyImageWidget(
                                        imageUrl: pController.imageUrl,
                                        isProfile: true,
                                        radius: 20,
                                        height: 40,
                                        width: 40,
                                      ),
                                    ),
                                    const SizedBox(width: Dimensions.space10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(controller.user?.username ?? '', style: boldDefault.copyWith(fontSize: 17, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                                          Text(controller.user?.email ?? '', style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(width: Dimensions.space10),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space5),
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: controller.isVerifiedUser() ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                child: Text(controller.isVerifiedUser() ? MyStrings.verified : MyStrings.notVerified, style: boldDefault.copyWith(fontSize: 13, color: controller.isVerifiedUser() ? MyColor.colorGreen : MyColor.colorRed)),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }),
                  SizedBox(height: Dimensions.space20),
                  CustomContainer(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    child: Column(
                      children: List.generate(menuItem1.length, (index) {
                        return Column(
                          children: [
                            MenuRow(icon: menuItem1[index]['icon'], title: menuItem1[index]['title'], route: menuItem1[index]['route']),
                            index != menuItem1.length - 1 ? CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: .5, thickness: .5, space: 12) : SizedBox(),
                          ],
                        );
                      }),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20),
                  CustomContainer(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    child: Column(
                      children: List.generate(menuItem2.length, (index) {
                        return Column(
                          children: [
                            MenuRow(icon: menuItem2[index]['icon'], title: menuItem2[index]['title'], route: menuItem2[index]['route']),
                            index != menuItem2.length - 1 ? CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: .5, thickness: .5, space: 12) : SizedBox(),
                          ],
                        );
                      }),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20),
                  CustomContainer(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    child: Column(
                      children: List.generate(menuItem3.length, (index) {
                        return menuItem3[index]['route'] == RouteHelper.languageScreen && !controller.menuRepo.apiClient.isMultiLanguageEnabled()
                            ? SizedBox()
                            : Column(
                                children: [
                                  MenuRow(
                                    icon: menuItem3[index]['icon'],
                                    title: menuItem3[index]['title'],
                                    route: menuItem3[index]['route'],
                                    onTap: menuItem3[index]['route'] == "-1"
                                        ? () {
                                            controller.logout();
                                          }
                                        : null,
                                    trailing: menuItem3[index]['route'] == "-1" && controller.logoutLoading ? CustomLoader(isPagination: true) : null,
                                  ),
                                  index != menuItem3.length - 1 ? CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: .5, thickness: .5, space: 12) : SizedBox(),
                                ],
                              );
                      }),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20),
                  BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: controller.removeLoading ? 15.3 : 0, sigmaY: controller.removeLoading ? 15.3 : 0),
                    child: CustomContainer(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      child: MenuRow(
                        icon: MyImages.menuLogoutIcon,
                        title: MyStrings.deleteAccount,
                        route: "",
                        onTap: () {
                          AppDialog().warningAlertDialog(
                            context,
                            () {
                              controller.removeAccount();
                              Get.back();
                            },
                            title: MyStrings.deleteAccount,
                            subTitle: MyStrings.deleteBottomSheetSubtitle,
                          );
                        },
                        isDeleteAccount: true,
                        trailing: controller.removeLoading ? CustomLoader(isPagination: true, loaderColor: MyColor.redCancelTextColor) : null,
                      ),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20 * 6),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
