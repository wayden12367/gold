import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/deposit/deposit_history_controller.dart';
import 'package:viser_gold/data/controller/transaction/transactions_controller.dart';
import 'package:viser_gold/data/model/transctions/transaction_response_model.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/dropdown/generic_drop_down.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:get/get.dart';

class TransactionFilterBottomSheet extends StatefulWidget {
  const TransactionFilterBottomSheet({super.key});

  @override
  State<TransactionFilterBottomSheet> createState() => _TransactionFilterBottomSheetState();
}

class _TransactionFilterBottomSheetState extends State<TransactionFilterBottomSheet> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<TransactionsController>(builder: (controller) {
      return Stack(
        clipBehavior: Clip.none,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeInOut,
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
            decoration: BoxDecoration(
              boxShadow: [BoxShadow(color: MyColor.primaryColor.withValues(alpha: 0.1), blurRadius: 10, offset: Offset(0, -10))],
              borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
              gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(width: 40, height: 4, decoration: BoxDecoration(color: MyColor.colorGrey, borderRadius: BorderRadius.circular(10))),
                ),
                SizedBox(height: Dimensions.space20),
                Text(MyStrings.filterYourTransactions.tr, style: semiBoldDefault.copyWith(fontSize: 20, color: MyColor.colorWhite)),
                SizedBox(height: Dimensions.space20),
                CustomLabelTextFiled(
                  label: MyStrings.searchByTrxId,
                  onChanged: (v) {},
                  controller: controller.trxController,
                ),
                SizedBox(height: Dimensions.space10),
                GenericDropdown<Remarks>(
                  displayItem: (item) => (item.remark?.replaceAll('_', ' ') ?? " ").toTitleCase(),
                  list: controller.remarksList,
                  onChanged: (v) {
                    if (v != null) {
                      controller.changeSelectedRemark(v);
                    }
                  },
                  selectedValue: controller.selectedRemark,
                  bgColor: MyColor.colorWhite.withValues(alpha: 0.1),
                  title: MyStrings.remarkType,
                  titleStyle: lightDefault.copyWith(color: MyColor.bodyTextColor),
                ),
                SizedBox(height: Dimensions.space10),
                GenericDropdown<String>(
                  displayItem: (item) => item.toTitleCase(),
                  list: controller.transactionTypeList,
                  onChanged: (v) {
                    if (v != null) {
                      controller.changeSelectedTrxType(v);
                    }
                  },
                  selectedValue: controller.selectedTrxType,
                  bgColor: MyColor.colorWhite.withValues(alpha: 0.1),
                  title: MyStrings.transactionType,
                  titleStyle: lightDefault.copyWith(color: MyColor.bodyTextColor),
                ),
                SizedBox(height: Dimensions.space30),
                RoundedButton(
                  text: MyStrings.submit,
                  isLoading: controller.filterLoading,
                  onTap: () {
                    controller.filterData();
                    Get.back();
                  },
                  paddingVertical: 15,
                ),
                SizedBox(height: Dimensions.space10),
              ],
            ),
          ),
          Positioned(
            top: -20,
            right: 10,
            child: GestureDetector(
              onTap: () => Get.back(),
              child: CircleIconButton(
                color: MyColor.cardBgColor,
                icon: Icon(Icons.keyboard_double_arrow_down, color: MyColor.redCancelTextColor),
              ).animate().fadeIn(delay: 100.ms, duration: 300.ms, begin: 0, curve: Curves.easeInOut),
            ),
          ),
        ],
      );
    });
  }

  Widget infoRow(String title, String value, {bool isLast = false, bool isFile = false}) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: lightDefault.copyWith(color: MyColor.bodyTextColor)),
            isFile
                ? GestureDetector(
                    onTap: () => Get.find<DepositController>().downloadAttachment(value, context),
                    child: Container(
                      alignment: Alignment.centerRight,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                      decoration: BoxDecoration(
                        color: MyColor.highPriorityPurpleColor.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
                        border: Border.all(color: MyColor.highPriorityPurpleColor, width: .5),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.file_present, color: MyColor.highPriorityPurpleColor),
                          SizedBox(width: Dimensions.space5),
                          Text(MyStrings.attachment.tr, style: lightDefault.copyWith(color: MyColor.highPriorityPurpleColor)),
                        ],
                      ),
                    ),
                  )
                : Expanded(
                    child: Text(
                      value,
                      style: regularDefault.copyWith(color: MyColor.colorWhite),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.end,
                    ),
                  ),
          ],
        ),
        if (!isLast) CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: 1, space: Dimensions.space10),
      ],
    );
  }
}
