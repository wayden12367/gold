import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/transaction/transactions_controller.dart';
import 'package:viser_gold/data/repo/transaction/transaction_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/dashboard/transaction/widget/transaction_filter_bottom_sheet.dart';
import 'package:get/get.dart';

class TransactionScreen extends StatefulWidget {
  const TransactionScreen({super.key});

  @override
  State<TransactionScreen> createState() => _TransactionScreenState();
}

class _TransactionScreenState extends State<TransactionScreen> {
  final ScrollController scrollController = ScrollController();

  void scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<TransactionsController>().hasNext()) {
        Get.find<TransactionsController>().loadTransaction();
      }
    }
  }

  @override
  void initState() {
    Get.put(TransactionRepo(apiClient: Get.find()));
    final controller = Get.put(TransactionsController(transactionRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
      scrollController.addListener(scrollListener);
    });
  }

  @override
  void dispose() {
    scrollController.removeListener(scrollListener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(
          title: MyStrings.transaction,
          isShowBackBtn: Get.previousRoute == RouteHelper.dashboardScreen && Get.currentRoute != RouteHelper.dashboardScreen,
          action: [
            ZoomTapAnimation(
              onTap: () {
                CustomBottomSheet(
                  isNeedPadding: false,
                  bgColor: MyColor.backgroundColor,
                  child: TransactionFilterBottomSheet(),
                ).show(context);
              },
              child: CircleIconButton(
                color: MyColor.colorWhite.withValues(alpha: 0.1),
                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                icon: Icon(Icons.search, size: 22, color: MyColor.colorWhite),
              ),
            ),
          ],
        ),
        body: GetBuilder<TransactionsController>(
          builder: (controller) {
            return CustomBodyContainer(
              padding: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, top: Dimensions.space15),
              child: controller.isLoading || controller.filterLoading
                  ? HistoryShimmer()
                  : controller.transactionList.isEmpty && !controller.filterLoading && !controller.filterLoading
                      ? SingleChildScrollView(child: NoDataWidget(text: MyStrings.noTransaction.tr))
                      : Column(
                          children: [
                            Expanded(
                              flex: 1,
                              child: ListView.separated(
                                controller: scrollController,
                                separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                                itemCount: controller.transactionList.length + 1,
                                itemBuilder: (context, index) {
                                  if (controller.transactionList.length == index) {
                                    return controller.hasNext() ? SizedBox(height: 40, width: MediaQuery.of(context).size.width, child: const Center(child: CustomLoader(isPagination: true))) : const SizedBox();
                                  }
                                  final transaction = controller.transactionList[index];
                                  return CustomContainer(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                                    radius: 20,
                                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.end,
                                          children: [
                                            Expanded(
                                                child: Text(
                                              transaction.trx ?? '',
                                              style: boldDefault.copyWith(fontSize: 16),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            )),
                                            SizedBox(width: Dimensions.space10),
                                            Expanded(
                                              child: Text(
                                                DateConverter.formatDate(transaction.createdAt ?? ''),
                                                style: lightDefault.copyWith(fontSize: 10, color: MyColor.bodyTextColor),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.end,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: Dimensions.space10),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: CardColumn(
                                                header: MyStrings.amount,
                                                body: "${transaction.trxType == "+" ? "+" : "-"}${controller.currencySym}${AppConverter.formatNumber(transaction.amount ?? '', precision: 2)} ${controller.currency} ",
                                                maxLine: 1,
                                                bodyTextStyle: regularDefault.copyWith(color: transaction.trxType == "+" ? MyColor.colorGreen : MyColor.colorRed, fontWeight: FontWeight.w500),
                                              ),
                                            ),
                                            Expanded(
                                                child: CardColumn(
                                              header: MyStrings.postBalance,
                                              body: "${controller.currencySym}${AppConverter.formatNumber(transaction.postBalance ?? '', precision: 2)} ${controller.currency} ",
                                              alignmentEnd: true,
                                              maxLine: 1,
                                            )),
                                          ],
                                        ),
                                        CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.1), height: 1, space: 5),
                                        CardColumn(
                                          header: MyStrings.details,
                                          body: transaction.details ?? '',
                                          maxLine: 5,
                                          bodyTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(height: Dimensions.space30),
                          ],
                        ),
            );
          },
        ),
      ),
    );
  }
}
