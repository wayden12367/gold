import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/will_pop_widget.dart';
import 'package:viser_gold/view/screens/dashboard/home/home_screen.dart';
import 'package:viser_gold/view/screens/dashboard/menu/menu_screen.dart';
import 'package:viser_gold/view/screens/dashboard/portfolio/portfolio_screen.dart';
import 'package:viser_gold/view/screens/dashboard/transaction/transaction_screen.dart';
import 'package:viser_gold/view/screens/dashboard/widget/nav_item.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int currentIndex = 0;
  List<Widget> screens = [
    HomeScreen(),
    PortfolioScreen(),
    TransactionScreen(),
    MenuScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return WillPopWidget(
      child: Scaffold(
        extendBody: true,
        backgroundColor: MyColor.backgroundColor,
        body: screens[currentIndex],
        bottomNavigationBar: CustomContainer(
          margin: const EdgeInsets.only(bottom: 17, left: 10, right: 10),
          radius: 250,
          width: MediaQuery.of(context).size.width,
          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.0), width: 0.0),
          color: MyColor.colorWhite.withValues(alpha: 0.05),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(250),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 15.3, sigmaY: 15.3),
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(250),
                  border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    NavItem(
                      title: MyStrings.home,
                      icon: MyImages.home,
                      isActive: currentIndex == 0,
                      onTap: () {
                        setState(() {
                          currentIndex = 0;
                        });
                      },
                    ),
                    NavItem(
                      title: MyStrings.portfolio,
                      icon: MyImages.menuPortfolio,
                      isActive: currentIndex == 1,
                      onTap: () {
                        setState(() {
                          currentIndex = 1;
                        });
                      },
                    ),
                    NavItem(
                      title: MyStrings.transaction,
                      icon: MyImages.menuTransaction,
                      isActive: currentIndex == 2,
                      onTap: () {
                        setState(() {
                          currentIndex = 2;
                        });
                      },
                    ),
                    NavItem(
                      title: MyStrings.settings,
                      icon: MyImages.menuMenu,
                      isActive: currentIndex == 3,
                      onTap: () {
                        setState(() {
                          currentIndex = 3;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
