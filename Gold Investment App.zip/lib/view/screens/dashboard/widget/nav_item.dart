import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class NavItem extends StatefulWidget {
  final String title;
  final String icon;
  final bool isActive;
  final VoidCallback onTap;
  const NavItem({super.key, required this.title, required this.icon, required this.isActive, required this.onTap});

  @override
  State<NavItem> createState() => _NavItemState();
}

class _NavItemState extends State<NavItem> {
  @override
  Widget build(BuildContext context) {
    return widget.isActive
        ? InkWell(
            autofocus: true,
            onTap: widget.onTap,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                
                gradient: LinearGradient(colors: [MyColor.primaryColor300.withValues(alpha: 0.15), MyColor.primaryColor960.withValues(alpha: 0.15)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                border: GradientBoxBorder(gradient: LinearGradient(colors: [MyColor.primaryColor300.withValues(alpha: 0.15), MyColor.primaryColor500.withValues(alpha: 0.15)], begin: Alignment.topCenter, end: Alignment.bottomCenter), width: 1),
                boxShadow: [
                  BoxShadow(color: MyColor.colorBlack.withValues(alpha: 0.04), blurRadius: 4, offset: Offset(0, 0)),
                  BoxShadow(color: MyColor.colorBlack.withValues(alpha: 0.08), blurRadius: 16, offset: Offset(0, 8)),
                ],
              ),
              child: Row(
                children: [
                  GradientWidget(child: SvgPicture.asset(widget.icon, color: MyColor.colorWhite)),
                  const SizedBox(width: Dimensions.space10),
                  GradientText(text: widget.title.tr, style: boldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)).animate().slideX(delay: Duration(milliseconds: 200), duration: Duration(milliseconds: 200), begin: 0.1, end: 0.0),
                ],
              ),
            ).animate().slideX(delay: Duration(milliseconds: 200), duration: Duration(milliseconds: 200), begin: 0.1, end: 0.0),
          )
        : InkWell(
            autofocus: true,
            onTap: widget.onTap,
            child: CircleIconButton(
              borderRadius: BorderRadius.circular(5),
              shape: BoxShape.rectangle,
              color: MyColor.transparentColor,
              icon: SvgPicture.asset(widget.icon, color: MyColor.iconColor),
            ),
          );
  }
}
