import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/home/home_controller.dart';
import 'package:viser_gold/data/repo/home/home_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/dashboard/portfolio/widget/card_button.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({super.key});

  @override
  State<PortfolioScreen> createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends State<PortfolioScreen> {
  @override
  void initState() {
    Get.put(HomeRepo(apiClient: Get.find()));
    final controller = Get.put(HomeController(homeRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: GetBuilder<HomeController>(builder: (controller) {
        return Scaffold(
          backgroundColor: MyColor.backgroundColor,
          appBar: CustomAppBar(title: MyStrings.portfolio, isShowBackBtn: false),
          body: Skeletonizer(
            enabled: false,
            // enabled: controller.isLoading,
            containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
            effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
            child: Container(
              padding: Dimensions.screenPadding,
              constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
              decoration: BoxDecoration(
                image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                      margin: EdgeInsets.only(right: Dimensions.space10),
                      width: MediaQuery.of(context).size.width - 30,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        image: DecorationImage(image: AssetImage(MyImages.appBarBg), fit: BoxFit.cover),
                        boxShadow: [BoxShadow(color: MyColor.cardBgColor, blurRadius: .1, offset: Offset(0, 0))],
                        border: GradientBoxBorder(width: .5, gradient: MyColor.gradientBorder),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  CircleIconButton(icon: Skeleton.replace(child: SvgPicture.asset(MyImages.wallet)), padding: EdgeInsets.all(12), borderRadius: BorderRadius.circular(10), shape: BoxShape.rectangle, color: MyColor.colorWhite.withValues(alpha: 0.1), border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 1)),
                                  const SizedBox(width: Dimensions.space5),
                                  Text(MyStrings.walletBalance.tr, style: semiBoldDefault.copyWith(fontSize: 17)),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: Dimensions.space10),
                          Text(
                            "${controller.currencySym}${AppConverter.formatNumber(controller.user.balance ?? "0.00")} ${controller.currency}",
                            style: boldDefault.copyWith(fontSize: 28),
                          ),
                          const SizedBox(height: Dimensions.space10),
                          Row(
                            children: [
                              Expanded(
                                child: CardButton(title: MyStrings.deposit, icon: Icons.download_rounded, color: MyColor.colorGreen, press: () => Get.toNamed(RouteHelper.newDepositScreen)),
                              ),
                              const SizedBox(width: Dimensions.space10),
                              Expanded(
                                child: CardButton(title: MyStrings.withdraw, icon: Icons.upload_rounded, color: MyColor.colorRed, press: () => Get.toNamed(RouteHelper.addWithdrawScreen)),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    const SizedBox(height: Dimensions.space20),
                    Text(MyStrings.totalGoldHoldings.tr, style: lightDefault.copyWith(fontSize: 17)),
                    const SizedBox(height: Dimensions.space20),
                    controller.assets.isEmpty
                        ? NoDataWidget(margin: 6, text: MyStrings.noAssetFound)
                        : GridView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: controller.assets.length,
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 2.2), // or 120/130
                              mainAxisSpacing: Dimensions.space16,
                              crossAxisSpacing: Dimensions.space15,
                            ),
                            itemBuilder: (context, index) {
                              return CustomContainer(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space10),
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                radius: 16,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space4),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 2),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Image.asset(MyImages.goldBar, height: 20, width: 20),
                                          const SizedBox(width: Dimensions.space10),
                                          Expanded(
                                            child: Text(
                                              controller.assets[index].category?.name ?? '',
                                              style: semiBoldDefault.copyWith(fontSize: 12),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: Dimensions.space5),
                                    GradientText(text: "${AppConverter.formatNumber(controller.assets[index].quantity ?? "00.00")}${MyStrings.g}", style: boldDefault.copyWith(fontSize: 22)),
                                    const SizedBox(height: Dimensions.space5),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "${MyStrings.in_.tr} ${controller.currency}",
                                          style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                                        ),
                                        Container(
                                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space5),
                                          child: Icon(Icons.arrow_right_alt, color: MyColor.bodyTextColor),
                                        ),
                                        Expanded(
                                          child: Text(
                                            "${controller.currencySym}${AppConverter.mul(controller.assets[index].category?.price ?? "0.00", controller.assets[index].quantity ?? "0.00")}",
                                            style: boldDefault.copyWith(fontSize: 12),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              );
                            },
                          )
                  ],
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}
