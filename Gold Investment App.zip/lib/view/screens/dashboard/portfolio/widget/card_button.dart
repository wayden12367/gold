import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:get/get.dart';

class CardButton extends StatelessWidget {
  final String title;
  final dynamic icon;
  final Color color;
  final VoidCallback press;
  const CardButton({
    super.key,
    required this.title,
    this.icon,
    this.color = MyColor.colorGreen,
    required this.press,
  });

  @override
  Widget build(BuildContext context) {
    return ZoomTapAnimation(
      onTap: press,
      child: CustomContainer(
        padding: EdgeInsets.only(left: Dimensions.space4, right: Dimensions.space10, top: Dimensions.space5, bottom: Dimensions.space5),
        border: Border.all(color: color),
        borderRadius: BorderRadius.circular(250),
        child: Row(
          children: [
            CircleIconButton(
              icon: Icon(icon, color: color),
              padding: EdgeInsets.all(8),
              color: MyColor.colorWhite.withValues(alpha: 0.1),
              border: Border.all(color: color),
            ),
            const SizedBox(width: Dimensions.space10),
            Expanded(
              child: Text(
                title.tr,
                style: semiBoldDefault.copyWith(fontSize: 17, color: color),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
