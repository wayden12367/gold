import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/shared_preference_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/splash/splash_controller.dart';
import 'package:viser_gold/data/repo/splash/splash_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/will_pop_widget.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class OnboardScreen extends StatefulWidget {
  const OnboardScreen({super.key});

  @override
  State<OnboardScreen> createState() => _OnboardScreenState();
}

class _OnboardScreenState extends State<OnboardScreen> {
  PageController pageController = PageController();

  int currentSlideIndex = 0;

  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(SplashRepo(apiClient: Get.find()));
    Get.put(SplashController(repo: Get.find(), localizationController: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      onBoardCompleted();
    });
  }

  void _onNextTap() {
    if (currentSlideIndex < Get.find<SplashController>().onboardData.length - 1) {
      pageController.nextPage(duration: 300.milliseconds, curve: Curves.easeInOut);
    } else {
      onBoardCompleted();
      Get.offAllNamed(RouteHelper.authenticationScreen);
    }
  }

  void _onSkipTap() {
    onBoardCompleted();
    Get.offAllNamed(RouteHelper.authenticationScreen);
  }

  void onBoardCompleted() {
    Get.find<ApiClient>().storeBoolToSF(SharedPreferenceHelper.isOnboarded, true);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopWidget(
      nextRoute: '',
      child: AnoNateWidget(
        navigationBarColor: MyColor.systemNavBarColor,
        systemNavigationBarDividerColor: MyColor.systemNavBarColor,
        child: GetBuilder<SplashController>(builder: (controller) {
          return Scaffold(
            backgroundColor: MyColor.backgroundColor,
            body: CustomBodyContainer(
              padding: EdgeInsets.zero,
              child: PageView.builder(
                controller: pageController,
                itemCount: controller.onboardData.length,
                onPageChanged: (index) {
                  setState(() {
                    currentSlideIndex = index;
                  });
                  onBoardCompleted();
                },
                itemBuilder: (context, index) => SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(30), bottomRight: Radius.circular(30)),
                            child: Opacity(
                              opacity: 0.9,
                              child: MyImageWidget(
                                imageUrl: "${UrlContainer.onboardImageUrl}/${controller.onboardData[index].dataValues?.image ?? ""}",
                                height: MediaQuery.sizeOf(context).height * 0.65,
                                width: double.infinity,
                                boxFit: BoxFit.fill,
                                radius: 0,
                              ),
                            ),
                          ),
                          SafeArea(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: List.generate(
                                controller.onboardData.length,
                                (index) => Expanded(
                                  child: AnimatedContainer(
                                    duration: 300.milliseconds,
                                    height: 10,
                                    margin: EdgeInsets.symmetric(horizontal: Dimensions.space8),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(8),
                                      color: index <= currentSlideIndex ? MyColor.primaryColor : MyColor.borderColor.withValues(alpha: 0.7),
                                      gradient: index <= currentSlideIndex ? MyColor.gradientBorder2 : null,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      SizedBox(height: Dimensions.space10),
                      Padding(
                        padding: Dimensions.screenPadding,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(
                              "${controller.onboardData[index].dataValues?.title}",
                              style: semiBoldDefault.copyWith(fontSize: 20, color: MyColor.colorWhite),
                            ),
                            Text(
                              "${controller.onboardData[index].dataValues?.description}",
                              style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
                            ),
                            SizedBox(height: Dimensions.space40),
                            RoundedButton(text: currentSlideIndex == controller.onboardData.length - 1 ? MyStrings.getStarted : MyStrings.next, onTap: _onNextTap),
                            SizedBox(height: Dimensions.space15),
                            Align(
                              alignment: Alignment.center,
                              child: InkWell(
                                onTap: _onSkipTap,
                                customBorder: CircleBorder(),
                                child: GradientText(
                                  text: MyStrings.skip,
                                  style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                                ),
                              ),
                            ),
                            SizedBox(height: Dimensions.space20),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
