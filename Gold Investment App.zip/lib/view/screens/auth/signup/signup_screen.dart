import 'package:flutter/material.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/auth/auth_controller.dart';
import 'package:viser_gold/data/model/auth/sign_up_model/sign_up_model.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/auth_text_field.dart';
import 'package:viser_gold/view/screens/auth/social_section.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  bool isAgree = false;
  bool isObscure = false;

  @override
  void initState() {
    super.initState();
    clearControllers();
  }

  void clearControllers() {
    firstNameController.clear();
    lastNameController.clear();
    emailController.clear();
    passwordController.clear();
    confirmPasswordController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: GetBuilder<AuthController>(builder: (controller) {
        return AnimatedContainer(
          duration: Duration(milliseconds: 700),
          child: Form(
            child: Column(
              children: [
                SizedBox(height: Dimensions.space30),
                Row(
                  children: [
                    Expanded(
                      child: AuthTextField(
                        label: MyStrings.firstName,
                        prefixIcon: Icon(Icons.person, color: MyColor.iconColor),
                        controller: firstNameController,
                        onChanged: (value) {},
                      ),
                    ),
                    SizedBox(width: Dimensions.space10),
                    Expanded(
                      child: AuthTextField(
                        label: MyStrings.lastName,
                        prefixIcon: Icon(Icons.person, color: MyColor.iconColor),
                        controller: lastNameController,
                        onChanged: (value) {},
                      ),
                    ),
                  ],
                ),
                SizedBox(height: Dimensions.space16),
                AuthTextField(
                  label: MyStrings.email,
                  prefixIcon: Icon(Icons.email, color: MyColor.iconColor),
                  controller: emailController,
                  onChanged: (value) {},
                ),
                SizedBox(height: Dimensions.space16),
                AuthTextField(
                  label: MyStrings.password,
                  prefixIcon: SvgPicture.asset(MyImages.lock),
                  controller: passwordController,
                  onChanged: (value) {},
                  isObscure: isObscure,
                  suffixIcon: IconButton(
                    onPressed: () {
                      setState(() {
                        isObscure = !isObscure;
                      });
                    },
                    icon: Icon(isObscure ? Icons.visibility : Icons.visibility_off, color: MyColor.iconColor),
                  ),
                ),
                SizedBox(height: Dimensions.space16),
                AuthTextField(
                  label: MyStrings.confirmPassword,
                  prefixIcon: SvgPicture.asset(MyImages.lock),
                  controller: confirmPasswordController,
                  onChanged: (value) {},
                  isObscure: true,
                ),
                SizedBox(height: Dimensions.space16),
                Visibility(
                  visible: true,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 25,
                        height: 25,
                        child: Checkbox(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.defaultRadius)),
                          activeColor: MyColor.primaryColor,
                          checkColor: MyColor.colorWhite,
                          value: isAgree,
                          side: WidgetStateBorderSide.resolveWith(
                            (states) => BorderSide(width: 1.0, color: isAgree ? MyColor.primaryColor : MyColor.borderColor),
                          ),
                          onChanged: (bool? value) {
                            setState(() {
                              isAgree = value ?? false;
                            });
                          },
                        ),
                      ),
                      const SizedBox(width: Dimensions.space8),
                      Row(
                        children: [
                          Text(MyStrings.iAgreeWith.tr, style: regularDefault.copyWith(color: MyColor.bodyTextColor)),
                          const SizedBox(width: Dimensions.space3),
                          GestureDetector(
                            onTap: () {
                              Get.toNamed(RouteHelper.privacyScreen);
                            },
                            behavior: HitTestBehavior.translucent,
                            child: Text(MyStrings.policies.tr.toLowerCase(), style: regularDefault.copyWith(color: MyColor.primaryColor, decoration: TextDecoration.underline, decorationColor: MyColor.primaryColor)),
                          ),
                          const SizedBox(width: Dimensions.space3),
                        ],
                      ),
                    ],
                  ),
                ),
                SizedBox(height: Dimensions.space16),
                RoundedButton(
                  text: MyStrings.register,
                  isLoading: controller.isSubmitLoading,
                  onTap: () {
                    if (firstNameController.text.isEmpty || lastNameController.text.isEmpty || emailController.text.isEmpty || passwordController.text.isEmpty || confirmPasswordController.text.isEmpty) {
                      CustomSnackBar.error(errorList: [MyStrings.pleaseFillAllFields]);
                      return;
                    }
                    if (emailController.text.isNotEmpty && !MyStrings.emailValidatorRegExp.hasMatch(emailController.text)) {
                      CustomSnackBar.error(errorList: [MyStrings.invalidEmailMsg]);
                      return;
                    }
                    if (!isAgree) {
                      CustomSnackBar.error(errorList: [MyStrings.agreePolicyMessage]);
                      return;
                    }
                    if (passwordController.text.toString().toLowerCase() != confirmPasswordController.text.toString().toLowerCase()) {
                      CustomSnackBar.error(errorList: [MyStrings.confirmYourPassword]);
                      return;
                    }
                    controller.registerUser(SignUpModel(
                      firstName: firstNameController.text,
                      lastName: lastNameController.text,
                      email: emailController.text,
                      password: passwordController.text,
                      agree: isAgree,
                    ));
                  },
                ),
                SizedBox(height: Dimensions.space20),
                SocialSection(isLogin: false),
                SizedBox(height: 100),
              ],
            ),
          ),
        );
      }),
    );
  }
}
