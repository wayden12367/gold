import 'dart:ui';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/auth/two_factor_controller.dart';
import 'package:viser_gold/data/controller/profile/profile_controller.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/data/repo/auth/two_factor_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_full_screen_loader.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:url_launcher/url_launcher.dart';

class TwoFactorSetupScreen extends StatefulWidget {
  const TwoFactorSetupScreen({super.key});

  @override
  State<TwoFactorSetupScreen> createState() => _TwoFactorSetupScreenState();
}

class _TwoFactorSetupScreenState extends State<TwoFactorSetupScreen> {
  String code = '';
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(TwoFactorRepo(apiClient: Get.find()));
    Get.put(ProfileRepo(apiClient: Get.find()));
    final controller = Get.put(TwoFactorController());
    final pController = Get.put(ProfileController(profileRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.get2FaCode();
      pController.loadProfileInfo();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: "Two Factor Setup", isShowBackBtn: true),
        body: GetBuilder<TwoFactorController>(builder: (controller) {
          return GetBuilder<ProfileController>(builder: (pController) {
            return controller.isLoading || pController.isLoading
                ? const FullScreenLoader(bgColor: MyColor.transparentColor, loaderColor: MyColor.primaryColor, size: 30)
                : CustomBodyContainer(
                    padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                    height: MediaQuery.of(context).size.height,
                    child: SingleChildScrollView(
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 3.5, sigmaY: 3.5),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            pController.user2faIsOne == false
                                ? SafeArea(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        if (controller.twoFactorCodeModel.data?.qrCodeUrl != null) ...[
                                          const SizedBox(height: Dimensions.space12),
                                          Center(
                                            child: Container(
                                              padding: const EdgeInsets.all(Dimensions.space10),
                                              decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(Dimensions.defaultRadius)),
                                              child: Image.network(controller.twoFactorCodeModel.data?.qrCodeUrl ?? '', width: 220, height: 220, errorBuilder: (ctx, object, trx) {
                                                return Container(width: 220, height: 220, decoration: BoxDecoration(color: MyColor.colorGrey.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(Dimensions.cardRadius)), child: const Icon(Icons.broken_image_rounded, color: MyColor.colorBlack));
                                              }),
                                            ),
                                          ),
                                          const SizedBox(height: Dimensions.space12),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(vertical: Dimensions.space10),
                                            child: Padding(
                                              padding: const EdgeInsets.all(0.8),
                                              child: DottedBorder(
                                                borderType: BorderType.RRect,
                                                color: MyColor.primaryColor,
                                                radius: const Radius.circular(Dimensions.defaultRadius),
                                                child: Container(
                                                  decoration: BoxDecoration(gradient: MyColor.gradientBorder2, borderRadius: BorderRadius.circular(Dimensions.defaultRadius - 1)),
                                                  width: double.infinity,
                                                  padding: const EdgeInsets.all(Dimensions.space15),
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    mainAxisAlignment: MainAxisAlignment.start,
                                                    children: [
                                                      Expanded(child: Text("${controller.twoFactorCodeModel.data?.secret}", style: boldDefault.copyWith(fontSize: 22))),
                                                      SizedBox(
                                                        width: 50,
                                                        height: 50,
                                                        child: GestureDetector(
                                                          onTap: () {
                                                            Clipboard.setData(ClipboardData(text: "${controller.twoFactorCodeModel.data?.secret}")).then((_) {
                                                              CustomSnackBar.success(successList: [MyStrings.copiedToClipBoard.tr], duration: 2);
                                                            });
                                                          },
                                                          child: FittedBox(
                                                            child: Padding(padding: const EdgeInsets.all(Dimensions.space5), child: Icon(Icons.copy, color: MyColor.colorWhite, size: 10)),
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: Dimensions.space15),
                                          Container(
                                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                                            decoration: BoxDecoration(
                                              color: MyColor.cardBgColor,
                                              border: Border(top: BorderSide(color: MyColor.borderColor, width: 1)),
                                              borderRadius: BorderRadius.circular(12),
                                              boxShadow: [],
                                            ),
                                            child: Column(
                                              children: [
                                                Text(MyStrings.addYourAccount.tr, style: boldDefault.copyWith(fontSize: 24, color: MyColor.colorWhite)),
                                                const SizedBox(height: Dimensions.space12),
                                                Text(MyStrings.useQRCODETips.tr, style: boldDefault.copyWith(fontSize: 12, color: MyColor.colorWhite), textAlign: TextAlign.center),
                                                const SizedBox(height: Dimensions.space12),
                                                Padding(
                                                  padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10),
                                                  child: PinCodeTextField(
                                                    appContext: context,
                                                    pastedTextStyle: regularDefault.copyWith(color: MyColor.getPrimaryColor()),
                                                    length: 6,
                                                    textStyle: regularDefault.copyWith(color: MyColor.colorWhite),
                                                    obscureText: false,
                                                    obscuringCharacter: '*',
                                                    blinkWhenObscuring: false,
                                                    animationType: AnimationType.fade,
                                                    pinTheme: PinTheme(
                                                        shape: PinCodeFieldShape.box,
                                                        borderWidth: 1,
                                                        borderRadius: BorderRadius.circular(8),
                                                        fieldHeight: 40,
                                                        fieldWidth: 40,
                                                        inactiveColor: MyColor.borderColor,
                                                        inactiveFillColor: MyColor.cardBgColor,
                                                        activeFillColor: MyColor.cardBgColor,
                                                        activeColor: MyColor.primaryColor,
                                                        selectedFillColor: MyColor.cardBgColor,
                                                        selectedColor: MyColor.primaryColor),
                                                    cursorColor: MyColor.primaryColor,
                                                    animationDuration: const Duration(milliseconds: 100),
                                                    enableActiveFill: true,
                                                    keyboardType: TextInputType.number,
                                                    beforeTextPaste: (text) {
                                                      return true;
                                                    },
                                                    onChanged: (value) {
                                                      setState(() {
                                                        code = value;
                                                      });
                                                    },
                                                  ),
                                                ),
                                                const SizedBox(height: Dimensions.space25),
                                                RoundedButton(
                                                  text: MyStrings.submit,
                                                  isLoading: controller.submitLoading,
                                                  onTap: () {
                                                    if (code.isEmpty || code.length != 6) {
                                                      CustomSnackBar.error(errorList: ["Enter your 6 digit verification code"]);
                                                      return;
                                                    }
                                                    controller.disable2fa(code);
                                                  },
                                                ),
                                                const SizedBox(height: Dimensions.space12),
                                              ],
                                            ),
                                          ),
                                          const SizedBox(height: Dimensions.space15),
                                          Container(
                                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                                            decoration: BoxDecoration(
                                              color: MyColor.cardBgColor,
                                              border: Border(top: BorderSide(color: MyColor.borderColor, width: 1)),
                                              borderRadius: BorderRadius.circular(20),
                                            ),
                                            child: Text.rich(
                                              TextSpan(
                                                children: [
                                                  TextSpan(text: MyStrings.useQRCODETips2.tr, style: regularDefault),
                                                  TextSpan(
                                                      text: ' ${MyStrings.download}',
                                                      recognizer: TapGestureRecognizer()
                                                        ..onTap = () async {
                                                          final Uri url = Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2&hl=en");

                                                          if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
                                                            throw Exception('Could not launch $url');
                                                          }
                                                        },
                                                      style: boldDefault.copyWith(color: MyColor.colorRed)),
                                                ],
                                              ),
                                            ),
                                          ),
                                          const SizedBox(height: Dimensions.space45),
                                        ]
                                      ],
                                    ),
                                  )
                                : Column(
                                    children: [
                                      SizedBox(height: MediaQuery.of(context).size.height * 0.3),
                                      Container(
                                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                                        margin: EdgeInsetsDirectional.only(top: 20),
                                        decoration: BoxDecoration(
                                          color: MyColor.cardBgColor,
                                          border: Border(top: BorderSide(color: MyColor.borderColor, width: 1)),
                                          borderRadius: BorderRadius.circular(20),
                                          boxShadow: [
                                            BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 3, offset: Offset(0, 10)),
                                            BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 3, offset: Offset(0, -10)),
                                            BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 3, offset: Offset(10, 0)),
                                            BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 3, offset: Offset(-10, 0)),
                                          ],
                                        ),
                                        child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(MyStrings.disable2Fa.tr, style: boldDefault.copyWith(fontSize: 24, color: MyColor.colorWhite)),
                                            SizedBox(height: Dimensions.space15),
                                            Text(
                                              MyStrings.twoFactorMsg.tr,
                                              style: lightDefault.copyWith(fontSize: 12, color: MyColor.colorWhite),
                                              textAlign: TextAlign.center,
                                            ),
                                            SizedBox(height: Dimensions.space40),
                                            Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10),
                                              child: PinCodeTextField(
                                                appContext: context,
                                                pastedTextStyle: regularDefault.copyWith(color: MyColor.getPrimaryColor()),
                                                length: 6,
                                                textStyle: regularDefault.copyWith(color: MyColor.colorWhite),
                                                obscureText: false,
                                                obscuringCharacter: '*',
                                                blinkWhenObscuring: false,
                                                animationType: AnimationType.fade,
                                                pinTheme: PinTheme(
                                                    shape: PinCodeFieldShape.box, borderWidth: 1, borderRadius: BorderRadius.circular(8), fieldHeight: 40, fieldWidth: 40, inactiveColor: MyColor.borderColor, inactiveFillColor: MyColor.cardBgColor, activeFillColor: MyColor.cardBgColor, activeColor: MyColor.primaryColor, selectedFillColor: MyColor.cardBgColor, selectedColor: MyColor.primaryColor),
                                                cursorColor: MyColor.primaryColor,
                                                animationDuration: const Duration(milliseconds: 100),
                                                enableActiveFill: true,
                                                keyboardType: TextInputType.number,
                                                beforeTextPaste: (text) {
                                                  return true;
                                                },
                                                onChanged: (value) {
                                                  setState(() {
                                                    code = value;
                                                  });
                                                },
                                              ),
                                            ),
                                            SizedBox(height: Dimensions.space40),
                                            RoundedButton(
                                              text: MyStrings.submit,
                                              isLoading: controller.submitLoading,
                                              onTap: () {
                                                if (code.isEmpty || code.length != 6) {
                                                  CustomSnackBar.error(errorList: ["Enter your 6 digit verification code"]);
                                                  return;
                                                }
                                                controller.disable2fa(code);
                                              },
                                            ),
                                            SizedBox(height: Dimensions.space40),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )
                          ],
                        ),
                      ),
                    ),
                  );
          });
        }),
      ),
    );
  }
}
