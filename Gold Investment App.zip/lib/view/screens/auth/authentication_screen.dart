import 'package:flutter/material.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/auth/auth_controller.dart';
import 'package:viser_gold/data/repo/auth/auth_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/will_pop_widget.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/auth/signin/signin_screen.dart';
import 'package:viser_gold/view/screens/auth/signup/signup_screen.dart';
import 'package:get/get.dart';

class AuthenticationScreen extends StatefulWidget {
  const AuthenticationScreen({super.key});

  @override
  State<AuthenticationScreen> createState() => _AuthenticationScreenState();
}

class _AuthenticationScreenState extends State<AuthenticationScreen> with TickerProviderStateMixin {
  late TabController tabController;
  int currentIndex = 0;

  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    Get.put(AuthRepo(apiClient: ApiClient(sharedPreferences: Get.find())));
    Get.put(AuthController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    bool isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;
    return WillPopWidget(
      nextRoute: '',
      child: GetBuilder<AuthController>(builder: (controller) {
        return AnoNateWidget(
          navigationBarColor: MyColor.cardBgColor,
          systemNavigationBarDividerColor: MyColor.cardBgColor,
          child: Skeletonizer(
            enabled: controller.isLoading,
            containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
            effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
            child: Scaffold(
              backgroundColor: MyColor.backgroundColor,
              body: Stack(
                children: [
                  Positioned(child: Image.asset(MyImages.authBG, fit: BoxFit.cover, height: MediaQuery.of(context).size.height / 3, width: double.infinity)),
                  Positioned.fill(
                    child: Container(
                      color: MyColor.backgroundColor.withValues(alpha: 0.1),
                      padding: Dimensions.screenPadding,
                      child: SafeArea(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Image.asset(MyImages.appLogo, width: 150),
                            SizedBox(height: Dimensions.space25),
                            Text(currentIndex == 0 ? MyStrings.loginAccount.tr : MyStrings.registerAccount.tr, style: boldDefault.copyWith(fontSize: 24, color: MyColor.colorWhite)),
                            SizedBox(height: Dimensions.space5),
                            Text(currentIndex == 0 ? MyStrings.loginSubTitle.tr : MyStrings.registerSubTitle.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                            SizedBox(height: Dimensions.space10),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(bottom: 0, left: 0, right: 0, child: SizedBox(height: MediaQuery.of(context).size.height / 3, width: double.infinity)),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20),
                    margin: EdgeInsetsDirectional.only(top: isLandscape ? 0 : (MediaQuery.of(context).size.height / 4) + 20, start: isLandscape ? Dimensions.space25 : 0, end: isLandscape ? Dimensions.space25 : 0),
                    decoration: BoxDecoration(
                      color: MyColor.cardBgColor,
                      border: Border(top: BorderSide(color: MyColor.borderColor, width: 1)),
                      borderRadius: const BorderRadius.only(topLeft: Radius.circular(Dimensions.space50 - 25), topRight: Radius.circular(Dimensions.space50 - 25)),
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: Dimensions.space20),
                        Container(
                          decoration: BoxDecoration(color: MyColor.colorBlack, borderRadius: BorderRadius.circular(30), border: Border.all(color: MyColor.borderColor, width: 1)),
                          child: TabBar(
                            controller: tabController,
                            indicator: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(24), shape: BoxShape.rectangle),
                            dividerColor: MyColor.transparentColor,
                            indicatorSize: TabBarIndicatorSize.tab,
                            labelStyle: semiBoldDefault.copyWith(fontSize: Dimensions.fontLarge),
                            unselectedLabelColor: MyColor.bodyTextColor,
                            unselectedLabelStyle: semiBoldDefault.copyWith(fontSize: Dimensions.fontLarge),
                            labelColor: MyColor.colorWhite,
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space8, vertical: Dimensions.space5),
                            indicatorPadding: EdgeInsets.zero,
                            indicatorWeight: 0,
                            labelPadding: EdgeInsets.zero,
                            onTap: (value) {
                              if (!controller.isSubmitLoading) {
                                setState(() {
                                  currentIndex = value;
                                });
                              }
                            },
                            tabs: [
                              Tab(text: MyStrings.login.tr),
                              Tab(text: MyStrings.register.tr),
                            ],
                          ),
                        ),
                        SizedBox(height: Dimensions.space10),
                        Expanded(
                          flex: 1,
                          child: currentIndex == 0 ? SigninScreen() : SignupScreen(),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      }),
    );
  }
}
