
import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/auth/sms_verification_controller.dart';
import 'package:viser_gold/data/repo/auth/sms_email_verification_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class SmsVerificationScreen extends StatefulWidget {
  const SmsVerificationScreen({super.key});

  @override
  State<SmsVerificationScreen> createState() => _SmsVerificationScreenState();
}

class _SmsVerificationScreenState extends State<SmsVerificationScreen> {
  String code = '';
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(SmsEmailVerificationRepo(apiClient: Get.find()));
    Get.put(SmsVerificationController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Get.find<SmsVerificationController>().loadBefore();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.smsVerification.tr, bgColor: MyColor.transparentColor, isShowBackBtn: true),
        body: CustomBodyContainer(
          child: GetBuilder<SmsVerificationController>(builder: (controller) {
            return Column(
              children: [
                Container(
                  padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                  decoration: BoxDecoration(
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      SizedBox(height: Dimensions.space15),
                      // Text(MyStrings.smsVerification.tr, style: boldDefault.copyWith(fontSize: 24, color: MyColor.colorWhite)),
                      // SizedBox(height: Dimensions.space15),
                      Text(
                        "${MyStrings.smsVerificationMsg.tr} ${MyUtils.maskPhoneNumber(controller.userEmail)}",
                        style: lightDefault.copyWith(fontSize: 12, color: MyColor.colorWhite),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: Dimensions.space40),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10),
                        child: PinCodeTextField(
                          appContext: context,
                          pastedTextStyle: regularDefault.copyWith(color: MyColor.getPrimaryColor()),
                          length: 6,
                          textStyle: regularDefault.copyWith(color: MyColor.colorWhite),
                          obscureText: false,
                          obscuringCharacter: '*',
                          blinkWhenObscuring: false,
                          animationType: AnimationType.fade,
                          pinTheme: PinTheme(shape: PinCodeFieldShape.box, borderWidth: 1, borderRadius: BorderRadius.circular(8), fieldHeight: 40, fieldWidth: 40, inactiveColor: MyColor.borderColor, inactiveFillColor: MyColor.cardBgColor, activeFillColor: MyColor.cardBgColor, activeColor: MyColor.primaryColor, selectedFillColor: MyColor.cardBgColor, selectedColor: MyColor.primaryColor),
                          cursorColor: MyColor.primaryColor,
                          animationDuration: const Duration(milliseconds: 100),
                          enableActiveFill: true,
                          keyboardType: TextInputType.number,
                          beforeTextPaste: (text) {
                            return true;
                          },
                          onChanged: (value) {
                            setState(() {
                              code = value;
                            });
                          },
                        ),
                      ),
                      SizedBox(height: Dimensions.space40),
                      RoundedButton(
                        text: MyStrings.verify,
                        isLoading: controller.submitLoading,
                        onTap: () {
                          if (code.isEmpty || code.length != 6) {
                            CustomSnackBar.error(errorList: ["Enter your 6 digit verification code"]);
                            return;
                          }
                          controller.verifyYourSms(code);
                        },
                      ),
                      SizedBox(height: Dimensions.space15),

                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.space30),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(MyStrings.didNotReceiveCode.tr, style: regularDefault.copyWith(color: MyColor.colorWhite)),
                            SizedBox(width: Dimensions.space5),
                            GestureDetector(
                              onTap: () {
                                if (controller.resendLoading) {
                                  return;
                                }
                                controller.sendCodeAgain();
                              },
                              child: controller.resendLoading ? CustomLoader(isPagination: true) : Text(MyStrings.resend.tr, style: regularDefault.copyWith(color: MyColor.getPrimaryColor())),
                            )
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                    ],
                  ),
                ),
              ],
            );
          }),
        ),
      ),
    );
  }
}
