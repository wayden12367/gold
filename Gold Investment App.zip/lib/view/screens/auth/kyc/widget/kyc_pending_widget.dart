import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/kyc_controller/kyc_controller.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/custom_svg_picture.dart';
import 'package:get/get.dart';

class KycPendingWidget extends StatelessWidget {
  const KycPendingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<KycController>(builder: (controller) {
      return Column(
        children: [
          SizedBox(height: MediaQuery.of(context).size.height * .2),
          CustomContainer(
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
            width: MediaQuery.of(context).size.width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CustomSvgPicture(
                  image: controller.isAlreadyPending ? MyImages.kycPendingIcon : MyImages.kycVerifiedIcon,
                  height: 100,
                  width: 100,
                  fit: BoxFit.cover,
                ),
                const SizedBox(height: 25),
                Text(controller.isAlreadyPending ? MyStrings.kycUnderReviewMsg.tr : MyStrings.kycAlreadyVerifiedMsg.tr, style: regularDefault.copyWith(color: MyColor.colorWhite, fontSize: Dimensions.fontExtraLarge)),
                const SizedBox(height: 40),
              ],
            ),
          ),
        ],
      );
    });
  }
}
