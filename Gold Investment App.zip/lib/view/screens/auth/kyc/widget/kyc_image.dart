import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';

class KycImage extends StatelessWidget {
  final String url;
  final bool? isDownload;
  const KycImage({super.key, required this.url, this.isDownload = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.defaultRadius),
        border: Border.all(color: MyColor.borderColor, width: .5),
      ),
      height: 100,
      width: 100,
      padding: EdgeInsets.all(Dimensions.space2),
      child: InteractiveViewer(
        child: CachedNetworkImage(imageUrl: url.toString()),
      ),
    );
  }
}
