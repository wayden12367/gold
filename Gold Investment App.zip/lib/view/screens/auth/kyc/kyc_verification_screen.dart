import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/kyc_controller/kyc_controller.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/data/repo/kyc/kyc_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/components/will_pop_widget.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_checkbox_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_date_time_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_file_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_radio_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_select_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_text_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_verifed_data.dart';
import 'package:get/get.dart';

class KycVerificationScreen extends StatefulWidget {
  const KycVerificationScreen({super.key});

  @override
  State<KycVerificationScreen> createState() => _KycVerificationScreenState();
}

class _KycVerificationScreenState extends State<KycVerificationScreen> {
  final formKey = GlobalKey<FormState>();

  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(KycRepo(apiClient: Get.find()));
    Get.put(KycController(repo: Get.find()));
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<KycController>().beforeInitLoadKycData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      systemNavigationBarDividerColor: MyColor.systemNavBarColor,
      child: WillPopWidget(
        nextRoute: Get.previousRoute == RouteHelper.dashboardScreen ? RouteHelper.dashboardScreen : "",
        child: Scaffold(
          backgroundColor: MyColor.backgroundColor,
          appBar: CustomAppBar(title: MyStrings.kycVerification),
          bottomNavigationBar: GetBuilder<KycController>(builder: (controller) {
            return controller.isLoading
                ? SizedBox.shrink()
                : SizedBox(
                    height: 80,
                    child: RoundedButton(
                      text: controller.isAlreadyVerified || controller.isAlreadyPending ? "Back".tr : MyStrings.submit.tr,
                      isLoading: controller.submitLoading,
                      onTap: () {
                        if (controller.isAlreadyVerified || controller.isAlreadyPending) {
                          Get.back();
                        } else {
                          if (formKey.currentState!.validate()) {
                            controller.submitKycData();
                          }
                        }
                      },
                      margin: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                    ),
                  );
          }),
          extendBody: true,
          body: Container(
            padding: Dimensions.screenPadding,
            constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
            ),
            child: GetBuilder<KycController>(
              builder: (controller) {
                return controller.isLoading
                    ? HistoryShimmer()
                    : controller.isAlreadyVerified || controller.isAlreadyPending
                        ? KycVerifiedData()
                        : Container(
                            padding: Dimensions.screenPadding,
                            child: Form(
                              key: formKey,
                              child: ListView.builder(
                                itemBuilder: (context, index) {
                                  GlobalFormModel? model = controller.formList[index];
                                  return Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      // SizedBox(height: Dimensions.space20),
                                      if (MyUtils.getTextInputType(model.type ?? 'text')) ...[
                                        KycTextAnEmailSection(
                                          onChanged: (value) {
                                            controller.changeSelectedValue(value, index);
                                          },
                                          model: model,
                                        )
                                      ] else if (model.type == "select") ...[
                                        KycSelectSection(
                                          onChanged: (value) {
                                            controller.changeSelectedValue(value, index);
                                          },
                                          model: model,
                                        )
                                      ] else if (model.type == 'radio') ...[
                                        KycRadioSection(
                                          model: model,
                                          onChanged: (selectedIndex) {
                                            controller.changeSelectedRadioBtnValue(index, selectedIndex);
                                          },
                                          selectedIndex: controller.formList[index].options?.indexOf(model.selectedValue ?? '') ?? 0,
                                        )
                                      ] else if (model.type == "checkbox") ...[
                                        KycCheckBoxSection(
                                          model: model,
                                          onChanged: (value) {
                                            controller.changeSelectedCheckBoxValue(index, value);
                                          },
                                          selectedValue: controller.formList[index].cbSelected,
                                        )
                                      ] else if (model.type == "datetime" || model.type == "date" || model.type == "time") ...[
                                        KycDateTimeSection(
                                          model: model,
                                          onChanged: (value) {
                                            controller.changeSelectedValue(value, index);
                                          },
                                          onTap: () {
                                            printX(model.type);
                                            if (model.type == "time") {
                                              controller.changeSelectedTimeOnlyValue(index, context);
                                            } else if (model.type == "date") {
                                              controller.changeSelectedDateOnlyValue(index, context);
                                            } else {
                                              controller.changeSelectedDateTimeValue(index, context);
                                            }
                                          },
                                          controller: controller.formList[index].textEditingController!,
                                        ),
                                        const SizedBox(height: Dimensions.space10),
                                      ],
                                      if (model.type == "file") ...[
                                        KycFileSection(
                                          model: model,
                                          selectedValue: controller.formList[index].selectedValue,
                                          onTap: () {
                                            controller.pickFile(index);
                                          },
                                        ),
                                        const SizedBox(height: Dimensions.space20),
                                      ],
                                    ],
                                  );
                                },
                                itemCount: controller.formList.length,
                              ),
                            ),
                          );
              },
            ),
          ),
        ),
      ),
    );
  }
}
