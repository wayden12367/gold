import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:get/get.dart';

class KycDateTimeSection extends StatelessWidget {
  GlobalFormModel model;
  Function onChanged;
  Function onTap;
  TextEditingController? controller;
  KycDateTimeSection({
    super.key,
    required this.model,
    required this.onTap,
    required this.onChanged,
    this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return CustomLabelTextFiled(
      label: model.label ?? '',
      hintText: model.name ?? '',
      instruction: model.instruction ?? '',
      controller: controller,
      keyboardType: TextInputType.datetime,
      enabled: true,
      isReadOnly: true,
      validator: (value) {
        if (model.isRequired != 'optional' && value.toString().isEmpty) {
          return '${model.name.toString().capitalizeFirst} ${MyStrings.isRequired}';
        } else {
          return null;
        }
      },
      onTap: () {
        onTap();
      },
      onChanged: (value) => onChanged(value),
    );
  }
}
