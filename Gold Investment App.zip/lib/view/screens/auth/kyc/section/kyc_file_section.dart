import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/view/components/text/label_text.dart';
import 'package:get/get.dart';

class KycFileSection extends StatefulWidget {
  final GlobalFormModel model;
  final String? selectedValue;
  final Function onTap;
  const KycFileSection({super.key, required this.model, required this.onTap, this.selectedValue});

  @override
  State<KycFileSection> createState() => _KycFileSectionState();
}

class _KycFileSectionState extends State<KycFileSection> {
  @override
  Widget build(BuildContext context) {
    logDebug(widget.model.isRequired.toString());
    return Column(
      children: [
        LabelText(text: widget.model.name ?? '', instruction: widget.model.instruction ?? '', isRequired: widget.model.isRequired == 'optional' ? false : true),
        SizedBox(height: Dimensions.space5),
        InkWell(
          onTap: () {
            widget.onTap();
          },
          child: Container(
            height: 50,
            width: MediaQuery.of(context).size.width,
            padding: const EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: 8),
            decoration: BoxDecoration(
              color: MyColor.colorWhite.withValues(alpha: 0.1),
              border: Border.all(color: MyColor.borderColor, width: 1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(padding: const EdgeInsets.all(Dimensions.space5), decoration: BoxDecoration(color: MyColor.colorBlack.withValues(alpha: 0.04), borderRadius: BorderRadius.circular(5)), alignment: Alignment.center, child: Text(MyStrings.chooseFile.tr, textAlign: TextAlign.center, style: regularDefault.copyWith(color: MyColor.primaryColor))),
                const SizedBox(width: Dimensions.space15),
                Expanded(flex: 5, child: Text(widget.selectedValue ?? MyStrings.chooseFile, style: regularDefault.copyWith())),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
