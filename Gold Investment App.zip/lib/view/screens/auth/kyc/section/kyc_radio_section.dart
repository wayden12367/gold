import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/view/components/radio/custom_radio_button.dart';
import 'package:viser_gold/view/components/text/label_text.dart';

class KycRadioSection extends StatelessWidget {
  GlobalFormModel model;
  Function onChanged;
  int selectedIndex;
  KycRadioSection({
    super.key,
    required this.model,
    required this.onChanged,
    required this.selectedIndex,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        LabelText(text: model.name ?? '', isRequired: model.isRequired == 'optional' ? false : true),
        CustomRadioButton(
          title: model.name,
          selectedIndex: selectedIndex,
          list: model.options ?? [],
          onChanged: (index) => onChanged(index),
        ),
        const SizedBox(height: Dimensions.space10),
      ],
    );
  }
}
