import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/kyc_controller/kyc_controller.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/screens/auth/kyc/widget/kyc_image.dart';
import 'package:viser_gold/view/screens/auth/kyc/widget/kyc_pending_widget.dart';
import 'package:get/get.dart';

class KycVerifiedData extends StatelessWidget {
  const KycVerifiedData({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<KycController>(builder: (controller) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          controller.pendingData.isEmpty
              ? const KycPendingWidget()
              : Expanded(
                  flex: 1,
                  child: ListView.builder(
                    itemCount: controller.pendingData.length,
                    itemBuilder: (context, index) {
                      return Container(
                        padding: const EdgeInsets.all(Dimensions.space8),
                        margin: const EdgeInsets.symmetric(vertical: Dimensions.space10),
                        decoration: BoxDecoration(
                          border: Border.all(color: MyColor.borderColor, width: .5),
                          borderRadius: BorderRadius.circular(Dimensions.defaultRadius),
                        ),
                        child: controller.pendingData[index].type == "file"
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(controller.pendingData[index].name ?? '', style: boldDefault.copyWith(fontSize: Dimensions.fontDefault)),
                                  const SizedBox(height: Dimensions.space5),
                                  GestureDetector(
                                    onTap: () {
                                      String url = "${UrlContainer.domainUrl}/${controller.path}/${controller.pendingData[index].value.toString()}";
                                      logDebug(url);
                                      if (MyUtils.isImage(controller.pendingData[index].value.toString())) {
                                        Get.toNamed(RouteHelper.previewImageScreen, arguments: url);
                                      } else {
                                        // DownloadService.downloadFile(mainUrl: url, accessToken: controller.repo.apiClient.token);
                                        controller.downloadAttachment(
                                          url: url,
                                          index: index,
                                        );
                                      }
                                    },
                                    child: MyUtils.isImage(controller.pendingData[index].value.toString())
                                        ? KycImage(
                                            url: "${UrlContainer.domainUrl}/${controller.path}/${controller.pendingData[index].value.toString()}",
                                          )
                                        : Row(
                                            children: [const Icon(Icons.file_download, size: 17, color: MyColor.primaryColor), const SizedBox(width: 12), Text(MyStrings.attachment.tr, style: regularDefault.copyWith(color: MyColor.primaryColor))],
                                          ),
                                  ),
                                ],
                              )
                            : CardColumn(
                                header: controller.pendingData[index].name ?? '',
                                body: AppConverter.removeQuotationAndSpecialCharacterFromString(controller.pendingData[index].value ?? ''),
                                headerTextStyle: boldDefault.copyWith(fontSize: Dimensions.fontDefault),
                                bodyTextStyle: regularDefault.copyWith(),
                                bodyMaxLine: 3,
                              ),
                      );
                    },
                  ),
                ),
        ],
      );
    });
  }
}
