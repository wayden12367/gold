import 'package:flutter/material.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/auth/auth_controller.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/auth_text_field.dart';
import 'package:viser_gold/view/screens/auth/social_section.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class SigninScreen extends StatefulWidget {
  const SigninScreen({super.key});

  @override
  State<SigninScreen> createState() => _SigninScreenState();
}

class _SigninScreenState extends State<SigninScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  final emailFocusNode = FocusNode();
  final passwordFocusNode = FocusNode();

  bool isObscure = true;
  final formKey = GlobalKey<FormState>();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      FocusScope.of(context).unfocus();
      emailFocusNode.unfocus();
      passwordFocusNode.unfocus();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<AuthController>(
      builder: (controller) {
        return SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: AnimatedContainer(
            duration: Duration(milliseconds: 700),
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  SizedBox(height: Dimensions.space30),
                  AuthTextField(
                    label: MyStrings.usernameOrEmail.tr,
                    prefixIcon: Icon(Icons.email, color: MyColor.iconColor),
                    controller: emailController,
                    onChanged: (value) {},
                    focusNode: emailFocusNode,
                  ),
                  SizedBox(height: Dimensions.space16),
                  AuthTextField(
                    label: MyStrings.password.tr,
                    prefixIcon: SvgPicture.asset(MyImages.lock),
                    controller: passwordController,
                    onChanged: (value) {},
                    isObscure: isObscure,
                    focusNode: passwordFocusNode,
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          isObscure = !isObscure;
                        });
                      },
                      icon: Icon(isObscure ? Icons.visibility_off : Icons.visibility, color: MyColor.iconColor),
                    ),
                  ),
                  SizedBox(height: Dimensions.space5),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(onTap: () => Get.toNamed(RouteHelper.forgetPasswordScreen), child: Text(MyStrings.forgotPassword.tr, style: regularDefault.copyWith(color: MyColor.colorRed, fontSize: 12))),
                    ],
                  ),
                  SizedBox(height: Dimensions.space16),
                  RoundedButton(
                    text: MyStrings.login.tr,
                    isLoading: controller.isSubmitLoading,
                    onTap: () {
                      if (emailController.text.isEmpty) {
                        CustomSnackBar.error(errorList: [MyStrings.enterEmailOrUserName.tr]);
                        return;
                      } else if (passwordController.text.isEmpty) {
                        CustomSnackBar.error(errorList: [MyStrings.enterYourPassword_.tr]);
                        return;
                      } else {
                        controller.loginUser(emailController.text, passwordController.text);
                      }
                    },
                  ),
                  SizedBox(height: Dimensions.space20),
                  SocialSection(isLogin: true),
                  SizedBox(height: 100),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
