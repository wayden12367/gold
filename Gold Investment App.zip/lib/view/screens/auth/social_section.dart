// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:viser_gold/data/controller/auth/social_auth_controller.dart';
import 'package:viser_gold/data/repo/auth/social_login_repo.dart';
import 'package:get/get.dart';

import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/screens/auth/widget/social_button.dart';

class SocialSection extends StatefulWidget {
  final bool isLogin;
  const SocialSection({super.key, required this.isLogin});

  @override
  State<SocialSection> createState() => _SocialSectionState();
}

class _SocialSectionState extends State<SocialSection> {
  @override
  void initState() {
    Get.put(SocialLoginRepo(apiClient: Get.find()));
    Get.put(SocialLoginController(repo: Get.find()));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SocialLoginController>(builder: (controller) {
      return controller.repo.apiClient.isAnySocialAuthEnable()
          ? Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(child: Container(height: 1, color: MyColor.borderColor)),
                    Text(widget.isLogin ? MyStrings.orLoginWith.tr : MyStrings.orRegisterWith.tr, style: lightDefault.copyWith(fontSize: Dimensions.fontLarge)),
                    Expanded(child: Container(height: 1, color: MyColor.borderColor)),
                  ],
                ),
                SizedBox(height: Dimensions.space24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (controller.repo.apiClient.isGoogleEnable()) ...[
                      SocialButton(
                        image: MyImages.google.tr,
                        title: MyStrings.google,
                        onTap: () => controller.signInWithGoogle(),
                        isLoading: controller.isGoogleSignInLoading,
                      ),
                    ],
                    if (controller.repo.apiClient.isLinkedinEnable()) ...[
                      SizedBox(width: Dimensions.space10),
                      SocialButton(
                        image: MyImages.linkedin.tr,
                        title: MyStrings.linkedin,
                        onTap: () => controller.signInWithLinkeDin(context),
                        isLoading: controller.isLinkedinSignInLoading,
                      ),
                    ],
                    if (Platform.isIOS && controller.repo.apiClient.isAppleEnable()) ...[
                      SizedBox(width: Dimensions.space10),
                      SocialButton(
                        image: MyImages.apple.tr,
                        title: MyStrings.apple,
                        onTap: () => controller.signInWithApple(),
                        isLoading: controller.isAppleSignInLoading,
                      ),
                    ]
                  ],
                )
              ],
            )
          : SizedBox();
    });
  }
}
