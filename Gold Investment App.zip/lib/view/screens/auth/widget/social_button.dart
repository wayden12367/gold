import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';

class SocialButton extends StatelessWidget {
  final String image;
  final String title;
  final bool isLoading;
  final Function() onTap;
  const SocialButton({
    super.key,
    required this.image,
    required this.title,
    required this.onTap,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return ZoomTapAnimation(
      onTap: onTap,
      child: CustomContainer(
        padding: EdgeInsets.all(Dimensions.space15),
        radius: Dimensions.space20,
        border: Border.all(color: MyColor.borderColor, width: 1),
        color: MyColor.transparentColor,
        borderRadius: BorderRadius.circular(10),
        child: isLoading ? SizedBox(height: 36, width: 36, child: SpinKitFadingCircle(color: MyColor.primaryColor, size: 20.0)) : Image.asset(image, width: Dimensions.space40, height: Dimensions.space40),
        
      ),
    );
  }
}
