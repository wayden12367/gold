import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/country_model/country_model.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:get/get.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';

class CountryBottomSheet extends StatefulWidget {
  final List<Countries> countries;
  final Function(Countries) onCountrySelected;
  const CountryBottomSheet({super.key, required this.countries, required this.onCountrySelected});

  @override
  State<CountryBottomSheet> createState() => _CountryBottomSheetState();
}

class _CountryBottomSheetState extends State<CountryBottomSheet> {
  final searchController = TextEditingController();
  List<Countries> filteredCountries = [];
  @override
  Widget build(BuildContext context) {
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 700),
            curve: Curves.easeInOut,
            width: double.infinity,
            height: MediaQuery.of(context).size.height * 0.6,
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
            decoration: BoxDecoration(
              color: MyColor.cardBgColor,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(25), topRight: Radius.circular(25)),
              border: Border(top: BorderSide(color: MyColor.borderColor, width: .5)),
              boxShadow: [BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 10, offset: Offset(0, -10))],
            ),
            child: StatefulBuilder(builder: (context, setState) {
              if (filteredCountries.isEmpty) {
                filteredCountries = widget.countries;
              }

              void filterCountries(String value) {
                filteredCountries = widget.countries.where((element) => element.country?.toLowerCase().contains(value.toLowerCase()) ?? false).toList();
                setState(() {});
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: Dimensions.space10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(child: GradientText(text: MyStrings.selectACountry.tr, style: boldDefault.copyWith(fontSize: 18, color: MyColor.colorWhite))),
                      SizedBox(width: Dimensions.space10),
                      Expanded(
                        child: CustomLabelTextFiled(
                          label: "",
                          isShowLabel: false,
                          onChanged: (value) {
                            filterCountries(value);
                          },
                          hintText: MyStrings.searchCountry.tr,
                          prefixIcon: Padding(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space10),
                            child: Icon(Icons.search, color: MyColor.colorWhite.withValues(alpha: 0.5)),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: Dimensions.space15),
                  Expanded(
                    // height: MediaQuery.of(context).size.height * 0.4,
                    child: ListView.builder(
                      itemCount: filteredCountries.length,
                      shrinkWrap: true,
                      physics: const BouncingScrollPhysics(),
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            widget.onCountrySelected(filteredCountries[index]);
                            Get.back();
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space10),
                            margin: EdgeInsets.symmetric(vertical: Dimensions.space5),
                            decoration: BoxDecoration(
                              color: MyColor.colorWhite.withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                MyImageWidget(
                                  imageUrl: UrlContainer.countryFlagImageLink.replaceAll('{countryCode}', filteredCountries[index].countryCode.toString().toLowerCase()),
                                  width: 30,
                                  height: 30,
                                ),
                                SizedBox(width: Dimensions.space10),
                                Expanded(child: Text(filteredCountries[index].country ?? "", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis)),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  
                ],
              );
            }),
          ),
          //bottom sheet closer
          Positioned(
            top: -30,
            right: 10,
            child: Padding(
              padding: const EdgeInsetsDirectional.only(),
              child: Material(
                type: MaterialType.transparency,
                child: Ink(
                  decoration: ShapeDecoration(color: MyColor.cardBgColor, shape: const CircleBorder()),
                  child: FittedBox(
                    child: IconButton(
                      padding: EdgeInsets.zero,
                      onPressed: () {
                        Get.back();
                      },
                      icon: Icon(Icons.keyboard_double_arrow_down, color: MyColor.colorRed),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
