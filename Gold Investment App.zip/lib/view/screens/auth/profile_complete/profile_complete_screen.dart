import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/profile/profile_complete_controller.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_full_screen_loader.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/auth/profile_complete/widget/country_bottom_sheet.dart';
import 'package:get/get.dart';

class ProfileCompleteScreen extends StatefulWidget {
  const ProfileCompleteScreen({super.key});

  @override
  State<ProfileCompleteScreen> createState() => _ProfileCompleteScreenState();
}

class _ProfileCompleteScreenState extends State<ProfileCompleteScreen> {
  @override
  void initState() {
    Get.put(ProfileRepo(apiClient: Get.find()));
    final controller = Get.put(ProfileCompleteController(profileRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadCountries();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileCompleteController>(builder: (controller) {
      return AnoNateWidget(
        child: Scaffold(
          // resizeToAvoidBottomInset: false,
          backgroundColor: MyColor.backgroundColor,
          body: controller.isLoading
              ? FullScreenLoader()
              : Container(
                  padding: Dimensions.screenPadding,
                  height: MediaQuery.of(context).size.height,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
                  ),
                  child: SafeArea(
                    child: SingleChildScrollView(
                      physics: BouncingScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: Dimensions.space40),
                          GradientText(text: MyStrings.profileComplete.tr, style: boldDefault.copyWith(fontSize: 24, color: MyColor.colorWhite)),
                          SizedBox(height: Dimensions.space5),
                          Text(MyStrings.profileCompleteSubText.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                          SizedBox(height: Dimensions.space40),
                          CustomContainer(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomLabelTextFiled(
                                  label: MyStrings.username.tr,
                                  onChanged: (value) {},
                                  hintText: MyStrings.enterYourUsername.tr,
                                  controller: controller.userNameController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.country.tr,
                                  onChanged: (value) {},
                                  hintText: controller.selectedCountry.country ?? MyStrings.selectACountry.tr,
                                  isReadOnly: true,
                                  suffixIcon: Container(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                    child: Icon(Icons.arrow_drop_down, color: MyColor.colorWhite.withValues(alpha: 0.5)),
                                  ),
                                  onTap: () {
                                    CustomBottomSheet(
                                      bgColor: MyColor.cardBgColor,
                                      enableDrag: true,
                                      isScrollControlled: true,
                                      isNeedPadding: false,
                                      child: CountryBottomSheet(
                                        countries: controller.countries,
                                        onCountrySelected: controller.onCountrySelected,
                                      ),
                                    ).show(context);
                                  },
                                ),
                                if (controller.selectedCountry.dialCode != "-1") ...[
                                  SizedBox(height: Dimensions.space10),
                                  CustomLabelTextFiled(
                                    label: MyStrings.mobile.tr,
                                    hintText: MyStrings.enterYourPhoneNumber.tr,
                                    onChanged: (value) {},
                                    controller: controller.phoneNoController,
                                    prefixIconConstraints: BoxConstraints(maxHeight: 80, maxWidth: 100, minWidth: 50),
                                    prefixIcon: CustomContainer(
                                      radius: 4,
                                      margin: EdgeInsets.only(right: Dimensions.space5, left: Dimensions.space10),
                                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space12, vertical: Dimensions.space5),
                                      color: MyColor.colorWhite.withValues(alpha: 0.1),
                                      border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.5), width: .5),
                                      child: FittedBox(child: Text("+${controller.selectedCountry.dialCode}", style: semiBoldDefault.copyWith(color: MyColor.bodyTextColor))),
                                    ),
                                  ),
                                ],
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.address.tr,
                                  hintText: MyStrings.enterYourAddress.tr,
                                  onChanged: (value) {},
                                  controller: controller.addressController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.state.tr,
                                  hintText: MyStrings.enterYourState.tr,
                                  onChanged: (value) {},
                                  controller: controller.stateController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.zipCode.tr,
                                  hintText: MyStrings.enterYourZipCode.tr,
                                  onChanged: (value) {},
                                  controller: controller.zipCodeController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.city.tr,
                                  hintText: MyStrings.enterYourCity.tr,
                                  onChanged: (value) {},
                                  controller: controller.cityController,
                                ),
                                SizedBox(height: Dimensions.space40),
                                RoundedButton(
                                  text: MyStrings.submit,
                                  onTap: () {
                                    if (controller.userNameController.text.isEmpty) {
                                      CustomSnackBar.error(errorList: [MyStrings.enterYourUsername]);
                                      return;
                                    }
                                    if (controller.selectedCountry.dialCode == "-1") {
                                      CustomSnackBar.error(errorList: [MyStrings.selectACountry]);
                                      return;
                                    }
                                    if (controller.phoneNoController.text.isEmpty) {
                                      CustomSnackBar.error(errorList: [MyStrings.enterYourPhoneNumber]);
                                      return;
                                    }
                                    controller.updateProfile();
                                  },
                                  isLoading: controller.submitLoading,
                                ),
                                SizedBox(height: Dimensions.space10),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
        ),
      );
    });
  }
}
