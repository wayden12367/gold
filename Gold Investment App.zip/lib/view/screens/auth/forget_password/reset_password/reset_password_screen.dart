
import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/auth/forgot_password_controller.dart';
import 'package:viser_gold/data/model/model/error_model.dart';
import 'package:viser_gold/data/repo/auth/auth_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/password_validation/validation_widget.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/auth_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();
  String? email, code;
  bool isObscure = true;
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(AuthRepo(apiClient: Get.find()));
    Get.put(ForgetPasswordController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      if (Get.arguments.isNotEmpty) {
        email = Get.arguments[0];
        code = Get.arguments[1];
        setState(() {});
      }
    });
  }

  List<ErrorModel> passwordValidationRules = [
    ErrorModel(text: MyStrings.hasUpperLetter.tr, hasError: true),
    ErrorModel(text: MyStrings.hasLowerLetter.tr, hasError: true),
    ErrorModel(text: MyStrings.hasDigit.tr, hasError: true),
    ErrorModel(text: MyStrings.hasSpecialChar.tr, hasError: true),
    ErrorModel(text: MyStrings.minSixChar.tr, hasError: true),
  ];

  void updateValidationList(String value) {
    passwordValidationRules[0].hasError = value.contains(RegExp(r'[A-Z]')) ? false : true;
    passwordValidationRules[1].hasError = value.contains(RegExp(r'[a-z]')) ? false : true;
    passwordValidationRules[2].hasError = value.contains(RegExp(r'[0-9]')) ? false : true;
    passwordValidationRules[3].hasError = value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')) ? false : true;
    passwordValidationRules[4].hasError = value.length >= 6 ? false : true;

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.resetPassword),
        body: SingleChildScrollView(
          child: CustomBodyContainer(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                  decoration: BoxDecoration(
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                  ),
                  child: GetBuilder<ForgetPasswordController>(builder: (controller) {
                    return Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        SizedBox(height: Dimensions.space15),
                        Text(MyStrings.resetPassContent.tr, style: lightDefault.copyWith(fontSize: 12, color: MyColor.colorWhite), textAlign: TextAlign.center),
                        SizedBox(height: Dimensions.space40),
                        AuthTextField(
                          label: MyStrings.password.tr,
                          prefixIcon: SvgPicture.asset(MyImages.lock),
                          controller: passwordController,
                          onChanged: (value) {
                            updateValidationList(value);
                          },
                          isObscure: isObscure,
                          suffixIcon: IconButton(
                            onPressed: () {
                              isObscure = !isObscure;
                              setState(() {});
                            },
                            icon: Icon(isObscure ? Icons.visibility : Icons.visibility_off, color: MyColor.iconColor),
                          ),
                        ),
                        Visibility(
                          visible: Get.find<ApiClient>().isStrongPassEnabled(),
                          child: ValidationWidget(list: passwordValidationRules),
                        ),
                        SizedBox(height: Dimensions.space16),
                        AuthTextField(
                          label: MyStrings.confirmPassword.tr,
                          prefixIcon: SvgPicture.asset(MyImages.lock),
                          controller: confirmPasswordController,
                          onChanged: (value) {},
                          isObscure: true,
                        ),
                        SizedBox(height: Dimensions.space40),
                        RoundedButton(
                          text: MyStrings.submit,
                          isLoading: controller.resetPasswordLoading,
                          onTap: () {
                            if (passwordController.text.isEmpty) {
                              CustomSnackBar.error(errorList: [MyStrings.enterYourPassword_.tr]);
                              return;
                            }
                            if (Get.find<ApiClient>().isStrongPassEnabled() && !MyUtils.regex.hasMatch(passwordController.text)) {
                              CustomSnackBar.error(errorList: [MyStrings.invalidPassMsg.tr]);
                              return;
                            } else {
                              if (confirmPasswordController.text != passwordController.text) {
                                CustomSnackBar.error(errorList: [MyStrings.kMatchPassError.tr]);
                                return;
                              }
                              controller.resetPassword(Get.arguments[0], passwordController.text, Get.arguments[1]);
                            }
                          },
                        ),
                        SizedBox(height: Dimensions.space10),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: Dimensions.space30),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(MyStrings.didNotReceiveCode.tr, style: regularDefault.copyWith(color: MyColor.colorWhite)),
                              SizedBox(width: Dimensions.space5),
                              GestureDetector(
                                onTap: () {
                                  if (controller.isResendLoading) {
                                    return;
                                  }
                                  controller.resendForgetPassCode(Get.arguments);
                                },
                                child: controller.isResendLoading ? CustomLoader(isPagination: true) : Text(MyStrings.resend.tr, style: regularDefault.copyWith(color: MyColor.getPrimaryColor())),
                              )
                            ],
                          ),
                        ),
                        SizedBox(height: Dimensions.space40),
                      ],
                    );
                  }),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
