
import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/auth/forgot_password_controller.dart';
import 'package:viser_gold/data/repo/auth/auth_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/auth_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class ForgetPasswordScreen extends StatefulWidget {
  const ForgetPasswordScreen({super.key});

  @override
  State<ForgetPasswordScreen> createState() => _ForgetPasswordScreenState();
}

class _ForgetPasswordScreenState extends State<ForgetPasswordScreen> {
  final emailController = TextEditingController();

  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(AuthRepo(apiClient: Get.find()));
    Get.put(ForgetPasswordController());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.forgetPassword.tr, isShowBackBtn: true, bgColor: MyColor.transparentColor),
        body: SingleChildScrollView(
          child: CustomBodyContainer(
            child: GetBuilder<ForgetPasswordController>(
              builder: (controller) {
                return Column(
                  children: [
                    SizedBox(height: MediaQuery.of(context).size.height * 0.1),
                    // Image.asset(MyImages.appLogo, height: 40),
                    // SizedBox(height: MediaQuery.of(context).size.height * 0.1),
                    Container(
                      padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                      decoration: BoxDecoration(
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: Dimensions.space15),
                          Text(
                            MyStrings.forgetPasswordSubText.tr,
                            style: lightDefault.copyWith(fontSize: 14, color: MyColor.colorWhite),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: Dimensions.space10),
                          SizedBox(height: Dimensions.space30),
                          AuthTextField(
                            label: MyStrings.usernameOrEmail.tr,
                            prefixIcon: Icon(Icons.email, color: MyColor.iconColor),
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            textInputAction: TextInputAction.done,
                            onChanged: (value) {},
                          ),
                          SizedBox(height: Dimensions.space40),
                          RoundedButton(
                            text: MyStrings.submit,
                            isLoading: controller.submitLoading,
                            onTap: () {
                              if (emailController.text.isEmpty) {
                                CustomSnackBar.error(errorList: [MyStrings.enterEmailOrUserName]);
                                return;
                              } else {
                                controller.submitForgetPassCode(emailController.text);
                              }
                            },
                          ),
                          SizedBox(height: Dimensions.space30),
                        ],
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
