import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/data/controller/splash/splash_controller.dart';
import 'package:viser_gold/data/repo/auth/general_setting_repo.dart';
import 'package:viser_gold/data/repo/splash/splash_repo.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    Get.put(SplashRepo(apiClient: Get.find()));
    Get.put(GeneralSettingRepo(apiClient: Get.find()));
    final controller = Get.put(SplashController(repo: Get.find(), localizationController: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.gotoNextPage();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      systemNavigationBarDividerColor: MyColor.cardBgColor,
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        body: Container(
          height: MediaQuery.sizeOf(context).height,
          width: MediaQuery.sizeOf(context).width,
          decoration: BoxDecoration(
            gradient: MyColor.gradientBorder2,
            image: DecorationImage(image: AssetImage(MyImages.authBG), fit: BoxFit.cover, opacity: 0.9, colorFilter: const ColorFilter.mode(Colors.black, BlendMode.dstATop)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(MyImages.appLogo, height: 200, width: 200).animate().scale(duration: 700.ms, delay: 200.ms),
            ],
          ),
        ),
      ),
    );
  }
}
