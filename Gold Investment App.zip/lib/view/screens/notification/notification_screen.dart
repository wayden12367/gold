import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/notifications/notification_controller.dart';
import 'package:viser_gold/data/repo/notification_repo/notification_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  final ScrollController scrollController = ScrollController();

  void scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<NotificationsController>().hasNext()) {
        Get.find<NotificationsController>().initData();
      }
    }
  }

  @override
  void initState() {
    Get.put(NotificationRepo(apiClient: Get.find()));
    final controller = Get.put(NotificationsController(repo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
      scrollController.addListener(scrollListener);
    });
  }

  @override
  void dispose() {
    scrollController.removeListener(scrollListener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.notification, isShowBackBtn: true),
        body: GetBuilder<NotificationsController>(builder: (controller) {
          return Container(
            padding: Dimensions.screenPadding,
            constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
            ),
            child: controller.isLoading
                ? HistoryShimmer()
                : controller.notificationList.isEmpty
                    ? NoDataWidget(text: MyStrings.noNotification.tr)
                    : ListView.separated(
                        controller: scrollController,
                        itemCount: controller.notificationList.length + 1,
                        separatorBuilder: (context, index) => SizedBox(height: Dimensions.space15),
                        itemBuilder: (context, index) {
                          if (controller.notificationList.length == index) {
                            return controller.hasNext() ? SizedBox(height: 40, width: MediaQuery.of(context).size.width, child: const Center(child: CustomLoader(isPagination: true))) : const SizedBox();
                          }
                          final data = controller.notificationList[index];
                          return CustomContainer(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                            color: MyColor.colorWhite.withValues(alpha: 0.05),
                            radius: 16,
                            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(data.subject ?? '', style: boldDefault.copyWith(fontSize: 17, color: MyColor.colorGreen)),
                                SizedBox(height: Dimensions.space8),
                                Text(data.message ?? '', style: lightDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor)),
                              ],
                            ),
                          );
                        },
                      ),
          );
        }),
      ),
    );
  }
}
