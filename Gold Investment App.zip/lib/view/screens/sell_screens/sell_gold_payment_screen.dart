import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/sell/sell_gold_controller.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/screens/sell_screens/widget/sell_gold_payment_info.dart';
import 'package:get/get.dart';

class SellGoldPaymentScreen extends StatelessWidget {
  const SellGoldPaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      margin: EdgeInsets.only(top: 300),
      padding: Dimensions.screenPadding,
      child: GetBuilder<SellGoldController>(
        builder: (controller) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: Dimensions.space5),
                SellGoldPaymentInfo(),
                SizedBox(height: Dimensions.space30),
                RoundedButton(
                  text: MyStrings.confirmSell,
                  isLoading: controller.isConfirming,
                  onTap: () => controller.confirmSell(),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
