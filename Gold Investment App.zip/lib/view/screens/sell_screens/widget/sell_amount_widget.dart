import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/sell/sell_gold_controller.dart';
import 'package:viser_gold/view/components/text_form_field/balance_text_field.dart';
import 'package:get/get.dart';

class SellAmountWidget extends StatefulWidget {
  const SellAmountWidget({super.key});

  @override
  State<SellAmountWidget> createState() => _SellAmountWidgetState();
}

class _SellAmountWidgetState extends State<SellAmountWidget> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellGoldController>(builder: (controller) {
      return Stack(
        alignment: Alignment.center,
        children: [
          Column(
            children: [
              BalanceTextField(
                onChanged: (value) {
                  printX("value>>>>>>>>>>: ${controller.sellType == AppStatus.TYPE_AMOUNT}");
                  if (controller.sellType == AppStatus.TYPE_AMOUNT) {
                    controller.calculateGram(AppConverter.formatDouble(value));
                  } else {
                    controller.calculateAmount(AppConverter.formatDouble(value));
                  }
                },
                textEditingController: controller.sellType == AppStatus.TYPE_AMOUNT ? controller.amountController : controller.gramController,
                label: controller.sellType == AppStatus.TYPE_AMOUNT ? MyStrings.enterAmount : MyStrings.gramGold,
                hintText: "0.0",
                minText: controller.sellType == AppStatus.TYPE_AMOUNT ? "${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.minAmount ?? "0")}" : null,
                isGramTextField: controller.sellType == AppStatus.TYPE_AMOUNT ? false : true,
              ),
              SizedBox(height: Dimensions.space10),
              BalanceTextField(
                textEditingController: controller.sellType == AppStatus.TYPE_AMOUNT ? controller.gramController : controller.amountController,
                label: controller.sellType == AppStatus.TYPE_AMOUNT ? MyStrings.gramGold : MyStrings.enterAmount,
                hintText: "0.0",
                onChanged: (value) {
                  if (controller.sellType == AppStatus.TYPE_AMOUNT) {
                    controller.calculateAmount(AppConverter.formatDouble(value));
                  } else {
                    controller.calculateGram(AppConverter.formatDouble(value));
                  }
                },
                isGramTextField: controller.sellType == AppStatus.TYPE_AMOUNT ? true : false,
              ),
            ],
          ),
          Positioned.fill(
            top: 15,
            child: Align(
              alignment: Alignment.center,
              child: InkWell(
                onTap: () {
                  controller.changeSellType(controller.sellType == AppStatus.TYPE_AMOUNT ? AppStatus.TYPE_GRAM : AppStatus.TYPE_AMOUNT);
                },
                radius: 100,
                borderRadius: BorderRadius.circular(24),
                splashColor: MyColor.colorWhite.withValues(alpha: 0.10),
                highlightColor: MyColor.colorWhite.withValues(alpha: 0.10),
                child: Container(
                  padding: EdgeInsets.all(Dimensions.space10),
                  decoration: BoxDecoration(
                    gradient: MyColor.gradientBorder2,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.swap_vert, color: MyColor.colorBlack, size: 24),
                ),
              ),
            ),
          )
        ],
      );
    });
  }
}
