import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/sell/sell_gold_controller.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:get/get.dart';

class SellGoldPaymentInfo extends StatelessWidget {
  const SellGoldPaymentInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SellGoldController>(builder: (controller) {
      return CustomContainer(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
        color: MyColor.colorWhite.withValues(alpha: 0.01),
        border: Border.all(color: MyColor.borderColor, width: 1),
        child: Column(
          children: [
            infoRow(MyStrings.goldCategory, "${controller.selectedGoldCategory.category?.name}"),
            SizedBox(height: Dimensions.space20),
            infoRow(MyStrings.goldQuantity, "${controller.gramController.text}${MyStrings.g.tr}"),
            SizedBox(height: Dimensions.space20),
            infoRow(MyStrings.goldValue, "${controller.currencySym}${AppConverter.formatNumber(controller.amountController.text)} ${controller.currency}"),
            SizedBox(height: Dimensions.space20),
            infoRow(MyStrings.charge, "${controller.currencySym}${controller.chargeLimit?.fixedCharge} ${controller.currency}"),
            SizedBox(height: Dimensions.space20),
            infoRow(MyStrings.totalAmount, "${controller.getTotalAmount()} ${controller.currency}"),
          ],
        ),
      );
    });
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}
