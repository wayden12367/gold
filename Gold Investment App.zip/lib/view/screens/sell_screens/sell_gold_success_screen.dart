import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/model/sell/sell_gold_sucess_response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class SellGoldSuccessScreen extends StatefulWidget {
  const SellGoldSuccessScreen({super.key});

  @override
  State<SellGoldSuccessScreen> createState() => _SellGoldSuccessScreenState();
}

class _SellGoldSuccessScreenState extends State<SellGoldSuccessScreen> {
  SellGoldSuccessData? data;

  @override
  void initState() {
    if (Get.arguments != null) {
      data = Get.arguments;
    } else {
      Get.back();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (value, result) {
        if (result == true) {}
        Get.offAllNamed(RouteHelper.dashboardScreen);
      },
      child: AnoNateWidget(
        child: Scaffold(
          backgroundColor: MyColor.backgroundColor,
          body: Container(
            padding: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, top: Dimensions.space20),
            constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: Dimensions.space40 * 2),
                  Stack(
                    children: [
                      Image.asset(MyImages.successBg),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.only(top: Dimensions.space30),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GradientWidget(
                              gradient: MyColor.textGradient,
                              child: Text.rich(
                                TextSpan(
                                  children: [
                                    TextSpan(text: AppConverter.formatNumber(data?.sellHistory?.quantity ?? "0.00", precision: 4), style: boldDefault.copyWith(fontSize: 48, fontWeight: FontWeight.w600)),
                                    TextSpan(
                                      text: MyStrings.gram.tr,
                                      style: regularDefault.copyWith(fontSize: 13),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Text(MyStrings.goldSuccessfullySold.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                            SizedBox(height: Dimensions.space10),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(MyStrings.youSpent.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                      Flexible(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: GradientWidget(
                            gradient: MyColor.textGradient,
                            child: Text.rich(
                              TextSpan(children: [
                                TextSpan(text: " ${Get.find<ApiClient>().getCurrencyOrUsername(isSymbol: true)}", style: regularDefault.copyWith(fontSize: 13)),
                                TextSpan(
                                  text: "${AppConverter.formatDouble(data?.sellHistory?.amount ?? "0.00") + AppConverter.formatDouble(data?.sellHistory?.charge ?? "0.00") + AppConverter.formatDouble(data?.sellHistory?.vat ?? "0.00")}",
                                  style: boldDefault.copyWith(fontSize: 48, fontWeight: FontWeight.w600),
                                ),
                              ]),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: Dimensions.space5),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Text(MyStrings.afterDeductingAllVatTax.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                  ),
                  SizedBox(height: Dimensions.space40),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                    decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor, width: 1)),
                    child: Column(
                      children: [
                        infoRow(
                          MyStrings.goldQuantity.tr,
                          "${AppConverter.formatNumber(data?.sellHistory?.quantity ?? "0.00", precision: 4)} ${MyStrings.gram.tr}",
                        ),
                        SizedBox(height: Dimensions.space15),
                        infoRow(
                          MyStrings.goldValue.tr,
                          "${Get.find<ApiClient>().getCurrencyOrUsername(isSymbol: true)}${AppConverter.formatNumber(data?.sellHistory?.amount ?? "0.00", precision: 2)}",
                        ),
                        SizedBox(height: Dimensions.space15),
                        infoRow(
                          MyStrings.charge,
                          "${Get.find<ApiClient>().getCurrencyOrUsername(isSymbol: true)}${AppConverter.formatNumber(data?.sellHistory?.charge ?? "0.00", precision: 2)}",
                        ),
                        SizedBox(height: Dimensions.space15),
                        CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.5), height: 3),
                        infoRow(
                          MyStrings.total.tr,
                          "${Get.find<ApiClient>().getCurrencyOrUsername(isSymbol: true)}${AppConverter.formatDouble(data?.sellHistory?.amount ?? "0.00", precision: 4) - AppConverter.formatDouble(data?.sellHistory?.charge ?? "0.00", precision: 4)} ${Get.find<ApiClient>().getCurrencyOrUsername()}",
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: Dimensions.space40),
                  RoundedButton(
                    text: MyStrings.sellAgain.tr,
                    onTap: () => Get.toNamed(RouteHelper.sellGoldScreen),
                    isOutline: true,
                  ),
                  SizedBox(height: Dimensions.space20 * 3),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}
