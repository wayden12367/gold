import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:viser_gold/data/repo/buy/buy_gold_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/buy_screens/buy_gold_payment_screen.dart';
import 'package:viser_gold/view/screens/buy_screens/widget/amount_widget.dart';
import 'package:viser_gold/view/screens/buy_screens/widget/buy_gold_catagori.dart';
import 'package:viser_gold/view/screens/buy_screens/widget/buy_gold_payment_info.dart';
import 'package:viser_gold/view/screens/buy_screens/widget/buy_gold_type.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class BuyGoldScreen extends StatefulWidget {
  const BuyGoldScreen({super.key});

  @override
  State<BuyGoldScreen> createState() => _BuyGoldScreenState();
}

class _BuyGoldScreenState extends State<BuyGoldScreen> {
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(BuyGoldRepo());
    final controller = Get.put(BuyGoldController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyGoldController>(
      builder: (controller) {
        return Skeletonizer(
          enabled: controller.isLoading,
          containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
          effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
          child: PopScope(
            canPop: false,
            onPopInvokedWithResult: (didPop, result) {
              if (didPop) return;
              if (controller.currentPage == 0) {
                Get.offAllNamed(RouteHelper.dashboardScreen);
              } else {
                controller.changePage(0);
              }
            },
            child: AnoNateWidget(
              navigationBarColor: MyColor.systemNavBarColor,
              child: CustomScaffold(
                title: controller.currentPage == 0 ? MyStrings.buyGold : MyStrings.checkOut,
                appBarHeight: controller.currentPage == 0 ? 220 : 260,
                onBack: () {
                  if (controller.currentPage == 0) {
                    Get.offAllNamed(RouteHelper.dashboardScreen);
                  } else {
                    controller.changePage(0);
                  }
                },
                actionWidget: Row(
                  children: [
                    if (controller.currentPage == 0)
                      ZoomTapAnimation(
                        onTap: () => Get.toNamed(RouteHelper.buyGoldHistoryScreen),
                        child: CircleIconButton(icon: Image.asset(MyImages.history, width: 25, height: 25, color: MyColor.colorWhite)),
                      ),
                  ],
                ),
                topForm: controller.currentPage == 0 ? BuyGoldCategory() : BuyGoldPaymentInfo(),
                body: SizedBox(
                  height: MediaQuery.of(context).size.height,
                  child: PageView.builder(
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: 2,
                    controller: controller.pageController,
                    onPageChanged: (index) {
                      //
                    },
                    itemBuilder: (context, index) {
                      return controller.currentPage == 0
                          ? SingleChildScrollView(
                              child: Container(
                                margin: EdgeInsets.only(top: 290),
                                padding: Dimensions.screenPadding,
                                child: GestureDetector(
                                  onTap: () {
                                    FocusScope.of(context).unfocus();
                                  },
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      BuyGoldType(),
                                      SizedBox(height: Dimensions.space20),
                                      BuyAmountWidget(),
                                      SizedBox(height: Dimensions.space5),
                                      Row(
                                        children: [
                                          Icon(Icons.info_sharp, color: MyColor.iconColor, size: 14),
                                          SizedBox(width: Dimensions.space5),
                                          Expanded(
                                            child: Text("${MyStrings.charge.tr}: ${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.fixedCharge ?? "0", precision: 2)} ${controller.currency} + ${AppConverter.formatNumber(controller.chargeLimit?.percentCharge ?? "0", precision: 2)}% + ${controller.chargeLimit?.vat}% ${MyStrings.vatWillBeApplicable.tr}",
                                                style: regularDefault.copyWith(color: MyColor.colorWhite, fontSize: 12), maxLines: 4, overflow: TextOverflow.ellipsis),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: Dimensions.space20 * 4),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          : BuyGoldPaymentScreen();
                    },
                  ),
                ),
                bottomWidget: controller.currentPage == 0
                    ? RoundedButton(
                        text: MyStrings.buyNow,
                        isLoading: controller.isBuyNowLoading,
                        onTap: () {
                          if (controller.isValidForCheckout()) {
                            controller.changePage(1);
                          } else {
                            CustomSnackBar.error(errorList: ["${MyStrings.minimumBuyMsg} ${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.minAmount ?? "0")} - ${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.maxAmount ?? "0")} ${controller.currency}"]);
                          }
                        },
                        margin: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, bottom: Dimensions.space5),
                        paddingVertical: Dimensions.space15,
                      )
                    : LayoutBuilder(
                        builder: (context, constraints) {
                          return SizedBox(
                            width: constraints.maxWidth,
                            height: 70,
                            child: RoundedButton(
                              text: MyStrings.proceedToPayment,
                              onTap: () {
                                controller.buyNow();
                              },
                              margin: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, bottom: Dimensions.space5),
                              paddingVertical: Dimensions.space15,
                              isLoading: controller.isBuyNowLoading,
                            ),
                          );
                        },
                      ),
                extendBody: true,
              ),
            ),
          ),
        );
      },
    );
  }
}
