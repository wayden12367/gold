import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/buy/buy_history_controller.dart';
import 'package:viser_gold/data/repo/buy/buy_gold_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class BuyGoldHistoryScreen extends StatefulWidget {
  const BuyGoldHistoryScreen({super.key});

  @override
  State<BuyGoldHistoryScreen> createState() => _BuyGoldHistoryScreenState();
}

class _BuyGoldHistoryScreenState extends State<BuyGoldHistoryScreen> {
  final ScrollController scrollController = ScrollController();

  fetchData() {
    Get.find<BuyHistoryController>().getBuyHistory();
  }

  void scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<BuyHistoryController>().hasNext()) {
        fetchData();
      }
    }
  }

  @override
  void initState() {
    Get.put(BuyGoldRepo());
    final controller = Get.put(BuyHistoryController(repo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
      scrollController.addListener(scrollListener);
    });
  }

  @override
  void dispose() {
    scrollController.removeListener(scrollListener);
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.buyHistory, isShowBackBtn: true),
        body: Container(
          padding: Dimensions.screenPadding,
          constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
            image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
          ),
          child: GetBuilder<BuyHistoryController>(builder: (controller) {
            return controller.isLoading
                ? HistoryShimmer()
                : controller.history.isEmpty && !controller.isLoading
                    ? NoDataWidget(text: MyStrings.noPurchaseFound)
                    : ListView.separated(
                        controller: scrollController,
                        addAutomaticKeepAlives: true,
                        separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                        itemCount: controller.history.length + 1,
                        itemBuilder: (context, index) {
                          if (index == controller.history.length) {
                            return controller.hasNext() ? CustomLoader(isPagination: true) : SizedBox.shrink();
                          }
                          final history = controller.history[index];
                          return CustomContainer(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                            color: MyColor.colorWhite.withValues(alpha: 0.05),
                            radius: 20,
                            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    GradientText(text: history.goldCategory?.name ?? '', style: boldDefault.copyWith(fontSize: 17)),
                                    Text(DateConverter.formatDate(history.createdAt ?? ''), style: lightDefault.copyWith(fontSize: 15, color: MyColor.bodyTextColor)),
                                  ],
                                ),
                                SizedBox(height: Dimensions.space16),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                        child: CardColumn(
                                      header: MyStrings.quantity,
                                      body: "${AppConverter.formatNumber(history.quantity ?? '0', precision: 4)} Gram",
                                      maxLine: 1,
                                      alignmentCenter: true,
                                    )),
                                    Expanded(
                                      child: CardColumn(
                                        header: MyStrings.price,
                                        body: "${controller.currencySym}${AppConverter.formatNumber(history.amount ?? '0', precision: 2)} ${controller.currency}",
                                        maxLine: 1,
                                        alignmentCenter: true,
                                      ),
                                    ),
                                    Expanded(child: CardColumn(header: MyStrings.charge, body: "${controller.currencySym}${AppConverter.formatNumber(history.charge ?? '0')}", alignmentCenter: true, maxLine: 1)),
                                  ],
                                )
                              ],
                            ),
                          );
                        },
                      );
          }),
        ),
      ),
    );
  }
}
