import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/custom_svg_picture.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/screens/buy_screens/widget/small_screen_payment_bottom_sheet_body.dart';
import 'package:get/get.dart';

class BuyGoldPaymentScreen extends StatefulWidget {
  const BuyGoldPaymentScreen({super.key});

  @override
  State<BuyGoldPaymentScreen> createState() => _BuyGoldPaymentScreenState();
}

class _BuyGoldPaymentScreenState extends State<BuyGoldPaymentScreen> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyGoldController>(builder: (controller) {
      String percentCharge = AppConverter.calculatePercentage(controller.amountController.text.toString(), controller.selectedGatewayCurrency?.percentCharge.toString() ?? "0");
      loggerX(percentCharge);
      return AnimatedContainer(
        duration: Duration(milliseconds: 700),
        height: MediaQuery.of(context).size.height,
        margin: EdgeInsets.only(top: 370),
        padding: EdgeInsets.only(top: 10, left: Dimensions.space20, right: Dimensions.space20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(MyStrings.selectPaymentMethod.tr, style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
              SizedBox(height: Dimensions.space5),
              MediaQuery.of(context).size.height > 680 ? BigScreenData() : SmallScreenData(),
              SizedBox(height: Dimensions.space20),
              Visibility(
                visible: controller.selectedGatewayCurrency?.id != -1,
                child: CustomContainer(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                  radius: 12,
                  color: MyColor.colorWhite.withValues(alpha: 0.10),
                  border: Border.all(color: MyColor.borderColor.withValues(alpha: 0.5), width: .5),
                  child: Column(
                    children: [
                      infoRow(
                        MyStrings.limit.tr,
                        "${controller.currencySym}${AppConverter.formatNumber(controller.selectedGatewayCurrency?.minAmount.toString() ?? "0")}-${AppConverter.formatNumber(controller.selectedGatewayCurrency?.maxAmount.toString() ?? "0")} ${controller.currency}",
                      ),
                      SizedBox(height: Dimensions.space15),
                      infoRow(
                        MyStrings.paymentCharge.tr,
                        "${controller.getTotalCharge()} ${controller.currency}",
                      ),
                      SizedBox(height: Dimensions.space15),
                      infoRow(
                        MyStrings.total.tr,
                        "${AppConverter.sum(AppConverter.formatNumber(controller.getTotalAmount().toString()), controller.getTotalCharge())} ${controller.currency}",
                      ),
                      if (AppConverter.formatDouble(controller.selectedGatewayCurrency?.methodCode ?? "0") < 299.00) ...[
                        SizedBox(height: Dimensions.space15),
                        infoRow(
                          MyStrings.conversionRate.tr,
                          "1 ${controller.currency} =  ${AppConverter.formatNumber(controller.selectedGatewayCurrency?.rate ?? "0.0")} ${controller.selectedGatewayCurrency?.currency}",
                        ),
                      ],
                    ],
                  ),
                ),
              ),
              SizedBox(height: Dimensions.space30 * 3),
            ],
          ),
        ),
      );
    });
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: regularDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}

class SmallScreenData extends StatelessWidget {
  const SmallScreenData({super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        CustomBottomSheet(
          isNeedPadding: false,
          bgColor: MyColor.backgroundColor,
          child: SmallScreenPaymentBottomSheetBody(),
        ).show(context);
      },
      customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: GetBuilder<BuyGoldController>(builder: (controller) {
        return CustomContainer(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
          radius: 10,
          color: MyColor.colorWhite.withValues(alpha: 0.05),
          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(Dimensions.space5),
                      decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                      child: controller.selectedGatewayCurrency?.id == -1
                          ? CustomSvgPicture(image: MyImages.wallet, width: 24, height: 24)
                          : MyImageWidget(
                              imageUrl: "${UrlContainer.domainUrl}/${controller.gatewayImagePath}/${controller.selectedGatewayCurrency?.method?.image}",
                              width: 30,
                              height: 20,
                              boxFit: BoxFit.cover,
                            ),
                    ),
                    SizedBox(width: Dimensions.space10),
                    Expanded(
                      child: Text(
                        controller.selectedGatewayCurrency?.name ?? MyStrings.selectPaymentMethod.tr,
                        style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.keyboard_arrow_down, size: 20, color: MyColor.bodyTextColor),
            ],
          ),
        );
      }),
    );
  }
}

class BigScreenData extends StatelessWidget {
  const BigScreenData({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyGoldController>(builder: (controller) {
      return SingleChildScrollView(
        child: CustomContainer(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
          height: 300,
          color: MyColor.colorWhite.withValues(alpha: 0.05),
          radius: 12,
          child: SingleChildScrollView(
            child: Column(
              children: [
                InkWell(
                  onTap: () {
                    controller.selectGatewayCurrency(MyUtils.fromWallet());
                  },
                  customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: CustomContainer(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                    radius: 10,
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(Dimensions.space5),
                                decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                child: Icon(Icons.person_2_sharp, size: 30, color: MyColor.primaryColor300),
                              ),
                              SizedBox(width: Dimensions.space10),
                              Expanded(
                                child: Text("${MyStrings.mainBalance.tr} (${controller.currencySym}${AppConverter.formatNumber(controller.user?.balance ?? "0.00")})", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ),
                            ],
                          ),
                        ),
                        Radio(
                          value: controller.selectedGatewayCurrency?.id == -1 ? true : false,
                          groupValue: true,
                          activeColor: MyColor.primaryColor,
                          fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                          onChanged: (value) {
                            controller.selectGatewayCurrency(MyUtils.fromWallet());
                          },
                          materialTapTargetSize: MaterialTapTargetSize.padded,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Column(
                  children: List.generate(
                    controller.gatewayCurrencies.length,
                    (index) => CustomContainer(
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                      margin: EdgeInsets.only(bottom: Dimensions.space10),
                      radius: 10,
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                      child: InkWell(
                        onTap: () {
                          controller.selectGatewayCurrency(controller.gatewayCurrencies[index]);
                        },
                        customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(Dimensions.space5),
                                    decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                    child: MyImageWidget(
                                      imageUrl: "${UrlContainer.domainUrl}/${controller.gatewayImagePath}/${controller.gatewayCurrencies[index].method?.image}",
                                      width: 30,
                                      height: 30,
                                      boxFit: BoxFit.cover,
                                    ),
                                  ),
                                  SizedBox(width: Dimensions.space5),
                                  Expanded(
                                    child: Text(controller.gatewayCurrencies[index].name ?? "", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                  ),
                                ],
                              ),
                            ),
                            Radio(
                              value: controller.gatewayCurrencies[index].id,
                              groupValue: controller.selectedGatewayCurrency?.id,
                              activeColor: MyColor.primaryColor,
                              fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                              onChanged: (value) {
                                controller.selectGatewayCurrency(controller.gatewayCurrencies[index]);
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    });
  }
}
