import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:get/get.dart';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:viser_gold/view/components/text_form_field/balance_text_field.dart';

class BuyAmountWidget extends StatefulWidget {
  const BuyAmountWidget({super.key});

  @override
  State<BuyAmountWidget> createState() => _BuyAmountWidgetState();
}

class _BuyAmountWidgetState extends State<BuyAmountWidget> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyGoldController>(builder: (controller) {
      return Stack(
        alignment: Alignment.center,
        children: [
          Column(
            children: [
              BalanceTextField(
                onChanged: (value) {
                  printX("value>>>>>>>>>>: ${controller.buyType == AppStatus.TYPE_AMOUNT}");
                  if (controller.buyType == AppStatus.TYPE_AMOUNT) {
                    controller.calculateGram(AppConverter.formatDouble(value));
                  } else {
                    controller.calculateAmount(AppConverter.formatDouble(value));
                  }
                },
                textEditingController: controller.buyType == AppStatus.TYPE_AMOUNT ? controller.amountController : controller.gramController,
                label: controller.buyType == AppStatus.TYPE_AMOUNT ? MyStrings.enterAmount : MyStrings.gramGold,
                hintText: "0.0",
                minText: controller.buyType == AppStatus.TYPE_AMOUNT ? "${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.minAmount ?? "0")}-${AppConverter.formatNumber(controller.chargeLimit?.maxAmount ?? "0")} ${controller.currency}" : null,
                isGramTextField: controller.buyType == AppStatus.TYPE_AMOUNT ? false : true,
              ),
              SizedBox(height: Dimensions.space10),
              BalanceTextField(
                textEditingController: controller.buyType == AppStatus.TYPE_AMOUNT ? controller.gramController : controller.amountController,
                label: controller.buyType == AppStatus.TYPE_AMOUNT ? MyStrings.gramGold : MyStrings.enterAmount,
                hintText: "0.0",
                onChanged: (value) {
                  if (controller.buyType == AppStatus.TYPE_AMOUNT) {
                    controller.calculateAmount(AppConverter.formatDouble(value));
                  } else {
                    controller.calculateGram(AppConverter.formatDouble(value));
                  }
                },
                isGramTextField: controller.buyType == AppStatus.TYPE_AMOUNT ? true : false,
              ),
            ],
          ),
          Positioned.fill(
            top: 15,
            child: Align(
              alignment: Alignment.center,
              child: InkWell(
                onTap: () {
                  controller.changeBuyType(controller.buyType == "1" ? "2" : "1");
                },
                radius: 100,
                borderRadius: BorderRadius.circular(24),
                splashColor: MyColor.colorWhite.withValues(alpha: 0.10),
                highlightColor: MyColor.colorWhite.withValues(alpha: 0.10),
                child: Container(
                  padding: EdgeInsets.all(Dimensions.space10),
                  decoration: BoxDecoration(gradient: MyColor.gradientBorder2, shape: BoxShape.circle),
                  child: Icon(Icons.swap_vert, color: MyColor.colorBlack, size: 24),
                ),
              ),
            ),
          )
        ],
      );
    });
  }
}
