import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:get/get.dart';

class BuyGoldPaymentInfo extends StatelessWidget {
  final bool isPaymentInfo;
  const BuyGoldPaymentInfo({super.key, this.isPaymentInfo = false});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: 110,
      left: 15,
      right: 15,
      child: GetBuilder<BuyGoldController>(
        builder: (controller) {
          return Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
            decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor, width: 1)),
            height: 260,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  infoRow(MyStrings.goldCategory.tr, "${controller.selectedGoldCategory.name}"),
                  SizedBox(height: Dimensions.space15),
                  infoRow(MyStrings.goldQuantity.tr, "${controller.gramController.text}g"),
                  SizedBox(height: Dimensions.space15),
                  infoRow(MyStrings.goldValue.tr, "${controller.currencySym}${AppConverter.formatNumber(controller.amountController.text)} ${controller.currency}"),
                  SizedBox(height: Dimensions.space15),
                  infoRow(MyStrings.charge.tr, "${controller.currencySym}${AppConverter.sum(controller.chargeLimit?.fixedCharge.toString() ?? "0", AppConverter.calculatePercentage(controller.amountController.text, controller.chargeLimit?.percentCharge.toString() ?? "0"))} ${controller.currency}"),
                  SizedBox(height: Dimensions.space15),
                  infoRow("${MyStrings.vat.tr} (${controller.chargeLimit?.vat}%)", "${controller.currencySym}${AppConverter.calculateVat(controller.amountController.text, controller.chargeLimit?.vat.toString() ?? "0")} ${controller.currency}"),
                  SizedBox(height: Dimensions.space15),
                  infoRow(
                    MyStrings.totalAmount.tr,
                    "${AppConverter.sum(AppConverter.formatNumber(controller.getTotalAmount().toString()), controller.getTotalCharge())} ${controller.currency}",
                    // "${controller.currencySym}${controller.getTotalAmount()} ${controller.currency}",
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: regularDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}
