import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:get/get.dart';

class SmallScreenPaymentBottomSheetBody extends StatelessWidget {
  const SmallScreenPaymentBottomSheetBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
          height: MediaQuery.of(context).size.height * 0.6,
          decoration: BoxDecoration(
            boxShadow: [BoxShadow(color: MyColor.primaryColor.withValues(alpha: 0.1), blurRadius: 10, offset: Offset(0, -10))],
            borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20)),
            gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
            image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
          ),
          child: GetBuilder<BuyGoldController>(builder: (controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(color: MyColor.colorGrey, borderRadius: BorderRadius.circular(10)),
                  ),
                ),
                SizedBox(height: Dimensions.space20),
                Text(MyStrings.paymentGateways.tr, style: semiBoldDefault.copyWith(fontSize: 18, color: MyColor.colorWhite)),
                SizedBox(height: Dimensions.space20),
                InkWell(
                  onTap: () {
                    controller.selectGatewayCurrency(MyUtils.fromWallet());
                    Get.back();
                  },
                  customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: CustomContainer(
                    width: MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                    radius: 10,
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(Dimensions.space5),
                                decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                child: Icon(Icons.person_2_sharp, size: 30, color: MyColor.primaryColor300),
                              ),
                              SizedBox(width: Dimensions.space10),
                              Expanded(
                                child: Text("${MyStrings.mainBalance.tr} (${controller.currencySym}${AppConverter.formatNumber(controller.user?.balance ?? "0.00")})", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                              ),
                            ],
                          ),
                        ),
                        Radio(
                          value: controller.selectedGatewayCurrency?.id == -1 ? true : false,
                          groupValue: true,
                          activeColor: MyColor.primaryColor,
                          fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                          onChanged: (value) {
                            controller.selectGatewayCurrency(MyUtils.fromWallet());
                            Get.back();
                          },
                          materialTapTargetSize: MaterialTapTargetSize.padded,
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: Dimensions.space10),
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.gatewayCurrencies.length,
                    physics: BouncingScrollPhysics(),
                    itemBuilder: (context, index) {
                      return CustomContainer(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                        margin: EdgeInsets.only(bottom: Dimensions.space10),
                        radius: 10,
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                        child: InkWell(
                          onTap: () {
                            controller.selectGatewayCurrency(controller.gatewayCurrencies[index]);
                            Get.back();
                          },
                          customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(Dimensions.space5),
                                      decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                      child: MyImageWidget(
                                        imageUrl: "${UrlContainer.domainUrl}/${controller.gatewayImagePath}/${controller.gatewayCurrencies[index].method?.image}",
                                        width: 30,
                                        height: 30,
                                        boxFit: BoxFit.cover,
                                      ),
                                    ),
                                    SizedBox(width: Dimensions.space5),
                                    Expanded(
                                      child: Text(controller.gatewayCurrencies[index].name ?? "", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                    ),
                                  ],
                                ),
                              ),
                              Radio(
                                value: controller.gatewayCurrencies[index].id,
                                groupValue: controller.selectedGatewayCurrency?.id,
                                activeColor: MyColor.primaryColor,
                                fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                                onChanged: (value) {
                                  controller.selectGatewayCurrency(controller.gatewayCurrencies[index]);
                                  Get.back();
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            );
          }),
        ),
        Positioned(
          top: -20,
          right: 10,
          child: GestureDetector(
            onTap: () => Get.back(),
            child: CircleIconButton(
              color: MyColor.cardBgColor,
              icon: Icon(Icons.keyboard_double_arrow_down, color: MyColor.redCancelTextColor),
            ).animate().fadeIn(delay: 100.ms, duration: 300.ms, begin: 0, curve: Curves.easeInOut),
          ),
        ),
      ],
    );
  }
}
