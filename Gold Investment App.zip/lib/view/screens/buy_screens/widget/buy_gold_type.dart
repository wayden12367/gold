import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/buy/buy_gold_controller.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:get/get.dart';

class BuyGoldType extends StatelessWidget {
  const BuyGoldType({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BuyGoldController>(builder: (controller) {
      return Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
        decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(200), border: Border.all(color: MyColor.borderColor, width: 1)),
        child: Row(
          children: [
            Expanded(
              child: InkWell(
                onTap: () {
                  controller.changeBuyType("1");
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space25, vertical: Dimensions.space8),
                  decoration: BoxDecoration(
                    color: controller.buyType == "1" ? MyColor.dropdownBgColor : MyColor.transparentColor,
                    borderRadius: BorderRadius.circular(22),
                    border: controller.buyType == "1" ? GradientBoxBorder(gradient: LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)), width: 2) : null,
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Center(
                      child: GradientText(
                        text: "${MyStrings.buyIn} ${controller.currency}",
                        style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                        gradient: controller.buyType == "1" ? LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)) : LinearGradient(colors: [MyColor.bodyTextColor, MyColor.bodyTextColor]),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: Dimensions.space10),
            Expanded(
              child: InkWell(
                onTap: () {
                  controller.changeBuyType("2");
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space25, vertical: Dimensions.space8),
                  decoration: BoxDecoration(
                    color: controller.buyType == "2" ? MyColor.dropdownBgColor : MyColor.transparentColor,
                    borderRadius: BorderRadius.circular(22),
                    border: controller.buyType == "2" ? GradientBoxBorder(gradient: LinearGradient(colors: [MyColor.primaryColor300, MyColor.primaryColor960], transform: GradientRotation(180)), width: 2) : null,
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Center(
                        child: controller.buyType == "2"
                            ? GradientText(
                                text: MyStrings.buyInQuantity,
                                style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                              )
                            : Text(
                                MyStrings.buyInQuantity.tr,
                                style: boldDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
                              )),
                  ),
                ),
              ),
            ),
       
          ],
        ),
      );
    });
  }
}
