import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:get/get.dart';

class LanguageCard extends StatelessWidget {
  final int index;
  final int selectedIndex;
  final bool isShowTopRight;
  final String langName;
  final String flag;

  const LanguageCard({super.key, required this.index, required this.selectedIndex, this.isShowTopRight = false, required this.flag, required this.langName});

  @override
  Widget build(BuildContext context) {
    return CustomContainer(
      padding: EdgeInsets.all(Dimensions.space10),
      radius: 8,
      border: Border.all(color: MyColor.primaryColor, width: .5),
      color: MyColor.cardBgColor,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(
                height: 55,
                width: 55,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: MyColor.cardBgColor, shape: BoxShape.circle),
                padding: EdgeInsets.all(Dimensions.space4),
                child: flag.isNotEmpty ? MyImageWidget(height: 60, width: 100, imageUrl: flag) : Icon(Icons.g_translate, color: MyColor.primaryColor, size: 22.5),
              ),
              const SizedBox(width: Dimensions.space10),
              Text(langName.tr, style: semiBoldDefault.copyWith(color: MyColor.textColor)),
            ],
          ),
          Container(
            height: 20,
            width: 20,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: index == selectedIndex ? MyColor.primaryColor : MyColor.transparentColor, shape: BoxShape.circle, border: index != selectedIndex ? Border.all(color: MyColor.primaryColor) : null),
            child: index == selectedIndex ? Icon(Icons.check, color: MyColor.colorWhite, size: 14) : null,
          )
        ],
      ),
    );
  }
}
