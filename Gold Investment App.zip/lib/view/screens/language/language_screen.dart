import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/localization/localization_controller.dart';
import 'package:viser_gold/data/controller/my_language_controller/my_language_controller.dart';
import 'package:viser_gold/data/repo/auth/general_setting_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/screens/language/widget/language_card.dart';
import 'package:get/get.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});

  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends State<LanguageScreen> {
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(GeneralSettingRepo(apiClient: Get.find()));
    Get.put(LocalizationController(sharedPreferences: Get.find()));
    final controller = Get.put(MyLanguageController(repo: Get.find(), localizationController: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadLanguage();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      appBar: CustomAppBar(title: MyStrings.language, isShowBackBtn: true),
      extendBody: true,
      body: CustomBodyContainer(
        child: GetBuilder<MyLanguageController>(builder: (controller) {
          return ListView.separated(
            itemCount: controller.langList.length,
            separatorBuilder: (context, index) {
              return SizedBox(height: Dimensions.space15);
            },
            itemBuilder: (context, index) {
              return GestureDetector(
                onTap: () {
                  controller.changeSelectedIndex(index);
                },
                child: LanguageCard(
                  index: index,
                  selectedIndex: controller.selectedIndex,
                  flag: "${controller.languageImagePath}/${controller.langList[index].imageUrl}",
                  langName: controller.langList[index].languageName,
                ),
              );
            },
          );
        }),
      ),
      bottomNavigationBar: GetBuilder<MyLanguageController>(builder: (controller) {
        return SizedBox(
          width: double.infinity,
          height: 110,
          child: RoundedButton(
            onTap: () {
              controller.changeLanguage(controller.selectedIndex);
            },
            text: "Continue",
            isLoading: controller.isChangeLangLoading,
            margin: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space20),
          ),
        );
      }),
    );
  }
}
