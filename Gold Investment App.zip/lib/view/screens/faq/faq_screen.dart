import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/controller/faq_controller/faq_controller.dart';
import 'package:viser_gold/data/repo/faq_repo/faq_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/faq/widget/faq_widget.dart';
import 'package:get/get.dart';

class FaqScreen extends StatefulWidget {
  const FaqScreen({super.key});

  @override
  State<FaqScreen> createState() => _FaqScreenState();
}

class _FaqScreenState extends State<FaqScreen> {
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(FaqRepo(apiClient: Get.find()));
    final controller = Get.put(FaqController(faqRepo: Get.find()));
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      appBar: CustomAppBar(title: MyStrings.faq, isShowBackBtn: true),
      body: GetBuilder<FaqController>(builder: (controller) {
        return CustomBodyContainer(
          child: controller.isLoading
              ? HistoryShimmer()
              : ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  physics: const BouncingScrollPhysics(),
                  itemCount: controller.faqList.length,
                  separatorBuilder: (context, index) => const SizedBox(height: Dimensions.space10),
                  itemBuilder: (context, index) => FaqListItem(
                      answer: (controller.faqList[index].dataValues?.answer ?? '').tr,
                      question: (controller.faqList[index].dataValues?.question ?? '').tr,
                      index: index,
                      press: () {
                        controller.changeSelectedIndex(index);
                      },
                      selectedIndex: controller.selectedIndex),
                ),
        );
      }),
    );
  }
}
