import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/custom_loader/custom_full_screen_loader.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class WebViewScreen extends StatefulWidget {
  final String url;
  const WebViewScreen({super.key, required this.url});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  InAppWebViewController? webView;
  final GlobalKey webViewKey = GlobalKey();
  bool isLoading = true;
  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        appBar: CustomAppBar(
          title: MyStrings.payNow,
          isShowBackBtn: true,
          backButtonOnPress: () {
            Get.offAllNamed(RouteHelper.dashboardScreen);
          },
        ),
        backgroundColor: MyColor.backgroundColor,
        body: Stack(
          children: [
            InAppWebView(
              key: webViewKey,
              initialUrlRequest: URLRequest(url: WebUri(widget.url)),
              onWebViewCreated: (controller) {
                webView = controller;
              },
              onLoadStart: (controller, url) {
                printX("onLoadStart: $url");
                isLoading = true;
                setState(() {});
                //check url is redirect url or not
                if (url.toString() == "${UrlContainer.domainUrl}/user/deposit/history") {
                  Get.offAllNamed(RouteHelper.dashboardScreen);
                  CustomSnackBar.success(successList: [MyStrings.requestSuccess.tr]);
                } else if (url.toString() == "${UrlContainer.domainUrl}/user/deposit") {
                  Navigator.pop(context);
                  CustomSnackBar.success(successList: [MyStrings.requestFail.tr]);
                }
              },
              onLoadStop: (controller, url) {
                printX("onLoadStop: $url");
                isLoading = false;
                setState(() {});
              },
              onReceivedServerTrustAuthRequest: (controller, challenge) async {
                return ServerTrustAuthResponse(action: ServerTrustAuthResponseAction.PROCEED);
              },
              initialSettings: InAppWebViewSettings(
                useHybridComposition: true,
                useWideViewPort: true,
                cacheEnabled: false,
              ),
            ),
            if (isLoading) ...[
              FullScreenLoader(),
            ],
          ],
        ),
      ),
    );
  }
}
