import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:get/get.dart';

class CustomScaffold extends StatelessWidget {
  final String title;
  final Widget body;
  final Widget? topForm;
  final Widget? titleWidget;
  final Widget? actionWidget;
  final double? appBarHeight;
  final BoxDecoration? bgDecoration;
  final VoidCallback? onBack;
  final Widget? bottomWidget;
  final bool? extendBody;
  const CustomScaffold({super.key, required this.body, this.topForm, required this.title, this.titleWidget, this.actionWidget, this.appBarHeight, this.bgDecoration, this.onBack, this.bottomWidget, this.extendBody});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      bottomNavigationBar: bottomWidget,
      extendBody: extendBody ?? false,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        decoration: bgDecoration ??
            BoxDecoration(
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
            ),
        child: SingleChildScrollView(
          child: Stack(
            children: [
              body,
              Stack(
                children: [
                  Container(
                    height: appBarHeight ?? 250,
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
                      color: MyColor.backgroundColor,
                    ),
                  ),
                  Container(
                    height: appBarHeight ?? 250,
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
                      gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Color.fromRGBO(0, 0, 0, 0.15), Color.fromRGBO(0, 0, 0, 0.15)]),
                      image: DecorationImage(
                        image: AssetImage(MyImages.bgSwipe),
                        fit: BoxFit.cover,
                        alignment: Alignment(-0.075, -0.99),
                        colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.8), BlendMode.dstATop),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const SizedBox(height: Dimensions.space50),
                        if (titleWidget != null) ...[
                          titleWidget!
                        ] else ...[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                children: [
                                  ZoomTapAnimation(
                                    behavior: HitTestBehavior.translucent,
                                    onTap: () {
                                      printX("onBack: $onBack");
                                      if (onBack != null) {
                                        onBack!();
                                      } else {
                                        Get.back();
                                      }
                                    },
                                    child: CircleIconButton(padding: EdgeInsets.all(Dimensions.space5), icon: Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white)),
                                  ),
                                  SizedBox(width: Dimensions.space10),
                                  Text(title.tr, style: boldDefault.copyWith(fontSize: 22, fontWeight: FontWeight.w600)),
                                ],
                              ),
                              if (actionWidget != null) ...[actionWidget!] else SizedBox.shrink(),
                            ],
                          )
                        ],
                      ],
                    ),
                  ),
                ],
              ),
              if (topForm != null) ...[
                topForm!,
              ],
            ],
          ),
        ),
      ),
    );
  }
}
