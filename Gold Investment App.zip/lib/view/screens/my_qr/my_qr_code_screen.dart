import 'dart:io';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:screenshot/screenshot.dart';

class MyQrCodeScreen extends StatefulWidget {
  const MyQrCodeScreen({super.key});

  @override
  State<MyQrCodeScreen> createState() => _MyQrCodeScreenState();
}

class _MyQrCodeScreenState extends State<MyQrCodeScreen> {
  final bool downloadLoading = false;
  ScreenshotController screenshotController = ScreenshotController();
  bool isDownloading = false;
  //
  Directory? downloadsDirectory;

  Future<bool> checkPermission() async {
    if (Platform.isAndroid) {
      await Permission.storage.request();
      downloadsDirectory = Directory('/storage/emulated/0/Download');
    } else if (Platform.isIOS) {
      downloadsDirectory = await getApplicationDocumentsDirectory();
    }
    setState(() {});
    return downloadsDirectory != null;
  }

  Future<void> saveAndShare({bool isShare = false}) async {
    if (!await checkPermission()) return;
    setState(() {});
    try {
      final downloadPath = '${downloadsDirectory?.path}/${Get.find<ApiClient>().getCurrencyOrUsername(isCurrency: false, isSymbol: false)}.png';
      final file = File(downloadPath);
      if (isShare && file.existsSync()) {
        Share.shareXFiles([XFile(downloadPath)]);
      } else {
        await screenshotController.capture().then((Uint8List? image) {
          file.writeAsBytesSync(image!);
        });
        CustomSnackBar.success(successList: ['File saved at: $downloadPath']);
        printX('File saved at: $downloadPath');
        if (isShare) {
          Share.shareXFiles([XFile(downloadPath)]);
        } else {
          await OpenFile.open(downloadPath);
        }
      }
    } catch (e) {
      if (e is PathAccessException) {
        await Permission.storage.request();
        // await saveAndShare();
      }
    } finally {
      isDownloading = false;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.myQrCode, isShowBackBtn: true),
        body: CustomBodyContainer(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: Dimensions.space30),
              CustomContainer(
                padding: const EdgeInsets.all(Dimensions.space10),
                radius: 12,
                child: Screenshot(
                  controller: screenshotController,
                  child: QrImageView(data: Get.find<ApiClient>().getCurrencyOrUsername(isCurrency: false, isSymbol: false), version: QrVersions.auto, size: MediaQuery.of(context).size.width * 0.7, backgroundColor: Colors.white),
                ),
              ),
              const SizedBox(height: Dimensions.space30),
              Padding(
                padding: const EdgeInsets.all(Dimensions.space10),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: MyColor.primaryColor, width: 0.5),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.0)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            !isDownloading ? const Icon(Icons.download_for_offline, color: MyColor.primaryColor) : const SizedBox.shrink(),
                            const SizedBox(width: Dimensions.space3),
                            Flexible(
                              child: Text(isDownloading ? "${MyStrings.downloading.tr}..." : MyStrings.download.tr, overflow: TextOverflow.ellipsis, style: regularDefault.copyWith()),
                            )
                          ],
                        ),
                        onPressed: () async {
                          isDownloading = true;
                          setState(() {});
                          await saveAndShare();
                        },
                      ),
                    ),
                    const SizedBox(width: Dimensions.space12),
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: MyColor.primaryColor, width: 0.5),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18.0),
                          ),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(Dimensions.space10),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.ios_share_rounded, color: MyColor.primaryColor),
                              const SizedBox(width: Dimensions.space3),
                              Flexible(
                                child: Text(MyStrings.share.tr, overflow: TextOverflow.ellipsis, style: regularDefault.copyWith()),
                              )
                            ],
                          ),
                        ),
                        onPressed: () {
                          saveAndShare(isShare: true);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
