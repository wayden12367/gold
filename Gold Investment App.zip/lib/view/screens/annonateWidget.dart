import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/my_color.dart';

class AnoNateWidget extends StatelessWidget {
  final Widget child;
  final Color? navigationBarColor, statusBarColor, systemNavigationBarDividerColor;
  const AnoNateWidget({super.key, required this.child, this.navigationBarColor, this.statusBarColor, this.systemNavigationBarDividerColor});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: statusBarColor ?? Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness: Brightness.light,
        systemNavigationBarColor: navigationBarColor ?? MyColor.backgroundColor,
        systemNavigationBarIconBrightness: Brightness.light,
        systemNavigationBarDividerColor: systemNavigationBarDividerColor ?? MyColor.systemNavBarColor,
        systemNavigationBarContrastEnforced: false,
      ),
      child: child,
    );
  }
}
