import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/profile/profile_controller.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    Get.put(ProfileRepo(apiClient: Get.find()));
    final controller = Get.put(ProfileController(profileRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadProfileInfo();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileController>(builder: (controller) {
      return AnoNateWidget(
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: MyColor.backgroundColor,
          extendBody: true,
          appBar: CustomAppBar(
            title: MyStrings.profile.tr,
            isShowBackBtn: true,
            action: [],
          ),
          body: Container(
            padding: EdgeInsets.only(left: Dimensions.space15, right: Dimensions.space15, top: Dimensions.space15),
            height: MediaQuery.of(context).size.height,
            width: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
            ),
            child: SafeArea(
              child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Skeletonizer(
                  enabled: controller.isLoading,
                  containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
                  effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(height: Dimensions.space10),
                      CustomContainer(
                        width: double.infinity,
                        border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 20,
                                    backgroundColor: MyColor.transparentColor,
                                    child: MyImageWidget(imageUrl: controller.imageUrl, isProfile: true, radius: 20, height: 40, width: 40),
                                  ),
                                  const SizedBox(width: Dimensions.space10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text(controller.user.username ?? '', style: boldDefault.copyWith(fontSize: 17, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                                        Text(controller.user.email ?? '', style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                      ],
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(width: Dimensions.space10),
                            ZoomTapAnimation(
                              onTap: () => Get.toNamed(RouteHelper.editProfileScreen),
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space5),
                                decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: controller.isVerifiedUser() ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                child: Text(MyStrings.editProfile, style: boldDefault.copyWith(fontSize: 13, color: controller.isVerifiedUser() ? MyColor.colorGreen : MyColor.colorRed)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                      CustomContainer(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space10),
                        radius: 8,
                        color: MyColor.transparentColor,
                        border: Border.all(color: Colors.black12, width: 0.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(MyStrings.verification.tr, style: lightDefault.copyWith(fontSize: 22, color: MyColor.bodyTextColor)),
                            SizedBox(height: Dimensions.space10),
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              physics: BouncingScrollPhysics(),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space8),
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: controller.isVerified(isEmail: true) ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                    child: Row(
                                      children: [
                                        Icon(Icons.verified_user_outlined, size: 20, color: controller.isVerified(isEmail: true) ? MyColor.colorGreen : MyColor.colorRed),
                                        SizedBox(width: Dimensions.space10),
                                        Text(MyStrings.email.tr, style: boldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: Dimensions.space10),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space8),
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: controller.isVerified(isMobile: true) ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.verified_user_outlined, size: 20, color: controller.isVerified(isMobile: true) ? MyColor.colorGreen : MyColor.colorRed),
                                        SizedBox(width: Dimensions.space10),
                                        Text(MyStrings.mobile.tr, style: boldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: Dimensions.space10),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space8),
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: controller.isVerified(isKYC: true) ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.verified_user_outlined, size: 20, color: controller.isVerified(isKYC: true) ? MyColor.colorGreen : MyColor.colorRed),
                                        SizedBox(width: Dimensions.space10),
                                        Text(MyStrings.kyc.tr, style: boldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)),
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: Dimensions.space10),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space8),
                                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: controller.isVerified(isTwoFactor: true) ? MyColor.colorGreen.withValues(alpha: 0.3) : MyColor.colorRed.withValues(alpha: 0.3)),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Icon(Icons.verified_user_outlined, size: 20, color: controller.isVerified(isTwoFactor: true) ? MyColor.colorGreen : MyColor.colorRed),
                                        SizedBox(width: Dimensions.space10),
                                        Text("Two Factor".tr, style: boldDefault.copyWith(fontSize: 13, color: MyColor.colorWhite)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                      CustomContainer(
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            titleWidget(MyStrings.firstName.tr, (controller.user.firstname ?? '').toCapitalized()),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.lastName.tr, (controller.user.lastname ?? '').toCapitalized()),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.country.tr, (controller.user.countryName ?? '').toCapitalized()),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.phoneNo.tr, controller.user.mobile ?? ''),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.address.tr, controller.user.address ?? ''),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.state.tr, controller.user.state ?? ''),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.zipCode.tr, controller.user.zip ?? ''),
                            SizedBox(height: Dimensions.space10),
                            titleWidget(MyStrings.city.tr, controller.user.city ?? ''),
                            SizedBox(height: Dimensions.space10),
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  Widget titleWidget(String title, String value) {
    return CustomContainer(
      radius: Dimensions.cardRadius,
      width: double.infinity,
      border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
      color: MyColor.colorWhite.withValues(alpha: 0.1),
      child: CardColumn(
        header: title,
        body: value,
        headerTextStyle: lightDefault.copyWith(fontSize: Dimensions.fontDefault, color: MyColor.bodyTextColor),
        bodyTextStyle: semiBoldDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor),
      ),
    );
  }
}
