import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/profile/profile_controller.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  @override
  void initState() {
    Get.put(ProfileRepo(apiClient: Get.find()));
    final controller = Get.put(ProfileController(profileRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      // controller
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileController>(
      builder: (controller) {
        return AnoNateWidget(
          child: StatefulBuilder(builder: (context, setState) {
            return Scaffold(
              resizeToAvoidBottomInset: false,
              backgroundColor: MyColor.backgroundColor,
              appBar: CustomAppBar(title: MyStrings.profile.tr, isShowBackBtn: true),
              body: Container(
                padding: Dimensions.screenPadding,
                height: MediaQuery.of(context).size.height,
                width: double.infinity,
                decoration: BoxDecoration(
                  image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
                ),
                child: SafeArea(
                  child: SingleChildScrollView(
                    physics: BouncingScrollPhysics(),
                    child: Skeletonizer(
                      enabled: controller.isLoading,
                      containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
                      effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(height: Dimensions.space10),
                          CustomContainer(
                            width: double.infinity,
                            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 0.0),
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                            color: MyColor.colorWhite.withValues(alpha: 0.05),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Stack(
                                  children: [
                                    if (controller.imageFile != null) ...[
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(50),
                                        child: Image.file(
                                          controller.imageFile!,
                                          fit: BoxFit.cover,
                                          height: 100,
                                          width: 100,
                                        ),
                                      )
                                    ] else
                                      MyImageWidget(imageUrl: controller.imageUrl, isProfile: true, radius: 50, height: 100, width: 100),
                                    Positioned.fill(
                                      child: GestureDetector(
                                        onTap: () {
                                          controller.uploadImage();
                                        },
                                        child: Container(
                                          padding: EdgeInsets.all(Dimensions.space10),
                                          decoration: BoxDecoration(color: MyColor.primaryColor.withValues(alpha: 0.3), shape: BoxShape.circle),
                                          child: Icon(Icons.camera_alt, color: MyColor.colorWhite),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: Dimensions.space10),
                                Text(controller.user.username ?? '', style: boldDefault.copyWith(fontSize: 26, fontWeight: FontWeight.w600)),
                                Text(controller.user.email ?? '', style: lightDefault.copyWith(fontSize: 17, color: MyColor.bodyTextColor)),
                              ],
                            ),
                          ),
                          SizedBox(height: Dimensions.space20),
                          CustomContainer(
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CustomLabelTextFiled(
                                  label: MyStrings.firstName.tr,
                                  onChanged: (value) {},
                                  hintText: controller.user.firstname ?? '',
                                  controller: controller.firstNameController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.lastName.tr,
                                  onChanged: (value) {},
                                  hintText: controller.user.lastname ?? '',
                                  controller: controller.lastNameController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.address.tr,
                                  hintText: controller.user.address ?? '',
                                  onChanged: (value) {},
                                  controller: controller.addressController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.state.tr,
                                  hintText: controller.user.state ?? '',
                                  onChanged: (value) {},
                                  controller: controller.stateController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.zipCode.tr,
                                  hintText: controller.user.zip ?? '',
                                  onChanged: (value) {},
                                  controller: controller.zipCodeController,
                                ),
                                SizedBox(height: Dimensions.space10),
                                CustomLabelTextFiled(
                                  label: MyStrings.city.tr,
                                  hintText: controller.user.city ?? '',
                                  onChanged: (value) {},
                                  controller: controller.cityController,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: Dimensions.space30),
                          RoundedButton(
                            text: MyStrings.submit,
                            isLoading: controller.isSubmitLoading,
                            onTap: () {
                              controller.updateProfile();
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
