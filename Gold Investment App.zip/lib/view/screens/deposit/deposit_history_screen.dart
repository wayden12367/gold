import 'package:custom_refresh_indicator/custom_refresh_indicator.dart';
import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/deposit/deposit_history_controller.dart';
import 'package:viser_gold/data/repo/deposit/deposit_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/deposit/widget/deposit_filter_bottom_sheet.dart';
import 'package:viser_gold/view/screens/deposit/widget/deposit_history_bottom_sheet.dart';
import 'package:get/get.dart';

class DepositHistoryScreen extends StatefulWidget {
  const DepositHistoryScreen({super.key});

  @override
  State<DepositHistoryScreen> createState() => _DepositHistoryScreenState();
}

class _DepositHistoryScreenState extends State<DepositHistoryScreen> {
  final ScrollController scrollController = ScrollController();

  fetchData() {
    Get.find<DepositController>().fetchNewList();
  }

  void _scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<DepositController>().hasNext()) {
        fetchData();
      }
    }
  }

  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(DepositRepo(apiClient: Get.find()));
    final controller = Get.put(DepositController(depositRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.beforeInitLoadData();
      scrollController.addListener(_scrollListener);
    });
  }

  @override
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      navigationBarColor: MyColor.systemNavBarColor,
      child: GetBuilder<DepositController>(
        builder: (controller) {
          return Scaffold(
            backgroundColor: MyColor.backgroundColor,
            appBar: CustomAppBar(
              title: MyStrings.depositHistory,
              paddingVertical: 10,
              isShowBackBtn: true,
              action: [
                Row(
                  children: [
                    ZoomTapAnimation(
                      onTap: () {
                        controller.clearFilter();
                        CustomBottomSheet(isNeedPadding: false, bgColor: MyColor.backgroundColor, child: DepositFilterBottomSheet()).show(context);
                      },
                      child: CircleIconButton(
                        icon: Icon(Icons.search, size: 20, color: MyColor.colorWhite),
                        color: MyColor.colorWhite.withValues(alpha: 0.1),
                        border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                      ),
                    ),
                    if (Get.previousRoute == RouteHelper.dashboardScreen) ...[
                      SizedBox(width: Dimensions.space10),
                      ZoomTapAnimation(
                        onTap: () {
                          Get.toNamed(RouteHelper.newDepositScreen);
                        },
                        child: CircleIconButton(
                          icon: Icon(Icons.add, size: 20, color: MyColor.colorWhite),
                          color: MyColor.colorWhite.withValues(alpha: 0.1),
                          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                        ),
                      ),
                    ],
                  ],
                )
              ],
            ),
            body: CustomMaterialIndicator(
              onRefresh: () async {
                controller.beforeInitLoadData();
              },
              indicatorBuilder: (context, controller) {
                return CustomContainer(
                  padding: const EdgeInsets.all(6.0),
                  child: controller.state.isLoading ? SizedBox() : Image.asset(MyImages.goldBar),
                );
              },
              //    color: MyColor.primaryColor,
              backgroundColor: MyColor.backgroundColor,
              child: CustomBodyContainer(
                child: controller.isLoading || controller.searchLoading
                    ? HistoryShimmer()
                    : controller.depositList.isEmpty && !controller.searchLoading && !controller.isLoading
                        ? SingleChildScrollView(
                            physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                            child: NoDataWidget(text: MyStrings.noDepositHistoryFound.tr),
                          )
                        : ListView.separated(
                            controller: scrollController,
                            physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                            separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                            itemCount: controller.depositList.length + 1,
                            itemBuilder: (context, index) {
                              if (controller.depositList.length == index) {
                                return controller.hasNext() ? SizedBox(height: 40, width: MediaQuery.of(context).size.width, child: const Center(child: CustomLoader())) : const SizedBox();
                              }
                              final transaction = controller.depositList[index];
                              final isAutomated = AppConverter.formatDouble(transaction.methodCode ?? '0').toInt() < 1000;
                              return CustomContainer(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space15),
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                radius: 20,
                                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                transaction.gateway?.name ?? '',
                                                style: boldDefault.copyWith(fontSize: 15, color: MyColor.highPriorityPurpleColor),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              Text(
                                                transaction.trx ?? '',
                                                style: regularDefault.copyWith(),
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: Dimensions.space10),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Container(
                                              padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                              decoration: BoxDecoration(
                                                color: AppStatus.getDepositStatusColor(transaction.status ?? '').withValues(alpha: 0.1),
                                                borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
                                                border: Border.all(color: AppStatus.getDepositStatusColor(transaction.status ?? ''), width: .5),
                                              ),
                                              child: Text(
                                                AppStatus.getDepositStatus(transaction.status ?? '').tr,
                                                style: regularDefault.copyWith(
                                                  fontSize: 12,
                                                  color: AppStatus.getDepositStatusColor(transaction.status ?? ''),
                                                ),
                                              ),
                                            ),
                                            SizedBox(height: Dimensions.space5),
                                            Text(
                                              DateConverter.formatDate(transaction.createdAt ?? ''),
                                              style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                            child: CardColumn(
                                          header: MyStrings.charge,
                                          body: "${controller.curSymbol}${AppConverter.formatNumber(transaction.charge ?? '')} ${controller.currency}",
                                          maxLine: 1,
                                        )),
                                        Expanded(
                                          child: CardColumn(
                                            alignmentEnd: true,
                                            header: MyStrings.amount,
                                            body: "${controller.curSymbol}${AppConverter.formatNumber(transaction.amount ?? '')} ${controller.currency}",
                                            maxLine: 1,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                            child: CardColumn(
                                          header: MyStrings.finalAmount,
                                          body: "${controller.curSymbol}${AppConverter.formatNumber(transaction.finalAmo ?? '')} ${controller.currency}",
                                          maxLine: 1,
                                        )),
                                        ZoomTapAnimation(
                                          onTap: () {
                                            if (!isAutomated) {
                                              CustomBottomSheet(
                                                isNeedPadding: false,
                                                bgColor: MyColor.backgroundColor,
                                                child: DepositHistoryBottomSheet(index: index),
                                              ).show(context);
                                            }
                                          },
                                          child: Container(
                                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                            decoration: BoxDecoration(
                                              color: MyColor.colorWhite.withValues(alpha: 0.1),
                                              borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
                                              border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                            ),
                                            child: Text(
                                              isAutomated ? MyStrings.automated.tr : MyStrings.details.tr,
                                              style: regularDefault.copyWith(
                                                fontSize: 12,
                                                color: MyColor.colorWhite,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                  ],
                                ),
                              );
                            },
                          ),
              ),
            ),
          );
        },
      ),
    );
  }
}
