import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/deposit/add_new_deposit_controller.dart';
import 'package:viser_gold/data/repo/deposit/deposit_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/divider/custom_divider.dart';
import 'package:viser_gold/view/components/image/custom_svg_picture.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/components/text_form_field/balance_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:get/get.dart';

class NewDepositScreen extends StatefulWidget {
  const NewDepositScreen({super.key});

  @override
  State<NewDepositScreen> createState() => _NewDepositScreenState();
}

class _NewDepositScreenState extends State<NewDepositScreen> {
  ScrollController scrollController = ScrollController();
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(DepositRepo(apiClient: Get.find()));
    final controller = Get.put(AddNewDepositController(depositRepo: Get.find()));

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.getDepositMethod();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
        navigationBarColor: MyColor.systemNavBarColor,
        child: GetBuilder<AddNewDepositController>(
          builder: (controller) {
            return CustomScaffold(
              title: MyStrings.deposit,
              actionWidget: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  ZoomTapAnimation(
                    onTap: () => Get.toNamed(RouteHelper.depositHistoryScreen),
                    child: CircleIconButton(
                      icon: Image.asset(MyImages.history, width: 25, height: 25, color: MyColor.colorWhite),
                      color: MyColor.colorWhite.withValues(alpha: 0.1),
                    ),
                  ),
                ],
              ),
              topForm: Positioned(
                top: 130,
                left: 15,
                right: 15,
                child: Container(
                  height: 200,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor, width: 1)),
                  padding: EdgeInsets.only(left: 10, right: 10, top: 5, bottom: 5),
                  child: controller.isLoading
                      ? HistoryShimmer(itemCount: 5, isRow: true)
                      : SingleChildScrollView(
                          child: Column(
                            children: List.generate(controller.methodList.length, (index) {
                              final method = controller.methodList[index];
                              return CustomContainer(
                                width: MediaQuery.of(context).size.width,
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                margin: EdgeInsets.only(bottom: Dimensions.space10),
                                radius: 10,
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                                child: InkWell(
                                  onTap: () {
                                    controller.setPaymentMethod(method);
                                    scrollController.animateTo(scrollController.position.maxScrollExtent, duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
                                  },
                                  customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Row(
                                          children: [
                                            Container(
                                              padding: EdgeInsets.all(Dimensions.space5),
                                              decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                              child: method.id == -1 ? CustomSvgPicture(image: MyImages.wallet, width: 25, height: 25, fit: BoxFit.cover) : MyImageWidget(imageUrl: "${controller.imagePath}/${method.method?.image}", width: 30, height: 30, boxFit: BoxFit.cover),
                                            ),
                                            SizedBox(width: Dimensions.space5),
                                            Expanded(
                                              child: Text(method.name ?? "", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Radio(
                                        value: method.id,
                                        groupValue: controller.paymentMethod?.id,
                                        activeColor: MyColor.primaryColor,
                                        fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                                        onChanged: (value) {
                                          controller.setPaymentMethod(method);
                                          scrollController.animateTo(scrollController.position.maxScrollExtent, duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }),
                          ),
                        ),
                ),
              ),
              body: SizedBox(
                height: MediaQuery.of(context).size.height,
                child: Container(
                  padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                  margin: EdgeInsets.only(top: 330),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    child: Column(
                      children: [
                        SizedBox(height: Dimensions.space20),
                        BalanceTextField(
                          label: MyStrings.amount,
                          hintText: "0.00",
                          textEditingController: controller.amountController,
                          onChanged: (v) {
                            controller.changeInfoWidgetValue(double.tryParse(v.toString()) ?? 0);
                          },
                        ),
                        SizedBox(height: Dimensions.space20),
                        Visibility(
                          visible: controller.paymentMethod?.id != -1,
                          child: CustomContainer(
                            width: MediaQuery.of(context).size.width,
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                            radius: 12,
                            color: MyColor.colorWhite.withValues(alpha: 0.10),
                            border: Border.all(color: MyColor.borderColor.withValues(alpha: 0.5), width: .5),
                            child: Column(
                              children: [
                                infoRow(MyStrings.limit.tr, "${controller.currencySym}${AppConverter.formatNumber(controller.paymentMethod?.minAmount.toString() ?? "0")}-${AppConverter.formatNumber(controller.paymentMethod?.maxAmount.toString() ?? "0")} ${controller.currency}"),
                                SizedBox(height: Dimensions.space15),
                                infoRow(MyStrings.conversionRate.tr, "${controller.currencySym}${controller.conversionRate}"),
                                SizedBox(height: Dimensions.space15),
                                infoRow(MyStrings.paymentCharge.tr, "${controller.currencySym}${controller.charge}"),
                                CustomDivider(color: MyColor.colorWhite.withValues(alpha: 0.10), height: 1),
                                infoRow(MyStrings.total.tr, "${controller.currencySym}${controller.payableText}"),
                                SizedBox(height: Dimensions.space5),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(height: Dimensions.space40),
                        RoundedButton(
                          text: MyStrings.proceedToPayment,
                          onTap: () {
                            controller.submitDeposit();
                          },
                          isLoading: controller.submitLoading,
                        ),
                        SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ));
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title.tr, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: regularDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}
