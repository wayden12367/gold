import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/withdraw/add_new_withdraw_controller.dart';
import 'package:viser_gold/data/repo/withdraw/withdraw_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/text_form_field/balance_text_field.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:viser_gold/view/screens/withdraw/add_withdraw_screen/widget/info_widget.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class AddWithdrawScreen extends StatefulWidget {
  const AddWithdrawScreen({super.key});

  @override
  State<AddWithdrawScreen> createState() => _AddWithdrawScreenState();
}

class _AddWithdrawScreenState extends State<AddWithdrawScreen> {
  final ScrollController scrollController = ScrollController();
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(WithdrawRepo(apiClient: Get.find()));
    final controller = Get.put(AddNewWithdrawController(repo: Get.find()));

    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.loadDepositMethod();
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: GetBuilder<AddNewWithdrawController>(
        builder: (controller) {
          return Skeletonizer(
            enabled: controller.isLoading,
            containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
            effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
            child: CustomScaffold(
              title: MyStrings.withdraw,
              appBarHeight: 200,
              actionWidget: Row(
                children: [
                  ZoomTapAnimation(
                    onTap: () => Get.toNamed(RouteHelper.withdrawHistoryScreen),
                    child: CircleIconButton(
                      icon: Image.asset(MyImages.history, width: 25, height: 25, color: MyColor.colorWhite),
                      color: MyColor.colorWhite.withValues(alpha: 0.1),
                    ),
                  ),
                ],
              ),
              topForm: Positioned(
                top: 130,
                left: 15,
                right: 15,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(color: MyColor.cardBgColor, borderRadius: BorderRadius.circular(20), border: Border.all(color: MyColor.borderColor, width: 1)),
                  padding: EdgeInsets.only(left: 10, right: 10, top: 15, bottom: 15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleIconButton(
                            icon: Skeleton.replace(child: SvgPicture.asset(MyImages.wallet)),
                            padding: EdgeInsets.all(8),
                            borderRadius: BorderRadius.circular(10),
                            shape: BoxShape.rectangle,
                            color: MyColor.colorWhite.withValues(alpha: 0.1),
                            border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: 1),
                          ),
                          const SizedBox(width: Dimensions.space5),
                          Text(MyStrings.walletBalance.tr, style: semiBoldDefault.copyWith(fontSize: 17)),
                        ],
                      ),
                      const SizedBox(height: Dimensions.space10),
                      Text("${controller.currencySym}${AppConverter.formatNumber(controller.user?.balance ?? "0")} ${controller.currency}", style: boldDefault.copyWith(fontSize: 17)),
                    ],
                  ),
                ),
              ),
              body: SizedBox(
                height: MediaQuery.of(context).size.height,
                child: Container(
                  padding: EdgeInsets.only(left: Dimensions.space20, right: Dimensions.space20, top: Dimensions.space15),
                  margin: EdgeInsets.only(top: 240),
                  child: SingleChildScrollView(
                    controller: scrollController,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: Dimensions.space20),
                        BalanceTextField(
                          label: MyStrings.amount.tr,
                          hintText: "0.00",
                          textEditingController: controller.amountController,
                          onChanged: (v) {
                            controller.changeInfoWidgetValue(double.tryParse(v.toString()) ?? 0);
                          },
                        ),
                        const SizedBox(height: Dimensions.space10),
                        Text(MyStrings.withdrawMethod.tr, style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                        SizedBox(height: Dimensions.space5),
                        CustomContainer(
                          width: MediaQuery.of(context).size.width,
                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                          color: MyColor.colorWhite.withValues(alpha: 0.05),
                          radius: 12,
                          child: SingleChildScrollView(
                            child: Column(
                              children: List.generate(
                                controller.withdrawMethodList.length,
                                (index) {
                                  final method = controller.withdrawMethodList[index];
                                  return CustomContainer(
                                    width: MediaQuery.of(context).size.width,
                                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                    margin: EdgeInsets.only(bottom: index == controller.withdrawMethodList.length - 1 ? 0 : Dimensions.space10),
                                    radius: 10,
                                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                                    border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.10), width: 1),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Row(
                                            children: [
                                              Container(
                                                padding: EdgeInsets.all(Dimensions.space5),
                                                decoration: BoxDecoration(color: MyColor.colorWhite.withValues(alpha: 0.05), borderRadius: BorderRadius.circular(4)),
                                                child: MyImageWidget(imageUrl: "${UrlContainer.withDrawImagePath}/${method.image}", width: 30, height: 30, boxFit: BoxFit.cover),
                                              ),
                                              SizedBox(width: Dimensions.space5),
                                              Expanded(
                                                child: Text(method.name ?? "", style: regularDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Radio(
                                          value: method.id,
                                          groupValue: controller.withdrawMethod?.id,
                                          activeColor: MyColor.primaryColor,
                                          fillColor: WidgetStateProperty.all(MyColor.primaryColor),
                                          onChanged: (value) {
                                            controller.setWithdrawMethod(method);
                                            scrollController.animateTo(scrollController.position.maxScrollExtent, duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
                                          },
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ),
                        ),
                        // ignore: unrelated_type_equality_checks
                        (controller.mainAmount > 0 && controller.withdrawMethod?.id != null) ? const InfoWidget() : const SizedBox(),
                        SizedBox(height: Dimensions.space20),
                        RoundedButton(
                          text: MyStrings.submit.tr,
                          isLoading: controller.submitLoading,
                          onTap: () {
                            controller.submitWithdrawRequest();
                          },
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
