import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/data/controller/withdraw/withdraw_confirm_controller.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/data/repo/account/profile_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_checkbox_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_date_time_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_file_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_radio_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_select_section.dart';
import 'package:viser_gold/view/screens/auth/kyc/section/kyc_text_section.dart';

class ConfirmWithdrawScreen extends StatefulWidget {
  const ConfirmWithdrawScreen({super.key});

  @override
  State<ConfirmWithdrawScreen> createState() => _ConfirmWithdrawScreenState();
}

class _ConfirmWithdrawScreenState extends State<ConfirmWithdrawScreen> {
  final formKey = GlobalKey<FormState>();

  String gatewayName = '';

  @override
  void initState() {
    gatewayName = Get.arguments[1];
    dynamic model = Get.arguments[0];

    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(ProfileRepo(apiClient: Get.find()));
    final controller = Get.put(WithdrawConfirmController(repo: Get.find(), profileRepo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.initData(model);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: GetBuilder<WithdrawConfirmController>(builder: (controller) {
        return Scaffold(
          backgroundColor: MyColor.backgroundColor,
          appBar: const CustomAppBar(title: MyStrings.withdrawConfirm),
          body: CustomBodyContainer(
            child: Form(
              key: formKey,
              child: ListView.builder(
                itemBuilder: (context, index) {
                  GlobalFormModel? model = controller.formList[index];
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // SizedBox(height: Dimensions.space20),
                      if (MyUtils.getTextInputType(model.type ?? 'text')) ...[
                        KycTextAnEmailSection(
                          onChanged: (value) {
                            controller.changeSelectedValue(value, index);
                          },
                          model: model,
                        )
                      ] else if (model.type == "select") ...[
                        KycSelectSection(
                          onChanged: (value) {
                            controller.changeSelectedValue(value, index);
                          },
                          model: model,
                        )
                      ] else if (model.type == 'radio') ...[
                        KycRadioSection(
                          model: model,
                          onChanged: (selectedIndex) {
                            controller.changeSelectedRadioBtnValue(index, selectedIndex);
                          },
                          selectedIndex: controller.formList[index].options?.indexOf(model.selectedValue ?? '') ?? 0,
                        )
                      ] else if (model.type == "checkbox") ...[
                        KycCheckBoxSection(
                          model: model,
                          onChanged: (value) {
                            controller.changeSelectedCheckBoxValue(index, value);
                          },
                          selectedValue: controller.formList[index].cbSelected,
                        )
                      ] else if (model.type == "datetime" || model.type == "date" || model.type == "time") ...[
                        KycDateTimeSection(
                          model: model,
                          onChanged: (value) {
                            controller.changeSelectedValue(value, index);
                          },
                          onTap: () {
                            printX(model.type);
                            if (model.type == "time") {
                              controller.changeSelectedTimeOnlyValue(index, context);
                            } else if (model.type == "date") {
                              controller.changeSelectedDateOnlyValue(index, context);
                            } else {
                              controller.changeSelectedDateTimeValue(index, context);
                            }
                          },
                          controller: controller.formList[index].textEditingController!,
                        ),
                        const SizedBox(height: Dimensions.space10),
                      ],
                      if (model.type == "file") ...[
                        KycFileSection(
                          model: model,
                          selectedValue: controller.formList[index].selectedValue,
                          onTap: () {
                            controller.pickFile(index);
                          },
                        ),
                        const SizedBox(height: Dimensions.space20),
                      ],
                    ],
                  );
                },
                itemCount: controller.formList.length,
              ),
            ),
          ),
          bottomNavigationBar: GetBuilder<WithdrawConfirmController>(builder: (controller) {
            return controller.isLoading
                ? SizedBox.shrink()
                : SizedBox(
                    height: 80,
                    child: RoundedButton(
                      text: MyStrings.submit.tr,
                      isLoading: controller.submitLoading,
                      onTap: () {
                        if (formKey.currentState!.validate()) {
                          controller.submitConfirmWithdrawRequest();
                        }
                      },
                      margin: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                    ),
                  );
          }),
          extendBody: true,
        );
      }),
    );
  }
}
