import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/gift/gift_controller.dart';
import 'package:viser_gold/environment.dart';
import 'package:viser_gold/view/components/buttons/circle_icon_button.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:viser_gold/data/repo/gift/gift_repo.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/text_form_field/balance_text_field.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:viser_gold/view/screens/gift_screen/widget/gift_gold_catagori.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

class GiftGoldScreen extends StatefulWidget {
  const GiftGoldScreen({super.key});

  @override
  State<GiftGoldScreen> createState() => _GiftGoldScreenState();
}

class _GiftGoldScreenState extends State<GiftGoldScreen> {
  TextEditingController recipientEmailController = TextEditingController();
  TextEditingController amountController = TextEditingController();
  FocusNode recipientEmailFocusNode = FocusNode();
  @override
  void initState() {
    Get.put(GiftRepo());
    final controller = Get.put(GiftController());
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.initData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<GiftController>(
      builder: (controller) {
        return Skeletonizer(
          enabled: controller.isLoading,
          containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
          effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
          child: CustomScaffold(
            title: MyStrings.giftGold,
            appBarHeight: 200,
            actionWidget: Row(
              children: [
                ZoomTapAnimation(
                  onTap: () => Get.toNamed(RouteHelper.giftHistoryScreen),
                  child: CircleIconButton(icon: Image.asset(MyImages.history, width: 25, height: 25, color: MyColor.colorWhite)),
                ),
              ],
            ),
            topForm: GiftGoldCategory(),
            body: Container(
              height: MediaQuery.of(context).size.height,
              margin: EdgeInsets.only(top: 270),
              padding: Dimensions.screenPadding,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomContainer(
                      width: MediaQuery.of(context).size.width,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      radius: 12,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomLabelTextFiled(
                            label: MyStrings.recipient,
                            onChanged: (value) {},
                            hintText: MyStrings.tapToScanQrCode.tr,
                            isReadOnly: true,
                            onTap: () {
                              Get.toNamed(RouteHelper.qrCodeScanner)?.then((value) {
                                if (value != null) {
                                  recipientEmailController.text = value;
                                  controller.checkUser(value);
                                }
                              });
                              setState(() {});
                            },
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: MyColor.primaryColor300.withValues(alpha: 0.5), width: .5)),
                            hintTextStyle: semiBoldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                            prefixIcon: Skeleton.replace(
                              child: CustomContainer(
                                margin: EdgeInsets.all(Dimensions.space3),
                                padding: EdgeInsets.all(Dimensions.space5),
                                radius: 4,
                                color: MyColor.colorWhite.withValues(alpha: 0.10),
                                border: Border.all(color: MyColor.borderColor, width: 1),
                                boxShadow: [
                                  BoxShadow(color: MyColor.borderColor.withValues(alpha: 0.15), blurRadius: 10, offset: Offset(0, 5)),
                                  BoxShadow(color: MyColor.borderColor.withValues(alpha: 0.15), blurRadius: 10, offset: Offset(0, -5)),
                                ],
                                child: SvgPicture.asset(MyImages.qrCode),
                              ),
                            ),
                          ),
                          SizedBox(height: Dimensions.space10),
                          Focus(
                            onFocusChange: (value) {
                              logInfo("value >>>>>>>> $value");
                              if (value == false) {
                                controller.checkUser(recipientEmailController.text);
                              }
                            },
                            child: CustomLabelTextFiled(
                              label: MyStrings.recipientEmail.tr,
                              onChanged: (value) {},
                              focusNode: recipientEmailFocusNode,
                              controller: recipientEmailController,
                              keyboardType: TextInputType.emailAddress,
                              suffixIcon: SizedBox(
                                width: 40,
                                height: 40,
                                //  child: Text(controller.isCheckingUser.toString()),
                                child: controller.isCheckingUser ? CustomLoader(isPagination: true, loaderColor: MyColor.primaryColor) : SizedBox(),
                              ),
                            ),
                          ),
                          SizedBox(height: Dimensions.space4),
                          Row(
                            children: [
                              Icon(Icons.error, size: 18, color: MyColor.colorWhite),
                              SizedBox(width: Dimensions.space4),
                              Expanded(
                                child: Text(MyStrings.recipientHasAccount.tr.replaceAll("_", Environment.appName), style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor), maxLines: 4, overflow: TextOverflow.ellipsis),
                              ),
                            ],
                          ),
                          SizedBox(height: Dimensions.space10),
                          CustomLabelTextFiled(
                            label: MyStrings.recipientName,
                            onChanged: (value) {},
                            isReadOnly: true,
                            controller: controller.recipientNameController,
                            onTap: () {
                              recipientEmailFocusNode.requestFocus();
                            },
                          ),
                          SizedBox(height: Dimensions.space10),
                        ],
                      ),
                    ),
                    SizedBox(height: Dimensions.space10),
                    BalanceTextField(
                      label: MyStrings.goldAmount,
                      hintText: "0.00",
                      textEditingController: amountController,
                      onChanged: (value) {},
                      minTextWidget: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                        ],
                      ),
                    ),
                    SizedBox(height: Dimensions.space10),
                    Visibility(
                      visible: amountController.text.isNotEmpty,
                      child: CustomContainer(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        radius: 12,
                        child: Column(
                          children: [
                            infoRow(MyStrings.goldQuantity.tr, "${(AppConverter.formatDouble(amountController.text) / AppConverter.formatDouble(controller.selectedGoldCategory?.category?.price ?? "0")).toStringAsFixed(4)} ${MyStrings.gram.tr}"),
                            SizedBox(height: Dimensions.space15),
                            infoRow(MyStrings.goldValue.tr, "${controller.currencySym}${AppConverter.formatNumber(amountController.text)}"),
                            SizedBox(height: Dimensions.space15),
                            infoRow(
                              "${MyStrings.charge.tr} (${controller.currencySym}${AppConverter.formatNumber(controller.chargeLimit?.fixedCharge ?? "0")} + ${AppConverter.formatNumber(controller.chargeLimit?.percentCharge ?? "0")}%)",
                              "${controller.currencySym}${AppConverter.sum(AppConverter.formatNumber(controller.chargeLimit?.fixedCharge ?? "0"), AppConverter.calculatePercentage(amountController.text, controller.chargeLimit?.percentCharge ?? "0"))} ${controller.currency}",
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: Dimensions.space30),
                    RoundedButton(
                      text: MyStrings.confirm,
                      onTap: () async {
                        controller.submitGiftGold(amountController.text).then((v) {
                          amountController.text = "0.00";
                          recipientEmailController.text = "";
                        });
                      },
                      isLoading: controller.isSubmitLoading,
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget infoRow(String title, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
        Text(value, style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
      ],
    );
  }
}
