import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/gift/gift_controller.dart';
import 'package:viser_gold/data/repo/gift/gift_repo.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart';

class GiftHistoryScreen extends StatefulWidget {
  const GiftHistoryScreen({super.key});

  @override
  State<GiftHistoryScreen> createState() => _GiftHistoryScreenState();
}

class _GiftHistoryScreenState extends State<GiftHistoryScreen> {
  @override
  void initState() {
    Get.put(GiftRepo());
    final controller = Get.put(GiftController());
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.getGiftGoldHistory();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(title: MyStrings.giftHistory, isShowBackBtn: true),
        body: Container(
          padding: Dimensions.screenPadding,
          constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height, minWidth: MediaQuery.of(context).size.width),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [MyColor.colorBlack, MyColor.colorBlack.withValues(alpha: 0.01)], begin: Alignment.topLeft, end: Alignment.bottomRight, stops: [0.0, 0.1]),
            image: DecorationImage(image: AssetImage(MyImages.bgShape), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.4), BlendMode.srcOver)),
          ),
          child: GetBuilder<GiftController>(
            builder: (controller) {
              return Skeletonizer(
                enabled: controller.isHistoryLoading,
                containersColor: MyColor.colorWhite.withValues(alpha: 0.05),
                effect: ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.05), highlightColor: MyColor.colorWhite.withValues(alpha: 0.05)),
                child: controller.isHistoryLoading
                    ? HistoryShimmer()
                    : controller.giftGoldHistory.isEmpty && !controller.isHistoryLoading
                        ? NoDataWidget(text: MyStrings.emptyGiftHistoryMsg)
                        : ListView.separated(
                            addAutomaticKeepAlives: true,
                            separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
                            itemCount: controller.giftGoldHistory.length,
                            itemBuilder: (context, index) {
                              final history = controller.giftGoldHistory[index];
                              return CustomContainer(
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space15),
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                radius: 20,
                                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.1), width: .5),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              GradientText(text: '${history.recipient?.firstname} ${history.recipient?.lastname}'.toCapitalized(), style: mediumDefault.copyWith(fontSize: 15)),
                                              Text(history.trx ?? '', style: regularDefault.copyWith(fontSize: 12)),
                                            ],
                                          ),
                                        ),
                                        Text(
                                          DateConverter.formatDate(history.createdAt ?? ''),
                                          style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: CardColumn(header: MyStrings.goldCategory, body: history.goldCategory?.name ?? '', maxLine: 1),
                                        ),
                                        Expanded(
                                          child: CardColumn(header: MyStrings.quantity, body: "${AppConverter.formatNumber(history.quantity ?? "0")}${MyStrings.g.tr}", maxLine: 1, alignmentEnd: true),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: Dimensions.space10),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: CardColumn(
                                            header: MyStrings.amount,
                                            body: "${controller.currencySym}${AppConverter.formatNumber(history.amount ?? "0")}",
                                            maxLine: 1,
                                          ),
                                        ),
                                        Expanded(
                                          child: CardColumn(
                                            header: MyStrings.charge,
                                            body: "${controller.currencySym}${AppConverter.formatNumber(history.charge ?? "0")}",
                                            alignmentEnd: true,
                                            maxLine: 1,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
              );
            },
          ),
        ),
      ),
    );
  }
}
