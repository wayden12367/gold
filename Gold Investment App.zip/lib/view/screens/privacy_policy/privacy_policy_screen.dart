import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/privacy/privacy_controller.dart';
import 'package:viser_gold/data/repo/privacy_repo/privacy_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/custom_loader/custom_full_screen_loader.dart';
import 'package:viser_gold/view/components/custom_loader/custom_loader.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:get/get.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(PrivacyRepo(apiClient: Get.find()));
    final controller = Get.put(PrivacyController(repo: Get.find()));

    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(
          title: MyStrings.privacyPolicy,
          isShowBackBtn: true,
        ),
        body: GetBuilder<PrivacyController>(
          builder: (controller) => CustomBodyContainer(
            child: controller.isLoading
                ? const FullScreenLoader()
                : controller.list.isEmpty
                    ? NoDataWidget()
                    : Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsetsDirectional.only(start: Dimensions.space10, top: Dimensions.space15),
                            child: SizedBox(
                              height: 30,
                              child: SingleChildScrollView(
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.horizontal,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: List.generate(
                                    controller.list.length,
                                    (index) => Row(
                                      children: [
                                        CategoryButton(
                                            color: controller.selectedIndex == index ? MyColor.primaryColor : MyColor.colorWhite,
                                            horizontalPadding: 8,
                                            verticalPadding: 7,
                                            textColor: controller.selectedIndex == index ? MyColor.colorWhite : MyColor.colorBlack,
                                            text: controller.list[index].dataValues?.title ?? '',
                                            press: () {
                                              controller.changeIndex(index);
                                            }),
                                        const SizedBox(width: Dimensions.space10)
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: Dimensions.space15),
                          Expanded(
                              child: Center(
                            child: SingleChildScrollView(
                              physics: const BouncingScrollPhysics(),
                              child: Container(
                                padding: const EdgeInsets.all(20),
                                width: double.infinity,
                                color: Colors.transparent,
                                child: HtmlWidget(
                                  controller.selectedHtml,
                                  textStyle: regularDefault.copyWith(color: MyColor.bodyTextColor),
                                  onLoadingBuilder: (context, element, loadingProgress) => const Center(child: CustomLoader()),
                                ),
                              ),
                            ),
                          ))
                        ],
                      ),
          ),
        ));
  }
}

class CategoryButton extends StatelessWidget {
  final String text;
  final VoidCallback press;
  final Color color, textColor;
  final double horizontalPadding;
  final double verticalPadding;
  final double textSize;

  const CategoryButton({
    super.key,
    required this.text,
    this.horizontalPadding = 3,
    this.verticalPadding = 3,
    this.textSize = Dimensions.fontSmall,
    required this.press,
    this.color = MyColor.primaryColor,
    this.textColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(4),
      child: InkWell(
        splashColor: MyColor.primaryColor.withValues(alpha: 0.2),
        onTap: press,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: horizontalPadding, vertical: verticalPadding),
          decoration: BoxDecoration(
            color: MyColor.transparentColor,
            borderRadius: BorderRadius.circular(4),
          ),
          child: Text(
            text.tr,
            style: regularDefault.copyWith(color: textColor, fontSize: textSize),
          ),
        ),
      ),
    );
  }
}
