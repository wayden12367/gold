import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/dropdown/generic_drop_down.dart';
import 'package:viser_gold/view/components/gradient/gradient_widget.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';

import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/custmoScaffold.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';

class ComponentPreviewScreen extends StatefulWidget {
  const ComponentPreviewScreen({super.key});

  @override
  State<ComponentPreviewScreen> createState() => _ComponentPreviewScreenState();
}

class _ComponentPreviewScreenState extends State<ComponentPreviewScreen> {
  int selectedIndex = 0;
  PageController pageController = PageController(viewportFraction: 1, keepPage: true, initialPage: 0, onAttach: (index) {}, onDetach: (index) {});

  List<Widget> pages = [
    PageFour(),
    PageOne(),
    PageTwo(),
    PageThree(),
  ];

  void nextPage() {
    if (selectedIndex < pages.length - 1) {
      selectedIndex++;
      pageController.animateToPage(selectedIndex, duration: Duration(milliseconds: 300), curve: Curves.easeInOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: PageView.builder(
        itemCount: pages.length,
        controller: pageController,
        // physics: NeverScrollableScrollPhysics(),
        onPageChanged: (index) {
          //
        },
        itemBuilder: (context, index) {
          return pages[index];
        },
      ),
    );
  }
}

class PageOne extends StatelessWidget {
  const PageOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage("assets/images/bgShape.png"), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
        ),
        child: SingleChildScrollView(
          // padding: Dimensions.screenPadding,
          child: Stack(
            children: [
              Container(
                height: 250,
                width: double.infinity,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
                  gradient: MyColor.bgGradient,
                  image: DecorationImage(
                    image: NetworkImage(
                        "https://s3-alpha-sig.figma.com/img/80cb/be62/5bef53788d914aabafeec548393ab020?Expires=1735516800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=P0HueEfnjz0SQ3kwkv~8ljw1CowIpeYstd5izKn4BryWcpyc8kVvGyPNgvASuc41Jx2lQFOKV4zX484xnEIAIYA3PdrRnsmAD7qRMIOoaY1fJyMI-R8ccQ8aJc8DQNv4NuFCPSi~G-qXEJanUJrgLuOlEF2ejIm-ikMAkgO7ngvg5Z0W49cdJH8JgzXYFtHNmogCfszCdtjIInEn40u4VMhJx2ioZnV5TUeu~Cnp4Ipd39Ee75Lm8f-Dmpb~tGDYxMM6WEqlfLd6mAbK2j8DgU8atzxih37F9mEP8j7AM0J5N4RbhemNYYN469pEOQ4CAqQa6~8-yHwybck2egUoQg__"),
                    fit: BoxFit.cover,
                    colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.6), BlendMode.dstATop),
                  ),
                ),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Padding(
                      padding: Dimensions.screenPadding,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          const SizedBox(height: Dimensions.space50),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                padding: EdgeInsets.only(left: Dimensions.space2, right: Dimensions.space15, top: Dimensions.space2 + 1, bottom: Dimensions.space2 + 1),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  border: GradientBoxBorder(gradient: MyColor.gradientBorder, width: 2),
                                  color: MyColor.cardBgColor.withValues(alpha: 0.10),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    CircleAvatar(
                                      radius: 20,
                                      backgroundColor: MyColor.transparentColor,
                                      child: MyImageWidget(
                                        imageUrl: 'https://img.freepik.com/premium-vector/avatar-icon0002_750950-43.jpg?semt=ais_hybrid',
                                        isProfile: true,
                                        radius: 20,
                                        height: 40,
                                        width: 40,
                                      ),
                                    ),
                                    const SizedBox(width: Dimensions.space10),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text("John Doe", style: boldDefault.copyWith(fontSize: 17, fontWeight: FontWeight.w600)),
                                        Text("VG5A7C9L12XSJ36", style: lightDefault.copyWith(fontSize: 12, color: MyColor.colorWhite)),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.all(Dimensions.space12),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: MyColor.cardBgColor.withValues(alpha: 0.10),
                                ),
                                child: Icon(CupertinoIcons.bell, color: MyColor.colorWhite, size: 20),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 320),
                padding: Dimensions.screenPadding,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          3,
                          (index) => Container(
                            margin: EdgeInsets.only(right: Dimensions.space10),
                            padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              gradient: MyColor.bgGradient,
                              border: GradientBoxBorder(
                                width: 1,
                                gradient: MyColor.gradientBorder,
                              ),
                            ),
                            child: Column(
                              children: [
                                Image.asset(MyImages.goldBar, height: 60, width: 60),
                                const SizedBox(height: Dimensions.space10),
                                Text("Buy Gold", style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: Dimensions.space20),
                    Text("Buy Gold", style: boldDefault.copyWith(fontSize: 22, fontWeight: FontWeight.w600)),
                    SizedBox(height: Dimensions.space20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space17),
                          decoration: BoxDecoration(
                            color: MyColor.cardBgColor,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: MyColor.borderColor),
                          ),
                          child: Row(
                            children: [
                              Image.asset(MyImages.goldBar, height: 20, width: 20),
                              const SizedBox(width: Dimensions.space10),
                              GradientText(text: "Auto Save", style: boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        const SizedBox(width: Dimensions.space10),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space17),
                          decoration: BoxDecoration(
                            color: MyColor.cardBgColor,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: MyColor.borderColor),
                          ),
                          child: Row(
                            children: [
                              Image.asset(MyImages.goldBar, height: 20, width: 20),
                              const SizedBox(width: Dimensions.space10),
                              GradientText(text: "Gift Gold", style: boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: Dimensions.space20),
                    RoundedButton(text: "Next", onTap: () {}, isLoading: false)
                  ],
                ),
              ),
              Positioned(
                top: 140,
                left: 15,
                right: 15,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: BouncingScrollPhysics(),
                  child: Row(
                    children: List.generate(
                      3,
                      (index) => Container(
                        padding: EdgeInsets.all(12),
                        margin: EdgeInsets.only(right: Dimensions.space10),
                        width: MediaQuery.of(context).size.width - 30,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(image: AssetImage(MyImages.appBarBg), fit: BoxFit.cover),
                          boxShadow: [BoxShadow(color: MyColor.cardBgColor, blurRadius: .1, offset: Offset(0, 0))],
                          border: GradientBoxBorder(width: .5, gradient: MyColor.gradientBorder),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                              decoration: BoxDecoration(
                                color: MyColor.colorWhite.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset(MyImages.goldBar, height: 20, width: 20),
                                  const SizedBox(width: Dimensions.space10),
                                  Text("22 karat Gold", style: regularDefault.copyWith(fontSize: 16)),
                                ],
                              ),
                            ),
                            const SizedBox(height: Dimensions.space10),
                            Row(
                              children: [
                                Text("0.0000 ", style: boldDefault.copyWith(fontSize: 38)),
                                Text("Gram Gold", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                              ],
                            ),
                            const SizedBox(height: Dimensions.space10),
                            Row(
                              children: [
                                Text("Market Today", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                                Icon(Icons.arrow_right_alt_outlined, color: MyColor.bodyTextColor),
                                const SizedBox(width: Dimensions.space10),
                                Text("\$1000/g", style: boldDefault.copyWith(fontSize: 22)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PageTwo extends StatelessWidget {
  const PageTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(240),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Container(
              height: 240,
              width: double.infinity,
              padding: Dimensions.screenPadding,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(26), bottomRight: Radius.circular(26)),
                image: DecorationImage(
                  image: NetworkImage(
                      "https://s3-alpha-sig.figma.com/img/80cb/be62/5bef53788d914aabafeec548393ab020?Expires=1735516800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=P0HueEfnjz0SQ3kwkv~8ljw1CowIpeYstd5izKn4BryWcpyc8kVvGyPNgvASuc41Jx2lQFOKV4zX484xnEIAIYA3PdrRnsmAD7qRMIOoaY1fJyMI-R8ccQ8aJc8DQNv4NuFCPSi~G-qXEJanUJrgLuOlEF2ejIm-ikMAkgO7ngvg5Z0W49cdJH8JgzXYFtHNmogCfszCdtjIInEn40u4VMhJx2ioZnV5TUeu~Cnp4Ipd39Ee75Lm8f-Dmpb~tGDYxMM6WEqlfLd6mAbK2j8DgU8atzxih37F9mEP8j7AM0J5N4RbhemNYYN469pEOQ4CAqQa6~8-yHwybck2egUoQg__"),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.6), BlendMode.dstATop),
                ),
              ),
              child: Row(
                children: [
                  Material(
                    color: Colors.transparent,
                    child: Ink(
                      decoration: ShapeDecoration(
                        color: MyColor.transparentColor,
                        shape: const CircleBorder(),
                      ),
                      child: IconButton(
                        icon: Icon(Icons.arrow_circle_left_outlined, color: MyColor.colorWhite, size: 22),
                        onPressed: () {},
                      ),
                    ),
                  ),
                  const SizedBox(width: Dimensions.space10),
                  Text("Buy Gold", style: boldDefault.copyWith(fontSize: 22, fontWeight: FontWeight.w600)),
                  Row(children: [])
                ],
              ),
            ),
            const SizedBox(height: Dimensions.space20),
            Positioned(
              top: 140,
              child: Container(
                width: context.width,
                padding: Dimensions.screenPadding,
                child: Container(
                  padding: Dimensions.screenPadding,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    image: DecorationImage(image: AssetImage(MyImages.appBarBg), fit: BoxFit.cover),
                    boxShadow: [BoxShadow(color: MyColor.cardBgColor, blurRadius: .1, offset: Offset(0, 0))],
                    border: GradientBoxBorder(width: .5, gradient: MyColor.gradientBorder),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                        decoration: BoxDecoration(
                          color: MyColor.colorWhite.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Image.asset(MyImages.goldBar, height: 20, width: 20),
                            const SizedBox(width: Dimensions.space10),
                            Text("22 karat Gold", style: regularDefault.copyWith(fontSize: 16)),
                          ],
                        ),
                      ),
                      const SizedBox(height: Dimensions.space10),
                      Row(
                        children: [
                          Text("0.0000 ", style: boldDefault.copyWith(fontSize: 38)),
                          Text("Gram Gold", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                        ],
                      ),
                      const SizedBox(height: Dimensions.space10),
                      Row(
                        children: [
                          Text("Market Today", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
                          Icon(Icons.arrow_right_alt_outlined, color: MyColor.bodyTextColor),
                          const SizedBox(width: Dimensions.space10),
                          Text("\$1000/g", style: boldDefault.copyWith(fontSize: 22)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: double.infinity,
        margin: EdgeInsets.only(top: 110),
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage("assets/images/bgShape.png"), fit: BoxFit.cover, colorFilter: ColorFilter.mode(Colors.black12.withValues(alpha: 0.1), BlendMode.srcOver)),
        ),
        child: SingleChildScrollView(
          padding: Dimensions.screenPadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: List.generate(
                    3,
                    (index) => Container(
                      margin: EdgeInsets.only(right: Dimensions.space10),
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: MyColor.bgGradient,
                        border: GradientBoxBorder(
                          width: 1,
                          gradient: MyColor.gradientBorder,
                        ),
                      ),
                      child: Column(
                        children: [
                          Image.asset(MyImages.goldBar, height: 60, width: 60),
                          const SizedBox(height: Dimensions.space10),
                          Text("Buy Gold", style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(height: Dimensions.space20),
              Text("Buy Gold", style: boldDefault.copyWith(fontSize: 22, fontWeight: FontWeight.w600)),
              SizedBox(height: Dimensions.space20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                    decoration: BoxDecoration(
                      color: MyColor.cardBgColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: MyColor.borderColor),
                    ),
                    child: Row(
                      children: [
                        Image.asset(MyImages.goldBar, height: 20, width: 20),
                        const SizedBox(width: Dimensions.space10),
                        Text("Auto Save", style: boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  const SizedBox(width: Dimensions.space10),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space10),
                    decoration: BoxDecoration(
                      color: MyColor.cardBgColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: MyColor.borderColor),
                    ),
                    child: Row(
                      children: [
                        Image.asset(MyImages.goldBar, height: 20, width: 20),
                        const SizedBox(width: Dimensions.space10),
                        Text("Auto Save", style: boldDefault.copyWith(fontSize: 15, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: Dimensions.space20),
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: 18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFDE4D), MyColor.primaryColor960],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: Dimensions.space20,
                      child: SpinKitFadingCircle(
                        color: MyColor.colorBlack,
                        size: 20,
                      ),
                    ),
                    Text(
                      "Next",
                      style: boldDefault.copyWith(fontSize: 18, color: MyColor.colorBlack),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PageThree extends StatelessWidget {
  const PageThree({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScaffold(
      title: "Buy Gold",
      appBarHeight: 200,
      topForm: Positioned(
        top: 120,
        left: 15,
        right: 15,
        child: Container(
          width: context.width,
          padding: EdgeInsets.symmetric(horizontal: Dimensions.space20, vertical: Dimensions.space15),
          decoration: BoxDecoration(
            color: MyColor.cardBgColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: MyColor.borderColor, width: 1),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GenericDropdown<String>(
                title: "Select Country",
                isShowTitle: false,
                list: ["22 Karat Gold", "24 Karat Gold", "20 Karat Gold", "18 Karat Gold", "14 Karat Gold", "10 Karat Gold"],
                displayItem: (value) => value,
              ),
              SizedBox(height: Dimensions.space10),
              Text("USD 84.65/g", style: boldDefault.copyWith(fontSize: 28, color: MyColor.colorWhite)),
              Text("Market Today", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
            ],
          ),
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 300),
        padding: Dimensions.screenPadding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: context.width,
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
              decoration: BoxDecoration(
                color: MyColor.cardBgColor,
                borderRadius: BorderRadius.circular(200),
                border: Border.all(color: MyColor.borderColor, width: 1),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space25, vertical: Dimensions.space8),
                      decoration: BoxDecoration(
                        color: MyColor.dropdownBgColor,
                        borderRadius: BorderRadius.circular(22),
                        border: GradientBoxBorder(
                          gradient: LinearGradient(
                            colors: [MyColor.primaryColor300, MyColor.primaryColor960],
                            transform: GradientRotation(180),
                          ),
                          width: 2,
                        ),
                      ),
                      child: GradientText(text: "Buy in USD", style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                    ),
                  ),
                  const SizedBox(width: Dimensions.space10),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space5, vertical: Dimensions.space5),
                      decoration: BoxDecoration(
                        color: MyColor.transparentColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: GradientText(
                        text: "Buy in Quantity",
                        gradient: LinearGradient(colors: [MyColor.bodyTextColor, MyColor.bodyTextColor]),
                        style: lightDefault.copyWith(fontSize: 16, color: MyColor.colorWhite),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: Dimensions.space20),
            RoundedButton(text: "Next", onTap: () {}, isLoading: false),
            

            SizedBox(height: Dimensions.space20),
            CustomLabelTextFiled(label: "Enter Amount", hintText: "\$0.00", controller: TextEditingController(), onChanged: (value) {}),
            SizedBox(height: Dimensions.space20),
            CustomLabelTextFiled(
              label: "Enter Location",
              hintText: "Enter Location",
              controller: TextEditingController(),
              onChanged: (value) {},
              prefixIcon: CustomContainer(
                radius: 8,
                margin: EdgeInsets.all(Dimensions.space5),
                color: MyColor.colorWhite.withValues(alpha: 0.1),
                border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.5), width: 1),
                child: Icon(Icons.location_on_outlined, color: MyColor.bodyTextColor),
              ),
              suffixIcon: Icon(Icons.location_searching_rounded, color: MyColor.bodyTextColor),
            ),
            SizedBox(height: Dimensions.space20),
            Container(
              width: context.width,
              padding: EdgeInsets.all(Dimensions.space16),
              decoration: BoxDecoration(
                color: MyColor.cardBgColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: MyColor.borderColor, width: 1),
              ),
              child: Column(
                children: [
                  CustomContainer(
                    border: GradientBoxBorder(
                      gradient: LinearGradient(
                        colors: [MyColor.primaryColor300, MyColor.primaryColor960],
                        transform: GradientRotation(180),
                      ),
                      width: 2,
                    ),
                    radius: 12,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    child: Row(
                      children: [
                        CustomContainer(
                          radius: 8,
                          color: MyColor.colorWhite.withValues(alpha: 0.1),
                          padding: EdgeInsets.all(Dimensions.space5),
                          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.5), width: .2),
                          child: Icon(Icons.location_on_outlined, color: MyColor.bodyTextColor),
                        ),
                        const SizedBox(width: Dimensions.space10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Pickup Point ", style: semiBoldDefault.copyWith(fontSize: 15, color: MyColor.colorWhite)),
                            Text("Pick up gold nearby", style: lightDefault.copyWith(fontSize: 10, color: MyColor.bodyTextColor)),
                          ],
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: Dimensions.space16),
                  CustomContainer(
                    radius: 12,
                    padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                    color: MyColor.colorWhite.withValues(alpha: 0.05),
                    border: Border.all(color: MyColor.borderColor, width: 1),
                    child: Row(
                      children: [
                        CustomContainer(
                          radius: 8,
                          color: MyColor.colorWhite.withValues(alpha: 0.1),
                          padding: EdgeInsets.all(Dimensions.space5),
                          border: Border.all(color: MyColor.colorWhite.withValues(alpha: 0.5), width: .2),
                          child: Icon(Icons.location_on_outlined, color: MyColor.bodyTextColor),
                        ),
                        const SizedBox(width: Dimensions.space10),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Pickup Point ", style: semiBoldDefault.copyWith(fontSize: 15, color: MyColor.colorWhite)),
                            Text("Pick up gold nearby", style: lightDefault.copyWith(fontSize: 10, color: MyColor.bodyTextColor)),
                          ],
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: Dimensions.space20),
            //list of users
            ListView.separated(
              separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
              itemCount: 3,
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) => CustomContainer(
                padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                color: MyColor.colorWhite.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                child: Row(
                  children: [
                    Image.asset(MyImages.goldBar, height: 20, width: 20),
                    Text("User $index", style: boldDefault.copyWith(fontSize: 16, color: MyColor.colorWhite)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PageFour extends StatelessWidget {
  const PageFour({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: MyColor.backgroundColor,
      // appBar: CustomAppBar(title: "Page Four"),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: Dimensions.screenPadding,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Send Money", style: boldDefault.copyWith(fontSize: 28, color: MyColor.colorBlack)),
              Text("Transfer money to your contacts", style: lightDefault.copyWith(fontSize: 16, color: MyColor.bodyTextColor)),
              SizedBox(height: Dimensions.space20),
              Container(
                width: context.width,
                decoration: BoxDecoration(
                  color: MyColor.colorWhite,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: MyUtils.getCardShadow(),
                ),
                child: Column(
                  children: List.generate(
                    4,
                    (index) => Container(
                      child: Row(
                        children: [
                          Checkbox(
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(Dimensions.space5)),
                            activeColor: MyColor.primaryColor,
                            checkColor: MyColor.colorWhite,
                            value: true,
                            side: WidgetStateBorderSide.resolveWith(
                              (states) => BorderSide(width: 1.0, color: MyColor.primaryColor),
                            ),
                            onChanged: (value) {},
                          ),
                          Text("Item $index"),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
