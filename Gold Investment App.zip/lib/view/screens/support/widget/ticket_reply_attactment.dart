import 'dart:io';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_icons.dart';
import 'package:viser_gold/core/utils/util.dart';
import 'package:viser_gold/view/components/buttons/custom_circle_animated_button.dart';
import 'package:viser_gold/view/components/image/my_image_widget.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:flutter_svg/svg.dart';

class AttachmentPreviewWidget extends StatelessWidget {
  final String path;
  final Function() onTap;
  final Function()? onImageTap;
  final File? file;
  final bool isShowCloseButton;
  final bool isFileImg;
  final double? height, width;

  const AttachmentPreviewWidget({super.key, required this.path, required this.onTap, this.onImageTap, required this.file, this.isShowCloseButton = false, this.isFileImg = false, this.height = 100, this.width = 100});

  @override
  Widget build(BuildContext context) {
    printX(file);
    return Stack(
      children: [
        ZoomTapAnimation(
          onTap: onImageTap,
          child: Container(
            margin: const EdgeInsets.all(Dimensions.space5),
            decoration: const BoxDecoration(),
            child: isFileImg
                ? UserAttachment(file: file!)
                : MyUtils.isImage(path)
                    ? MyImageWidget(
                        imageUrl: path,
                        height: height,
                        width: width,
                      )
                    : MyUtils.isXlsx(path)
                        ? Container(
                            width: width,
                            height: height,
                            decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                            child: Center(
                              child: SvgPicture.asset(MyIcons.xlsx, height: 45, width: 45),
                            ),
                          )
                        : MyUtils.isDoc(path)
                            ? Container(
                                width: width,
                                height: height,
                                decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                                child: Center(child: SvgPicture.asset(MyIcons.doc, height: 45, width: 45)),
                              )
                            : Container(
                                width: width,
                                height: height,
                                decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                                child: Center(child: SvgPicture.asset(MyIcons.pdfFile, height: 45, width: 45)),
                              ),
          ),
        ),
        isShowCloseButton
            ? Positioned(
                right: 0,
                child: CustomCircleAnimatedButton(
                  onTap: onTap,
                  height: Dimensions.space20 + 5,
                  width: Dimensions.space20 + 5,
                  backgroundColor: MyColor.redCancelTextColor,
                  child: const Icon(Icons.close, color: MyColor.colorWhite, size: Dimensions.space15),
                ),
              )
            : const SizedBox(),
      ],
    );
  }
}

class UserAttachment extends StatelessWidget {
  final double? height, width;
  final File file;
  const UserAttachment({super.key, required this.file, this.height = 100, this.width = 100});

  @override
  Widget build(BuildContext context) {
    return MyUtils.isImage(file.path)
        ? Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
              child: Image.file(
                file,
                width: width,
                height: height,
                fit: BoxFit.cover,
              ),
            ),
          )
        : MyUtils.isXlsx(file.path)
            ? Container(
                width: width,
                height: height,
                decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                child: Center(
                  child: SvgPicture.asset(MyIcons.xlsx, height: 45, width: 45),
                ),
              )
            : MyUtils.isDoc(file.path)
                ? Container(
                    width: width,
                    height: height,
                    decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                    child: Center(child: SvgPicture.asset(MyIcons.doc, height: 45, width: 45)),
                  )
                : Container(
                    width: width,
                    height: height,
                    decoration: BoxDecoration(color: MyColor.colorWhite, borderRadius: BorderRadius.circular(Dimensions.mediumRadius), border: Border.all(color: MyColor.borderColor, width: 1)),
                    child: Center(child: SvgPicture.asset(MyIcons.pdfFile, height: 45, width: 45)),
                  );
  }
}
