import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/support/ticket_details_controller.dart';
import 'package:viser_gold/view/components/bottom-sheet/custom_bottom_sheet.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_details_attachment_bottom_sheet.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_reply_attactment.dart';
import 'package:get/get.dart';

class TicketViewCommentReplyWidget extends StatelessWidget {
  const TicketViewCommentReplyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TicketDetailsController>(builder: (controller) {
      return ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.messageList.length,
        separatorBuilder: (context, index) => SizedBox(height: Dimensions.space10),
        itemBuilder: (context, index) {
          final messages = controller.messageList[index];
          return CustomContainer(
            color: MyColor.colorWhite.withValues(alpha: 0.05),
            radius: 8,
            padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Flexible(
                      flex: 2,
                      child: Row(
                        children: [
                          ClipOval(child: Image.asset(MyImages.user, height: 45, width: 45)),
                          const SizedBox(width: 8),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (messages.admin == null) Text('${messages.ticket?.name}', style: boldDefault.copyWith()) else Text('${messages.admin?.name}', style: boldDefault.copyWith()),
                              Text(messages.adminId == "1" ? MyStrings.admin.tr : MyStrings.you.tr, style: boldDefault.copyWith()),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(DateConverter.getFormatedSubtractTime(messages.createdAt ?? ''), style: regularDefault.copyWith(color: MyColor.colorGrey, fontSize: 12)),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: Dimensions.space10),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(Dimensions.cardRadius)),
                        child: Text(messages.message ?? "", style: lightDefault.copyWith(color: MyColor.bodyTextColor)),
                      ),
                    ),
                  ],
                ),
                //
                if (messages.attachments != null && messages.attachments?.isNotEmpty == true) ...[
                  SizedBox(height: Dimensions.space20),
                  SizedBox(
                    height: 110,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: List.generate(
                        messages.attachments?.length ?? 0,
                        (index) => Positioned(
                          left: (index * 16),
                          child: Transform.rotate(
                            angle: index * 0.1,
                            child: InkWell(
                              onTap: () {
                                CustomBottomSheet(
                                  isNeedPadding: false,
                                  bgColor: MyColor.backgroundColor,
                                  child: TicketDetailsAttachmentBottomSheet(attachments: messages.attachments ?? []),
                                ).show(context);
                              },
                              child: CustomContainer(
                                radius: 8,
                                border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: .5),
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                height: 100,
                                width: 100,
                                child: AttachmentPreviewWidget(path: "${UrlContainer.supportImagePath}${messages.attachments?[index].attachment}", onTap: () {}, file: null, isShowCloseButton: false, isFileImg: false),
                              ).animate().moveX(delay: 1000.ms, begin: 0, end: index * 6),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
                SizedBox(height: Dimensions.space10),
              ],
            ),
          );
        },
      );
    });
  }
}
