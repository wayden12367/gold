import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/controller/support/ticket_details_controller.dart';
import 'package:viser_gold/data/model/support/support_ticket_view_response_model.dart';
import 'package:viser_gold/view/components/buttons/custom_circle_animated_button.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_reply_attactment.dart';
import 'package:get/get.dart';

class TicketDetailsAttachmentBottomSheet extends StatelessWidget {
  List<Attachment> attachments;
  TicketDetailsAttachmentBottomSheet({super.key, required this.attachments});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TicketDetailsController>(builder: (controller) {
      return BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeInOut,
              width: double.infinity,
              height: MediaQuery.of(context).size.height * .4,
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
              decoration: BoxDecoration(
                color: MyColor.cardBgColor,
                borderRadius: BorderRadius.only(topLeft: Radius.circular(25), topRight: Radius.circular(25)),
                border: Border(top: BorderSide(color: MyColor.borderColor, width: .5)),
                boxShadow: [BoxShadow(color: MyColor.colorWhite.withValues(alpha: 0.05), blurRadius: 10, offset: Offset(0, -10))],
              ),
              child: Column(
                children: [
                  Container(
                    height: Dimensions.space5,
                    width: 50,
                    decoration: BoxDecoration(
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      borderRadius: BorderRadius.circular(Dimensions.mediumRadius),
                    ),
                  ),
                  SizedBox(height: Dimensions.space10),
                  Expanded(
                    child: GridView.builder(
                      itemCount: attachments.length,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: MediaQuery.of(context).size.width / (MediaQuery.of(context).size.height / 2.2), // or 120/130
                        mainAxisSpacing: Dimensions.space16,
                        crossAxisSpacing: Dimensions.space15,
                      ),
                      itemBuilder: (context, index) {
                        return Stack(
                          children: [
                            AttachmentPreviewWidget(
                              path: "${UrlContainer.supportImagePath}${attachments[index].attachment}",
                              onTap: () {},
                              onImageTap: () {
                                final url = "${UrlContainer.supportImagePath}${attachments[index].attachment}";
                                controller.downloadAttachment(url: url, index: index);
                                // Get.toNamed(RouteHelper.previewImageScreen, arguments: url);
                              },
                              file: null,
                              isShowCloseButton: false,
                              isFileImg: false,
                              height: 200,
                              width: 200,
                            ),
                            Positioned(
                              top: 0,
                              right: 0,
                              child: CustomCircleAnimatedButton(
                                onTap: () {
                                  final url = "${UrlContainer.supportImagePath}${attachments[index].attachment}";
                                  controller.downloadAttachment(url: url, index: index);
                                },
                                height: Dimensions.space20 + 5,
                                width: Dimensions.space20 + 5,
                                backgroundColor: MyColor.redCancelTextColor,
                                child: Icon(Icons.download_rounded, color: MyColor.colorWhite),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: -30,
              right: 10,
              child: Padding(
                padding: const EdgeInsetsDirectional.only(),
                child: Material(
                  type: MaterialType.transparency,
                  child: Ink(
                    decoration: ShapeDecoration(color: MyColor.cardBgColor, shape: const CircleBorder()),
                    child: FittedBox(
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        onPressed: () {
                          Get.back();
                        },
                        icon: Icon(Icons.keyboard_double_arrow_down, color: MyColor.colorRed),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      );
    });
  }
}
