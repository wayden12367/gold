import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/support/ticket_details_controller.dart';
import 'package:viser_gold/data/repo/support/support_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/custom_circle_animated_button.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/dialog/app_dialog.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_reply_attactment.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_view_comment_reply_widget.dart';
import 'package:get/get.dart';
import 'package:skeletonizer/skeletonizer.dart' as skl;

class TicketDetailsScreen extends StatefulWidget {
  const TicketDetailsScreen({super.key});

  @override
  State<TicketDetailsScreen> createState() => _TicketDetailsScreenState();
}

class _TicketDetailsScreenState extends State<TicketDetailsScreen> {
  String title = "";
  String ticketId = "-1";
  @override
  void initState() {
    ticketId = Get.arguments[0];
    title = Get.arguments[1];
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(SupportRepo(apiClient: Get.find()));
    var controller = Get.put(TicketDetailsController(repo: Get.find(), ticketId: ticketId));

    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(
          title: MyStrings.ticketDetails,
          isShowBackBtn: true,
          paddingVertical: 6,
          action: [],
        ),
        body: GetBuilder<TicketDetailsController>(
          builder: (controller) {
            return skl.Skeletonizer(
              enabled: controller.isLoading,
              containersColor: MyColor.colorWhite.withValues(alpha: 0.03),
              effect: skl.ShimmerEffect(baseColor: MyColor.colorWhite.withValues(alpha: 0.03), highlightColor: MyColor.colorWhite.withValues(alpha: 0.03)),
              child: CustomBodyContainer(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      CustomContainer(
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        radius: 8,
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                        child: Row(
                          children: [
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                    decoration: BoxDecoration(
                                      color: controller.getStatusColor(controller.model.data?.myTickets?.status ?? "0").withValues(alpha: 0.2),
                                      border: Border.all(color: controller.getStatusColor(controller.model.data?.myTickets?.status ?? "0"), width: 1),
                                      borderRadius: BorderRadius.circular(Dimensions.defaultRadius),
                                    ),
                                    child: Text(
                                      controller.getStatusText(controller.model.data?.myTickets?.status ?? '0'),
                                      style: regularDefault.copyWith(
                                        color: controller.getStatusColor(controller.model.data?.myTickets?.status ?? "0"),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10, height: 2),
                                  Expanded(
                                    child: Text(
                                      "[${MyStrings.ticket.tr}#${controller.model.data?.myTickets?.ticket ?? ''}] ${controller.model.data?.myTickets?.subject ?? ''}",
                                      style: boldDefault.copyWith(),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 2,
                                    height: 2,
                                  ),
                                ],
                              ),
                            ),
                            if (controller.model.data?.myTickets?.status != '3')
                              CustomCircleAnimatedButton(
                                onTap: () {
                                  AppDialog().warningAlertDialog(context, title: "Are You Sure ?", subTitle: "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout", () {
                                    Get.back();
                                    controller.closeTicket(controller.model.data?.myTickets?.id.toString() ?? '-1');
                                  });
                                },
                                height: 40,
                                width: 40,
                                backgroundColor: MyColor.colorRed,
                                child: controller.closeLoading ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: MyColor.colorWhite, strokeWidth: 2)) : const Icon(Icons.close_rounded, color: MyColor.colorWhite, size: 20),
                              )
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                      CustomContainer(
                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                        radius: 8,
                        padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CustomLabelTextFiled(
                              fillColor: MyColor.colorWhite.withValues(alpha: 0.05),
                              label: MyStrings.reply,
                              onChanged: (value) {},
                              controller: controller.replyController,
                              hintText: MyStrings.message,
                              hintTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                              maxLines: 4,
                            ),
                            SizedBox(height: Dimensions.space20),
                            Text(MyStrings.attachments.tr, style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)),
                            SizedBox(height: Dimensions.textToTextSpace),
                            ZoomTapAnimation(
                              onTap: () {
                                if (controller.attachmentList.length >= 5) {
                                  CustomSnackBar.error(errorList: [MyStrings.maximumAttachmentLimit]);
                                  return;
                                }
                                controller.pickFile();
                              },
                              child: CustomContainer(
                                width: double.infinity,
                                radius: 12,
                                padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space40),
                                border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: .5),
                                color: MyColor.colorWhite.withValues(alpha: 0.05),
                                child: Column(
                                  children: [
                                    Icon(Icons.add, size: 20, color: MyColor.bodyTextColor),
                                    Text(MyStrings.addAttachment.tr, style: boldDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)),
                                  ],
                                ),
                              ),
                            ),
                            SizedBox(height: Dimensions.space20),
                            Visibility(
                              visible: controller.attachmentList.isNotEmpty,
                              child: SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                child: Row(
                                  children: List.generate(
                                    controller.attachmentList.length,
                                    (index) => GestureDetector(
                                      onTap: () => controller.removeAttachmentFromList(index),
                                      child: CustomContainer(
                                        radius: 12,
                                        margin: EdgeInsets.only(right: Dimensions.space10),
                                        padding: EdgeInsets.all(Dimensions.space4),
                                        border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: .5),
                                        color: MyColor.colorWhite.withValues(alpha: 0.05),
                                        child: Stack(
                                          children: [
                                            AttachmentPreviewWidget(
                                              path: '',
                                              onTap: () {},
                                              file: controller.attachmentList[index],
                                              isShowCloseButton: false,
                                              isFileImg: true,
                                              height: 100,
                                              width: 100,
                                            ),
                                            Positioned.fill(
                                              child: Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                  height: double.infinity,
                                                  width: double.infinity,
                                                  decoration: BoxDecoration(
                                                    color: MyColor.colorRed.withValues(alpha: 0.2),
                                                    borderRadius: BorderRadius.circular(12),
                                                  ),
                                                  child: Icon(Icons.close, color: MyColor.colorRed),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ).animate().fadeIn(duration: 500.ms, delay: 100.ms),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: Dimensions.space20),
                            RoundedButton(
                              text: MyStrings.submit.tr,
                              margin: EdgeInsets.symmetric(horizontal: Dimensions.space15),
                              isLoading: controller.submitLoading,
                              onTap: () {
                                controller.submitReply();
                              },
                            ),
                            SizedBox(height: Dimensions.space10),
                          ],
                        ),
                      ),
                      SizedBox(height: Dimensions.space20),
                      TicketViewCommentReplyWidget(),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
