import 'package:custom_refresh_indicator/custom_refresh_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/date_converter.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/support/support_controller.dart';
import 'package:viser_gold/data/repo/support/support_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/card/card_column.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/no_data.dart';
import 'package:viser_gold/view/components/shimmer/history_shimmer.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:get/get.dart';

class SupportTicketScreen extends StatefulWidget {
  const SupportTicketScreen({super.key});

  @override
  State<SupportTicketScreen> createState() => _SupportTicketScreenState();
}

class _SupportTicketScreenState extends State<SupportTicketScreen> {
  ScrollController scrollController = ScrollController();

  void scrollListener() {
    if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
      if (Get.find<SupportController>().hasNext()) {
        Get.find<SupportController>().getSupportTicket();
      }
    }
  }

  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(SupportRepo(apiClient: Get.find()));
    final controller = Get.put(SupportController(repo: Get.find()));
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      controller.loadData();
      scrollController.addListener(scrollListener);
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        appBar: CustomAppBar(
          title: MyStrings.supportTicket,
          isShowBackBtn: true,
          paddingVertical: 6,
          action: [
            InkWell(
              onTap: () => Get.toNamed(RouteHelper.newTicketScreen),
              child: Container(
                padding: EdgeInsets.all(Dimensions.space10),
                decoration: BoxDecoration(shape: BoxShape.circle, color: MyColor.primaryColor.withValues(alpha: 0.10)),
                child: Icon(CupertinoIcons.add, color: MyColor.colorWhite, size: 20),
              ),
            ),
          ],
        ),
        body: GetBuilder<SupportController>(
          builder: (controller) {
            return CustomMaterialIndicator(
              onRefresh: () async {
                controller.loadData();
              },
              indicatorBuilder: (context, controller) {
                return CustomContainer(
                  padding: const EdgeInsets.all(6.0),
                  child: controller.state.isLoading ? SizedBox() : Image.asset(MyImages.goldBar),
                );
              },
              backgroundColor: MyColor.primaryColor,
              triggerMode: IndicatorTriggerMode.anywhere,
              child: CustomBodyContainer(
                child: controller.isLoading
                    ? HistoryShimmer()
                    : controller.ticketList.isEmpty
                        ? SingleChildScrollView(
                            physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                            child: NoDataWidget(text: MyStrings.noTicketFound),
                          )
                        : ListView.separated(
                            controller: scrollController,
                            itemCount: controller.ticketList.length,
                            physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                            separatorBuilder: (context, index) {
                              return SizedBox(height: Dimensions.space10);
                            },
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  String id = controller.ticketList[index].ticket ?? '-1';
                                  String subject = controller.ticketList[index].subject ?? '';
                                  Get.toNamed(RouteHelper.ticketDetailScreen, arguments: [id, subject]);
                                },
                                child: CustomContainer(
                                  color: MyColor.colorWhite.withValues(alpha: 0.05),
                                  border: Border(left: BorderSide(color: controller.getStatusColor(controller.ticketList[index].status ?? "0"), width: 2)),
                                  radius: 8,
                                  padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Flexible(
                                            child: Padding(
                                              padding: const EdgeInsetsDirectional.only(end: Dimensions.space10),
                                              child: Column(
                                                children: [
                                                  CardColumn(
                                                    header: "[${MyStrings.ticket.tr}#${controller.ticketList[index].ticket}] ${controller.ticketList[index].subject}",
                                                    body: "${controller.ticketList[index].subject}",
                                                    space: 5,
                                                    headerTextStyle: regularDefault.copyWith(fontWeight: FontWeight.w700),
                                                    bodyTextStyle: regularDefault.copyWith(),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                            decoration: BoxDecoration(
                                              color: controller.getStatusColor(controller.ticketList[index].status ?? "0").withValues(alpha: 0.2),
                                              border: Border.all(color: controller.getStatusColor(controller.ticketList[index].status ?? "0"), width: 1),
                                            ),
                                            child: Text(
                                              controller.getStatusText(controller.ticketList[index].status ?? '0'),
                                              style: regularDefault.copyWith(
                                                color: controller.getStatusColor(controller.ticketList[index].status ?? "0"),
                                              ),
                                            ),
                                          )
                                        ],
                                      ),
                                      const SizedBox(height: Dimensions.space15),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space5),
                                            decoration: BoxDecoration(
                                              color: controller.getStatusColor(controller.ticketList[index].priority ?? "0", isPriority: true).withValues(alpha: 0.2),
                                              border: Border.all(color: controller.getStatusColor(controller.ticketList[index].priority ?? "0", isPriority: true), width: 1),
                                            ),
                                            child: Text(
                                              controller.getStatus(controller.ticketList[index].priority ?? '1', isPriority: true),
                                              style: regularDefault.copyWith(
                                                color: controller.getStatusColor(controller.ticketList[index].priority ?? "0", isPriority: true),
                                              ),
                                            ),
                                          ),
                                          Text(
                                            DateConverter.getFormatedSubtractTime(controller.ticketList[index].createdAt ?? ''),
                                            style: regularDefault.copyWith(fontSize: 10, color: MyColor.bodyTextColor),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            );
          },
        ),
      ),
    );
  }
}
