import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:viser_gold/core/utils/dimensions.dart';
import 'package:viser_gold/core/utils/my_color.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/style.dart';
import 'package:viser_gold/data/controller/support/new_ticket_controller.dart';
import 'package:viser_gold/data/repo/support/support_repo.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:viser_gold/view/components/app-bar/custom_appbar.dart';
import 'package:viser_gold/view/components/buttons/rounded_button.dart';
import 'package:viser_gold/view/components/container/custom_body_container.dart';
import 'package:viser_gold/view/components/container/custom_container.dart';
import 'package:viser_gold/view/components/dropdown/generic_drop_down.dart';
import 'package:viser_gold/view/components/packages/zoom_tap/zoom_tap_animation.dart';
import 'package:viser_gold/view/components/text_form_field/custom_label_text_field.dart';
import 'package:viser_gold/view/packages/box_border/gradient_box_border.dart';
import 'package:viser_gold/view/screens/annonateWidget.dart';
import 'package:viser_gold/view/screens/support/widget/ticket_reply_attactment.dart';
import 'package:get/get.dart';

class NewTicketScreen extends StatefulWidget {
  const NewTicketScreen({super.key});

  @override
  State<NewTicketScreen> createState() => _NewTicketScreenState();
}

class _NewTicketScreenState extends State<NewTicketScreen> {
  @override
  void initState() {
    Get.put(ApiClient(sharedPreferences: Get.find()));
    Get.put(SupportRepo(apiClient: Get.find()));
    Get.put(NewTicketController(repo: Get.find()));

    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {});
  }

  @override
  Widget build(BuildContext context) {
    return AnoNateWidget(
      child: Scaffold(
        backgroundColor: MyColor.backgroundColor,
        extendBody: true,
        appBar: CustomAppBar(
          title: "Add New Ticket",
          isShowBackBtn: true,
          paddingVertical: 6,
          action: [],
        ),
        bottomNavigationBar: GetBuilder<NewTicketController>(builder: (controller) {
          return SizedBox(
            width: double.infinity,
            height: 80,
            child: RoundedButton(
              text: MyStrings.submit,
              isLoading: controller.submitLoading,
              onTap: () {
                controller.submit();
              },
              margin: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
            ),
          );
        }),
        body: GetBuilder<NewTicketController>(builder: (controller) {
          return CustomBodyContainer(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: Dimensions.space15, vertical: Dimensions.space10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: Dimensions.space20),
                  CustomLabelTextFiled(
                    fillColor: MyColor.colorWhite.withValues(alpha: 0.05),
                    label: MyStrings.subject,
                    onChanged: (value) {},
                    controller: controller.subjectController,
                    hintText: MyStrings.enterYourSubject,
                    hintTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                  ),
                  SizedBox(height: Dimensions.space20),
                  GenericDropdown<String>(
                    displayItem: (item) => item,
                    onChanged: controller.setPriority,
                    list: controller.priorityList,
                    selectedValue: controller.selectedPriority,
                    title: MyStrings.priority,
                    bgColor: MyColor.colorWhite.withValues(alpha: 0.05),
                    titleStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                    hintTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                    itemTextStyle: regularDefault,
                  ),
                  SizedBox(height: Dimensions.space20),
                  CustomLabelTextFiled(
                    fillColor: MyColor.colorWhite.withValues(alpha: 0.05),
                    label: MyStrings.message,
                    onChanged: (value) {},
                    controller: controller.messageController,
                    hintText: MyStrings.enterYourMessage,
                    hintTextStyle: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor),
                    maxLines: 5,
                  ),
                  SizedBox(height: Dimensions.space20),
                  Text(MyStrings.attachments.tr, style: lightDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)),
                  SizedBox(height: Dimensions.textToTextSpace),
                  ZoomTapAnimation(
                    onTap: () {
                      controller.pickFile();
                    },
                    child: CustomContainer(
                      width: double.infinity,
                      radius: 12,
                      padding: EdgeInsets.symmetric(horizontal: Dimensions.space10, vertical: Dimensions.space40),
                      border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: .5),
                      color: MyColor.colorWhite.withValues(alpha: 0.05),
                      child: Column(
                        children: [
                          Icon(Icons.add, size: 20, color: MyColor.bodyTextColor),
                          Text(MyStrings.addAttachment.tr, style: boldDefault.copyWith(fontSize: 12, color: MyColor.bodyTextColor)),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20),
                  Visibility(
                    visible: controller.attachmentList.isNotEmpty,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: List.generate(
                          controller.attachmentList.length,
                          (index) => GestureDetector(
                            onTap: () => controller.removeAttachmentFromList(index),
                            child: CustomContainer(
                              radius: 12,
                              margin: EdgeInsets.only(right: Dimensions.space10),
                              padding: EdgeInsets.all(Dimensions.space4),
                              border: GradientBoxBorder(gradient: MyColor.gradientBorder2, width: .5),
                              color: MyColor.colorWhite.withValues(alpha: 0.05),
                              child: Stack(
                                children: [
                                  AttachmentPreviewWidget(
                                    path: '',
                                    onTap: () {},
                                    file: controller.attachmentList[index],
                                    isShowCloseButton: false,
                                    isFileImg: true,
                                    height: 100,
                                    width: 100,
                                  ),
                                  Positioned.fill(
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Container(
                                        height: double.infinity,
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                          color: MyColor.colorRed.withValues(alpha: 0.2),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Icon(Icons.close, color: MyColor.colorRed),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ).animate().fadeIn(duration: 500.ms, delay: 100.ms),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: Dimensions.space20 * 4),
                ],
              ),
            ),
          );
        }),
      ),
    );
  }
}
