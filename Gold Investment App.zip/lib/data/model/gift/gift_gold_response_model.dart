// To parse this JSON data, do
//
//     final giftGoldFormResponseModel = giftGoldFormResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

GiftGoldFormResponseModel giftGoldFormResponseModelFromJson(String str) => GiftGoldFormResponseModel.fromJson(json.decode(str));

String giftGoldFormResponseModelToJson(GiftGoldFormResponseModel data) => json.encode(data.toJson());

class GiftGoldFormResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  GiftGoldFormResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory GiftGoldFormResponseModel.fromJson(Map<String, dynamic> json) => GiftGoldFormResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  List<UserGoldCategory>? assets;
  GoldCharge? chargeLimit;

  Data({this.assets, this.chargeLimit});

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        assets: json["assets"] == null ? [] : List<UserGoldCategory>.from(json["assets"]!.map((x) => UserGoldCategory.fromJson(x))),
        chargeLimit: json["charge_limit"] == null ? null : GoldCharge.fromJson(json["charge_limit"]),
      );

  Map<String, dynamic> toJson() => {
        "assets": assets == null ? [] : List<dynamic>.from(assets!.map((x) => x.toJson())),
        "charge_limit": chargeLimit?.toJson(),
      };
}

class UserGoldCategory {
  String? id;
  String? userId;
  String? categoryId;
  String? quantity;
  String? createdAt;
  String? updatedAt;
  GoldCategory? category;

  UserGoldCategory({
    this.id,
    this.userId,
    this.categoryId,
    this.quantity,
    this.createdAt,
    this.updatedAt,
    this.category,
  });

  factory UserGoldCategory.fromJson(Map<String, dynamic> json) => UserGoldCategory(
        id: json["id"].toString(),
        userId: json["user_id"].toString(),
        categoryId: json["category_id"].toString(),
        quantity: json["quantity"].toString(),
        createdAt: json["created_at"].toString(),
        updatedAt: json["updated_at"].toString(),
        category: json["category"] == null ? null : GoldCategory.fromJson(json["category"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "category_id": categoryId,
        "quantity": quantity,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "category": category?.toJson(),
      };
}
