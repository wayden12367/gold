// To parse this JSON data, do
//
//     final giftHistoryResponseModel = giftHistoryResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/model/redeem/redeem_history_response_model.dart';

GiftHistoryResponseModel giftHistoryResponseModelFromJson(String str) => GiftHistoryResponseModel.fromJson(json.decode(str));

String giftHistoryResponseModelToJson(GiftHistoryResponseModel data) => json.encode(data.toJson());

class GiftHistoryResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  GiftHistoryResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory GiftHistoryResponseModel.fromJson(Map<String, dynamic> json) => GiftHistoryResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  List<GiftHistory>? giftHistory;

  Data({
    this.giftHistory,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        giftHistory: json["gift_history"] == null ? [] : List<GiftHistory>.from(json["gift_history"]!.map((x) => GiftHistory.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "gift_history": giftHistory == null ? [] : List<dynamic>.from(giftHistory!.map((x) => x.toJson())),
      };
}

class GiftHistory {
  String? id;
  String? userId;
  String? assetId;
  String? recipientId;
  String? categoryId;
  String? quantity;
  String? amount;
  String? charge;
  String? vat;
  String? type;
  String? trx;
  String? createdAt;
  String? updatedAt;
  GlobalUser? recipient; // gifted user [recipient]
  GoldCategory? goldCategory;
  RedeemData? redeemData; //info: this object is only available when the type is redeem

  GiftHistory({
    this.id,
    this.userId,
    this.assetId,
    this.recipientId,
    this.categoryId,
    this.quantity,
    this.amount,
    this.charge,
    this.vat,
    this.type,
    this.trx,
    this.createdAt,
    this.updatedAt,
    this.goldCategory,
    this.recipient,
    this.redeemData,
  });

  factory GiftHistory.fromJson(Map<String, dynamic> json) => GiftHistory(
        id: json["id"].toString(),
        userId: json["user_id"].toString(),
        assetId: json["asset_id"].toString(),
        recipientId: json["recipient_id"].toString(),
        categoryId: json["category_id"].toString(),
        quantity: json["quantity"].toString(),
        amount: json["amount"].toString(),
        charge: json["charge"].toString(),
        vat: json["vat"].toString(),
        type: json["type"].toString(),
        trx: json["trx"].toString(),
        createdAt: json["created_at"].toString(),
        updatedAt: json["updated_at"].toString(),
        goldCategory: json["category"] == null ? null : GoldCategory.fromJson(json["category"]),
        recipient: json["recipient"] == null ? null : GlobalUser.fromJson(json["recipient"]),
        redeemData: json["redeem_data"] == null ? null : RedeemData.fromJson(json["redeem_data"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "user_id": userId,
        "asset_id": assetId,
        "recipient_id": recipientId,
        "category_id": categoryId,
        "quantity": quantity,
        "amount": amount,
        "charge": charge,
        "vat": vat,
        "type": type,
        "trx": trx,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "category": goldCategory?.toJson(),
        "user": recipient?.toJson(),
        "redeem_data": redeemData?.toJson(),
      };
}
