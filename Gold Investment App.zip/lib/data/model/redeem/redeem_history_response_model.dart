// To parse this JSON data, do
//
//     final buyGoldHistoryResponseModel = buyGoldHistoryResponseModelFromJson(jsonString);


import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

class RedeemHistoryResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  RedeemHistoryResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory RedeemHistoryResponseModel.fromJson(Map<String, dynamic> json) => RedeemHistoryResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  RedeemHistories? redeemHistories;

  Data({
    this.redeemHistories,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        redeemHistories: json["redeem_histories"] == null ? null : RedeemHistories.fromJson(json["redeem_histories"]),
      );

  Map<String, dynamic> toJson() => {
        "buy_histories": redeemHistories?.toJson(),
      };
}

class RedeemHistories {
  List<GiftHistory>? data;
  String? nextPageUrl;

  RedeemHistories({
    this.data,
    this.nextPageUrl,
  });

  factory RedeemHistories.fromJson(Map<String, dynamic> json) => RedeemHistories(
        data: json["data"] == null ? [] : List<GiftHistory>.from(json["data"]!.map((x) => GiftHistory.fromJson(x))),
        nextPageUrl: json["next_page_url"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
        "next_page_url": nextPageUrl,
      };
}

class RedeemData {
  final String? id;
  final String? goldHistoryId;
  final OrderDetails? orderDetails;
  final String? deliveryAddress;
  final String? status;
  final String? createdAt;
  final String? updatedAt;

  RedeemData({
    this.id,
    this.goldHistoryId,
    this.orderDetails,
    this.deliveryAddress,
    this.status,
    this.createdAt,
    this.updatedAt,
  });

  factory RedeemData.fromJson(Map<String, dynamic> json) => RedeemData(
        id: json["id"].toString(),
        goldHistoryId: json["gold_history_id"].toString(),
        orderDetails: json["order_details"] == null ? null : OrderDetails.fromJson(json["order_details"]),
        deliveryAddress: json["delivery_address"].toString(),
        status: json["status"].toString(),
        createdAt: json["created_at"].toString(),
        updatedAt: json["updated_at"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "gold_history_id": goldHistoryId,
        "order_details": orderDetails?.toJson(),
        "delivery_address": deliveryAddress,
        "status": status,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}

class OrderDetails {
  final String? assetId;
  final List<Item>? items;

  OrderDetails({
    this.assetId,
    this.items,
  });

  factory OrderDetails.fromJson(Map<String, dynamic> json) => OrderDetails(
        assetId: json["asset_id"].toString(),
        items: json["items"] == null ? [] : List<Item>.from(json["items"]!.map((x) => Item.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "asset_id": assetId,
        "items": items == null ? [] : List<dynamic>.from(items!.map((x) => x.toJson())),
      };
}

class Item {
  final String? redeemUnitId;
  final String? type;
  final String? quantity;
  final String? text;

  Item({
    this.redeemUnitId,
    this.type,
    this.quantity,
    this.text,
  });

  factory Item.fromJson(Map<String, dynamic> json) => Item(
        redeemUnitId: json["redeem_unit_id"].toString(),
        type: json["type"].toString(),
        quantity: json["quantity"].toString(),
        text: json["text"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "redeem_unit_id": redeemUnitId,
        "type": type,
        "quantity": quantity,
        "text": text,
      };
}
