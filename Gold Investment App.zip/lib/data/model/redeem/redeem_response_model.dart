// To parse this JSON data, do
//
//     final redeemDataResponseModel = redeemDataResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

RedeemDataResponseModel redeemDataResponseModelFromJson(String str) => RedeemDataResponseModel.fromJson(json.decode(str));

String redeemDataResponseModelToJson(RedeemDataResponseModel data) => json.encode(data.toJson());

class RedeemDataResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  RedeemDataResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory RedeemDataResponseModel.fromJson(Map<String, dynamic> json) => RedeemDataResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  List<UserGoldCategory>? assets;
  List<RedeemUnit>? redeemUnits;
  GoldCharge? chargeLimit;

  Data({
    this.assets,
    this.redeemUnits,
    this.chargeLimit,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        assets: json["assets"] == null ? [] : List<UserGoldCategory>.from(json["assets"]!.map((x) => UserGoldCategory.fromJson(x))),
        redeemUnits: json["redeem_units"] == null ? [] : List<RedeemUnit>.from(json["redeem_units"]!.map((x) => RedeemUnit.fromJson(x))),
        chargeLimit: json["charge_limit"] == null ? null : GoldCharge.fromJson(json["charge_limit"]),
      );

  Map<String, dynamic> toJson() => {
        "assets": assets == null ? [] : List<dynamic>.from(assets!.map((x) => x.toJson())),
        "redeem_units": redeemUnits == null ? [] : List<dynamic>.from(redeemUnits!.map((x) => x.toJson())),
        "charge_limit": chargeLimit?.toJson(),
      };
}

class RedeemUnit {
  String? id;
  String? quantity;
  String? type;
  String? status;
  String? createdAt;
  String? updatedAt;
  TextEditingController value;

  RedeemUnit({
    this.id,
    this.quantity,
    this.type,
    this.status,
    this.createdAt,
    this.updatedAt,
    required this.value,
  });

  factory RedeemUnit.fromJson(Map<String, dynamic> json) => RedeemUnit(
        id: json["id"].toString(),
        quantity: json["quantity"].toString(),
        type: json["type"].toString(),
        status: json["status"].toString(),
        createdAt: json["created_at"]?.toString(),
        updatedAt: json["updated_at"]?.toString(),
        value: TextEditingController(text: "0"),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "quantity": quantity,
        "type": type,
        "status": status,
        "created_at": createdAt,
        "updated_at": updatedAt,
        "value": value.text,
      };
}
