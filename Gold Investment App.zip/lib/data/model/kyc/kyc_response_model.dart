import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import '../global/meassage_model.dart';

class KycResponseModel {
  final String? remark;
  final String? status;
  final GlobalMessage? message;
  final Data? data;
  KycResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory KycResponseModel.fromJson(dynamic json) {
    return KycResponseModel(
      remark: json['remark'],
      status: json['status'] != null ? json['status'].toString() : '',
      message: json['message'] != null ? GlobalMessage.fromJson(json['message']) : null,
      data: json['data'] != null ? Data.fromJson(json['data']) : null,
    );
  }
}

class Data {
  final GlobalKYCForm? form;
  final List<KycPendingData>? pendingData;
  final String? path;

  Data({
    this.form,
    this.pendingData,
    this.path,
  });

  factory Data.fromJson(dynamic json) {
    return Data(
      form: json['form'] != null ? GlobalKYCForm.fromJson(json['form']) : null,
      pendingData: json['kyc_data'] != null ? (json['kyc_data'] as List).map((i) => KycPendingData.fromJson(i)).toList() : [],
      path: json['file_path'],
    );
  }
}

class KycPendingData {
  String? name;
  String? type;
  String? value;

  KycPendingData({
    this.name,
    this.type,
    this.value,
  });

  factory KycPendingData.fromJson(Map<String, dynamic> json) => KycPendingData(
        name: json["name"],
        type: json["type"],
        value: json["value"] != null ? json["value"].toString() : '---',
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "type": type,
        "value": value,
      };
}
