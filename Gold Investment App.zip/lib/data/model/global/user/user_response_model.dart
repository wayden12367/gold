class GlobalUser {
  int? id;
  String? firstname;
  String? lastname;
  String? username;
  String? email;
  String? balance;
  String? dialCode;
  String? mobile;
  String? refBy;
  String? countryName;
  String? countryCode;
  String? city;
  String? state;
  String? zip;
  String? address;
  String? status;
  String? kycRejectionReason;
  String? kv;
  String? ev;
  String? sv;
  String? profileComplete;
  String? verCodeSendAt;
  String? ts;
  String? tv;
  String? tsc;
  String? banReason;
  String? provider;
  String? createdAt;
  String? updatedAt;
  String? image;

  GlobalUser({
    this.id,
    this.firstname,
    this.lastname,
    this.username,
    this.email,
    this.balance,
    this.dialCode,
    this.mobile,
    this.refBy,
    this.countryName,
    this.countryCode,
    this.city,
    this.state,
    this.zip,
    this.address,
    this.status,
    this.kycRejectionReason,
    this.kv,
    this.ev,
    this.sv,
    this.profileComplete,
    this.verCodeSendAt,
    this.ts,
    this.tv,
    this.tsc,
    this.banReason,
    this.provider,
    this.createdAt,
    this.updatedAt,
    this.image,
  });

  factory GlobalUser.fromJson(dynamic json) {
    return GlobalUser(
      id: json['id'],
      firstname: json['firstname'] != null ? json['firstname'].toString() : "",
      lastname: json['lastname'] != null ? json['lastname'].toString() : "",
      username: json['username'] != null ? json['username'].toString() : "",
      email: json['email'] != null ? json['email'].toString() : "",
      balance: json['balance'] != null ? json['balance'].toString() : "0.00",
      dialCode: json['dial_code'] != null ? json['dial_code'].toString() : "",
      mobile: json['mobile'] != null ? json['mobile'].toString() : "",
      refBy: json['ref_by'] != null ? json['ref_by'].toString() : "",
      city: json['city'] != null ? json['city'].toString() : "",
      state: json['state'] != null ? json['state'].toString() : "",
      zip: json['zip'] != null ? json['zip'].toString() : "",
      address: json['address'] != null ? json['address'].toString() : "",
      status: json['status'] != null ? json['status'].toString() : "",
      countryName: json['country_name'] != null ? json['country_name'].toString() : "",
      countryCode: json['country_code'] != null ? json['country_code'].toString() : "",
      kycRejectionReason: json['kyc_rejection_reason'] != null ? json['kyc_rejection_reason'].toString() : "",
      profileComplete: json['profile_complete'] != null ? json['profile_complete'].toString() : "",
      verCodeSendAt: json['ver_code_send_at'] != null ? json['ver_code_send_at'].toString() : "",
      ts: json['ts'] != null ? json['ts'].toString() : "",
      tv: json['tv'] != null ? json['tv'].toString() : "",
      tsc: json['tsc'] != null ? json['tsc'].toString() : "",
      kv: json['kv'] != null ? json['kv'].toString() : "",
      ev: json['ev'] != null ? json['ev'].toString() : "",
      sv: json['sv'] != null ? json['sv'].toString() : "",
      banReason: json['ban_reason'] != null ? json['ban_reason'].toString() : "",
      provider: json['provider'] != null ? json['provider'].toString() : "",
      createdAt: json['created_at'] != null ? json['created_at'].toString() : "",
      updatedAt: json['updated_at'] != null ? json['updated_at'].toString() : "",
      image: json['image'] != null ? json['image'].toString() : "",
    );
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['firstname'] = firstname;
    map['lastname'] = lastname;
    map['username'] = username;
    map['email'] = email;
    map['balance'] = balance;
    map['dial_code'] = dialCode;
    map['mobile'] = mobile;
    map['ref_by'] = refBy;
    map['country_name'] = countryName;
    map['country_code'] = countryCode;
    map['city'] = city;
    map['state'] = state;
    map['zip'] = zip;
    map['address'] = address;
    map['status'] = status;
    map['kyc_rejection_reason'] = kycRejectionReason;
    map['kv'] = kv;
    map['ev'] = ev;
    map['sv'] = sv;
    map['profile_complete'] = profileComplete;
    map['ver_code_send_at'] = verCodeSendAt;
    map['ts'] = ts;
    map['tv'] = tv;
    map['tsc'] = tsc;
    map['ban_reason'] = banReason;
    map['provider'] = provider;
    map['created_at'] = createdAt;
    map['updated_at'] = updatedAt;
    map['image'] = image;
    return map;
  }
}
