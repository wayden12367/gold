// To parse this JSON data, do
//
//     final onboardResponseModel = onboardResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/global/meassage_model.dart';

OnboardResponseModel onboardResponseModelFromJson(String str) => OnboardResponseModel.fromJson(json.decode(str));

String onboardResponseModelToJson(OnboardResponseModel data) => json.encode(data.toJson());

class OnboardResponseModel {
  final String? remark;
  final String? status;
  final GlobalMessage? message;
  final Data? data;

  OnboardResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory OnboardResponseModel.fromJson(Map<String, dynamic> json) => OnboardResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  final List<OnboardData>? onboardings;

  Data({
    this.onboardings,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        onboardings: json["onboardings"] == null ? [] : List<OnboardData>.from(json["onboardings"]!.map((x) => OnboardData.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "onboardings": onboardings == null ? [] : List<dynamic>.from(onboardings!.map((x) => x.toJson())),
      };
}

class OnboardData {
  final String? id;
  final OnboardModel? dataValues;

  OnboardData({
    this.id,
    this.dataValues,
  });

  factory OnboardData.fromJson(Map<String, dynamic> json) => OnboardData(
        id: json["id"].toString(),
        dataValues: json["data_values"] == null ? null : OnboardModel.fromJson(json["data_values"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "data_values": dataValues?.toJson(),
      };
}

class OnboardModel {
  final String? title;
  final String? description;
  final String? image;

  OnboardModel({
    this.title,
    this.description,
    this.image,
  });

  factory OnboardModel.fromJson(Map<String, dynamic> json) => OnboardModel(
        title: json["title"] ?? "",
        description: json["description"] ?? "",
        image: json["image"] ?? "",
      );

  Map<String, dynamic> toJson() => {
        "title": title,
        "description": description,
        "image": image,
      };
}
