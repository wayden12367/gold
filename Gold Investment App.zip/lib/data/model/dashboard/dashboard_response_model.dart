// To parse this JSON data, do
//
//     final dashboardResponseModel = dashboardResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/model/transctions/transaction_response_model.dart';

DashboardResponseModel dashboardResponseModelFromJson(String str) => DashboardResponseModel.fromJson(json.decode(str));

String dashboardResponseModelToJson(DashboardResponseModel data) => json.encode(data.toJson());

class DashboardResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  DashboardResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory DashboardResponseModel.fromJson(Map<String, dynamic> json) => DashboardResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  GlobalUser? user;
  List<UserGoldCategory>? assets;
  List<Slider>? sliders;
  List<TransactionData>? transactions;
  String? userImagePath;
  String? sliderImagePath;

  Data({
    this.user,
    this.assets,
    this.sliders,
    this.transactions,
    this.userImagePath,
    this.sliderImagePath,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        user: json["user"] == null ? null : GlobalUser.fromJson(json["user"]),
        assets: json["assets"] == null ? [] : List<UserGoldCategory>.from(json["assets"]!.map((x) => UserGoldCategory.fromJson(x))),
        sliders: json["sliders"] == null ? [] : List<Slider>.from(json["sliders"]!.map((x) => Slider.fromJson(x))),
        transactions: json["transactions"] == null ? [] : List<TransactionData>.from(json["transactions"]!.map((x) => TransactionData.fromJson(x))),
        userImagePath: json["user_image_path"],
        sliderImagePath: json["app_slider_image_path"],
      );

  Map<String, dynamic> toJson() => {
        "user": user?.toJson(),
        "assets": assets == null ? [] : List<UserGoldCategory>.from(assets!.map((x) => x.toJson())),
        "sliders": sliders == null ? [] : List<Slider>.from(sliders!.map((x) => x.toJson())),
        "transactions": transactions == null ? [] : List<Transactions>.from(transactions!.map((x) => x.toJson())),
        "user_image_path": userImagePath,
        "slider_image_path": sliderImagePath,
      };
}

class Slider {
  final String? id;
  final DataValues? dataValues;

  Slider({
    this.id,
    this.dataValues,
  });

  factory Slider.fromJson(Map<String, dynamic> json) => Slider(
        id: json["id"].toString(),
        dataValues: json["data_values"] == null ? null : DataValues.fromJson(json["data_values"]),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "data_values": dataValues?.toJson(),
      };
}

class DataValues {
  final String? hasImage;
  final String? image;

  DataValues({
    this.hasImage,
    this.image,
  });

  factory DataValues.fromJson(Map<String, dynamic> json) => DataValues(
        hasImage: json["has_image"].toString(),
        image: json["image"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "has_image": hasImage,
        "image": image,
      };
}
