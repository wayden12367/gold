// To parse this JSON data, do
//
//     final buyGoldSuccessResponseModel = buyGoldSuccessResponseModelFromJson(jsonString);


import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

class SellGoldSuccessResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  SellGoldSuccessData? data;

  SellGoldSuccessResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory SellGoldSuccessResponseModel.fromJson(Map<String, dynamic> json) => SellGoldSuccessResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : SellGoldSuccessData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class SellGoldSuccessData {
  GiftHistory? sellHistory;
  GoldCategory? goldCategory;

  SellGoldSuccessData({
    this.sellHistory,
    this.goldCategory,
  });

  factory SellGoldSuccessData.fromJson(Map<String, dynamic> json) => SellGoldSuccessData(
        sellHistory: json["sell_history"] == null ? null : GiftHistory.fromJson(json["sell_history"]),
        goldCategory: json["category"] == null ? null : GoldCategory.fromJson(json["category"]),
      );

  Map<String, dynamic> toJson() => {
        "sell_history": sellHistory?.toJson(),
      };
}
