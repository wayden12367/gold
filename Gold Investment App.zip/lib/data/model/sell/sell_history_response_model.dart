// To parse this JSON data, do
//
//     final buyGoldHistoryResponseModel = buyGoldHistoryResponseModelFromJson(jsonString);

import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

class SellGoldHistoryResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  SellGoldHistoryResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory SellGoldHistoryResponseModel.fromJson(Map<String, dynamic> json) => SellGoldHistoryResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  SellHistories? sellHistories;

  Data({
    this.sellHistories,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        sellHistories: json["sell_histories"] == null ? null : SellHistories.fromJson(json["sell_histories"]),
      );

  Map<String, dynamic> toJson() => {
        "sell_histories": sellHistories?.toJson(),
      };
}

class SellHistories {
  List<GiftHistory>? data;
  String? nextPageUrl;

  SellHistories({
    this.data,
    this.nextPageUrl,
  });

  factory SellHistories.fromJson(Map<String, dynamic> json) => SellHistories(
        data: json["data"] == null ? [] : List<GiftHistory>.from(json["data"]!.map((x) => GiftHistory.fromJson(x))),
        nextPageUrl: json["next_page_url"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
        "next_page_url": nextPageUrl,
      };
}
