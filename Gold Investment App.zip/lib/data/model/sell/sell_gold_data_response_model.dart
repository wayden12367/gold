// To parse this JSON data, do
//
//     final buyGoldFormResponseModel = buyGoldFormResponseModelFromJson(jsonString);

import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/deposit/deposit_method_response_model.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

class SellGoldFormResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  SellGoldFormResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory SellGoldFormResponseModel.fromJson(Map<String, dynamic> json) => SellGoldFormResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  List<UserGoldCategory>? categories;
  List<Methods>? gatewayCurrencies;
  GoldCharge? chargeLimit;

  Data({
    this.categories,
    this.gatewayCurrencies,
    this.chargeLimit,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        categories: json["assets"] == null ? [] : List<UserGoldCategory>.from(json["assets"]!.map((x) => UserGoldCategory.fromJson(x))),
        gatewayCurrencies: json["gateway_currencies"] == null ? [] : List<Methods>.from(json["gateway_currencies"]!.map((x) => Methods.fromJson(x))),
        chargeLimit: json["charge_limit"] == null ? null : GoldCharge.fromJson(json["charge_limit"]),
      );

  Map<String, dynamic> toJson() => {
        "categories": categories == null ? [] : List<dynamic>.from(categories!.map((x) => x.toJson())),
        "gateway_currencies": gatewayCurrencies == null ? [] : List<dynamic>.from(gatewayCurrencies!.map((x) => x.toJson())),
        "charge_limit": chargeLimit?.toJson(),
      };
}
