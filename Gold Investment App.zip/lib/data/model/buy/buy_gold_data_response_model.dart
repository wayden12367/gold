// To parse this JSON data, do
//
//     final buyGoldFormResponseModel = buyGoldFormResponseModelFromJson(jsonString);

import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/deposit/deposit_method_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';

class BuyGoldFormResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  BuyGoldFormResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory BuyGoldFormResponseModel.fromJson(Map<String, dynamic> json) => BuyGoldFormResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  GlobalUser? user;
  List<GoldCategory>? categories;
  List<Methods>? gatewayCurrencies;
  GoldCharge? chargeLimit;
  String? gatewayImage;

  Data({
    this.user,
    this.categories,
    this.gatewayCurrencies,
    this.chargeLimit,
    this.gatewayImage,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        user: json["user"] == null ? null : GlobalUser.fromJson(json["user"]),
        categories: json["categories"] == null ? [] : List<GoldCategory>.from(json["categories"]!.map((x) => GoldCategory.fromJson(x))),
        gatewayCurrencies: json["gateway_currencies"] == null ? [] : List<Methods>.from(json["gateway_currencies"]!.map((x) => Methods.fromJson(x))),
        chargeLimit: json["charge_limit"] == null ? null : GoldCharge.fromJson(json["charge_limit"]),
        gatewayImage: json["gateway_image_path"],
      );

  Map<String, dynamic> toJson() => {
        "user": user?.toJson(),
        "categories": categories == null ? [] : List<dynamic>.from(categories!.map((x) => x.toJson())),
        "gateway_currencies": gatewayCurrencies == null ? [] : List<dynamic>.from(gatewayCurrencies!.map((x) => x.toJson())),
        "charge_limit": chargeLimit?.toJson(),
        "gateway_image_path": gatewayImage,
      };
}
