// To parse this JSON data, do
//
//     final buyGoldSuccessResponseModel = buyGoldSuccessResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

BuyGoldSuccessResponseModel buyGoldSuccessResponseModelFromJson(String str) => BuyGoldSuccessResponseModel.fromJson(json.decode(str));

String buyGoldSuccessResponseModelToJson(BuyGoldSuccessResponseModel data) => json.encode(data.toJson());

class BuyGoldSuccessResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  BuyGoldSuccessData? data;

  BuyGoldSuccessResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory BuyGoldSuccessResponseModel.fromJson(Map<String, dynamic> json) => BuyGoldSuccessResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : BuyGoldSuccessData.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class BuyGoldSuccessData {
  GiftHistory? buyHistory;
  GoldCategory? goldCategory;
  String? redirectUrl;

  BuyGoldSuccessData({
    this.buyHistory,
    this.goldCategory,
    this.redirectUrl,
  });

  factory BuyGoldSuccessData.fromJson(Map<String, dynamic> json) => BuyGoldSuccessData(
        buyHistory: json["buy_history"] == null ? null : GiftHistory.fromJson(json["buy_history"]),
        goldCategory: json["category"] == null ? null : GoldCategory.fromJson(json["category"]),
        redirectUrl: json["redirect_url"]?.toString(),
      );

  Map<String, dynamic> toJson() => {
        "buy_history": buyHistory?.toJson(),
        "redirect_url": redirectUrl,
      };
}
