class GoldCategory {
  String? id; //
  String? name;
  String? karat; //
  String? price;
  String? change1H;
  String? change24H;
  String? change7D;
  String? change30D;
  String? change90D;
  String? status; //
  String? createdAt;
  String? updatedAt;

  GoldCategory({
    this.id,
    this.name,
    this.karat,
    this.price,
    this.change1H,
    this.change24H,
    this.change7D,
    this.change30D,
    this.change90D,
    this.status,
    this.createdAt,
    this.updatedAt,
  });

  factory GoldCategory.fromJson(Map<String, dynamic> json) => GoldCategory(
        id: json["id"].toString(),
        name: json["name"].toString(),
        karat: json["karat"].toString(),
        price: json["price"].toString(),
        change1H: json["change_1h"].toString(),
        change24H: json["change_24h"].toString(),
        change7D: json["change_7d"].toString(),
        change30D: json["change_30d"].toString(),
        change90D: json["change_90d"].toString(),
        status: json["status"].toString(),
        createdAt: json["created_at"].toString(),
        updatedAt: json["updated_at"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "karat": karat,
        "price": price,
        "change_1h": change1H,
        "change_24h": change24H,
        "change_7d": change7D,
        "change_30d": change30D,
        "change_90d": change90D,
        "status": status,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
