class GoldCharge {
  String? id;
  String? slug;
  String? minAmount;
  String? maxAmount;
  String? fixedCharge;
  String? percentCharge;
  String? vat;
  String? createdAt;
  String? updatedAt;

  GoldCharge({
    this.id,
    this.slug,
    this.minAmount,
    this.maxAmount,
    this.fixedCharge,
    this.percentCharge,
    this.vat,
    this.createdAt,
    this.updatedAt,
  });

  factory GoldCharge.fromJson(Map<String, dynamic> json) => GoldCharge(
        id: json["id"].toString(),
        slug: json["slug"].toString(),
        minAmount: json["min_amount"].toString(),
        maxAmount: json["max_amount"].toString(),
        fixedCharge: json["fixed_charge"].toString(),
        percentCharge: json["percent_charge"].toString(),
        vat: json["vat"].toString(),
        createdAt: json["created_at"].toString(),
        updatedAt: json["updated_at"].toString(),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "slug": slug,
        "min_amount": minAmount,
        "max_amount": maxAmount,
        "fixed_charge": fixedCharge,
        "percent_charge": percentCharge,
        "vat": vat,
        "created_at": createdAt,
        "updated_at": updatedAt,
      };
}
