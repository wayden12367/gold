// To parse this JSON data, do
//
//     final buyGoldHistoryResponseModel = buyGoldHistoryResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/meassage_model.dart';

BuyGoldHistoryResponseModel buyGoldHistoryResponseModelFromJson(String str) => BuyGoldHistoryResponseModel.fromJson(json.decode(str));

String buyGoldHistoryResponseModelToJson(BuyGoldHistoryResponseModel data) => json.encode(data.toJson());

class BuyGoldHistoryResponseModel {
  String? remark;
  String? status;
  GlobalMessage? message;
  Data? data;

  BuyGoldHistoryResponseModel({
    this.remark,
    this.status,
    this.message,
    this.data,
  });

  factory BuyGoldHistoryResponseModel.fromJson(Map<String, dynamic> json) => BuyGoldHistoryResponseModel(
        remark: json["remark"],
        status: json["status"],
        message: json["message"] == null ? null : GlobalMessage.fromJson(json["message"]),
        data: json["data"] == null ? null : Data.fromJson(json["data"]),
      );

  Map<String, dynamic> toJson() => {
        "remark": remark,
        "status": status,
        "message": message?.toJson(),
        "data": data?.toJson(),
      };
}

class Data {
  BuyHistories? buyHistories;

  Data({
    this.buyHistories,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
        buyHistories: json["buy_histories"] == null ? null : BuyHistories.fromJson(json["buy_histories"]),
      );

  Map<String, dynamic> toJson() => {
        "buy_histories": buyHistories?.toJson(),
      };
}

class BuyHistories {
  List<GiftHistory>? data;
  String? nextPageUrl;

  BuyHistories({
    this.data,
    this.nextPageUrl,
  });

  factory BuyHistories.fromJson(Map<String, dynamic> json) => BuyHistories(
        data: json["data"] == null ? [] : List<GiftHistory>.from(json["data"]!.map((x) => GiftHistory.fromJson(x))),
        nextPageUrl: json["next_page_url"],
      );

  Map<String, dynamic> toJson() => {
        "data": data == null ? [] : List<dynamic>.from(data!.map((x) => x.toJson())),
        "next_page_url": nextPageUrl,
      };
}
