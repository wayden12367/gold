import 'dart:convert';

import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/redeem/redeem_history_response_model.dart';
import 'package:viser_gold/data/repo/redeem_repo/redeem_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class RedeemHistoryController extends GetxController {
  RedeemHistoryController() : repo = Get.find();
  RedeemRepo repo;
  bool isLoading = true;
  String currency = "";
  String currencySym = "";
  int page = 0;
  String? nextPageUrl;
  Future<void> initData() async {
    isLoading = false;
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    page = 0;
    update();
    getRedeemHistory();
  }

  List<GiftHistory> history = [];
  //
  Future<void> getRedeemHistory() async {
    page = page + 1;
    if (page == 1) {
      isLoading = true;
      history = [];
    }
    update();
    try {
      ResponseModel responseModel = await repo.getRedeemHistory(page);
      if (responseModel.statusCode == 200) {
        RedeemHistoryResponseModel model = RedeemHistoryResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          history.addAll(model.data?.redeemHistories?.data ?? []);
          nextPageUrl = model.data?.redeemHistories?.nextPageUrl;
          logInfo(history.length.toString());
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      printX(e);
    } finally {
      isLoading = false;
      update();
    }
  }

  bool hasNext() {
    return nextPageUrl != null && nextPageUrl!.isNotEmpty && nextPageUrl != 'null' ? true : false;
  }
}
