import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/redeem/redeem_response_model.dart';
import 'package:viser_gold/data/repo/redeem_repo/redeem_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class RedeemController extends GetxController {
  RedeemController() : repo = Get.find();
  RedeemRepo repo;

  bool isLoading = true;
  String currency = "";
  String currencySym = "";
  int currentPage = 0;

  PageController pageController = PageController(initialPage: 0, viewportFraction: 1, keepPage: true);
  Future<void> initialData() async {
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    isLoading = true;
    assetList = [];
    allUnitList = [];
    charge;
    currentPage = 0;
    update();
    await getRedeemData();
  }

  List<UserGoldCategory> assetList = [];
  List<RedeemUnit> allUnitList = [];
  List<RedeemUnit> barUnitList = [];
  List<RedeemUnit> coinUnitList = [];
  GoldCharge? charge;
  //
  Future<void> getRedeemData() async {
    try {
      ResponseModel responseModel = await repo.getRedeemData();
      if (responseModel.statusCode == 200) {
        RedeemDataResponseModel model = RedeemDataResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          assetList.addAll(model.data?.assets ?? []);
          allUnitList.addAll(model.data?.redeemUnits ?? []);
          charge = model.data?.chargeLimit;
          if (assetList.isNotEmpty) {
            selectedAsset = assetList.first;
          }
          if (allUnitList.isNotEmpty) {
            filterUnitList();
          }
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      printX(e);
    } finally {
      isLoading = false;
      update();
    }
  }

  void filterUnitList() {
    barUnitList = allUnitList.where((element) => element.type == "1").toList();
    coinUnitList = allUnitList.where((element) => element.type == "2").toList();
    update();
  }

  changePage(int index) {
    currentPage = index;
    pageController.animateToPage(index, duration: Duration(milliseconds: 500), curve: Curves.linearToEaseOut);
    update();
  }

  UserGoldCategory selectedAsset = UserGoldCategory();
  void selectAsset(UserGoldCategory asset) {
    selectedAsset = asset;
    update();
  }

  String redeemType = "1";
  void changeRedeemType(String type) {
    redeemType = type;
    update();
  }

  void incrementAndDecrement(String id, bool isIncrement) {
    try {
      printX("id>>>>>>>>>>: $id");
      if (isIncrement) {
        RedeemUnit unit = allUnitList.firstWhere((element) => element.id == id);
        unit.value.text = (AppConverter.formatDouble(unit.value.text).toInt() + 1).toString();
      } else {
        RedeemUnit unit = allUnitList.firstWhere((element) => element.id == id);
        unit.value.text = (AppConverter.formatDouble(unit.value.text).toInt() >= 1 ? AppConverter.formatDouble(unit.value.text).toInt() - 1 : 0).toString();
      }
      update();
    } catch (e) {
      printX(e);
    }
  }

  bool isValidForRedeem() => allUnitList.any((element) => AppConverter.formatDouble(element.value.text).toInt() != 0);

  double getTotalAmount() {
    return AppConverter.mul(selectedAsset.category?.price ?? "0", selectedAsset.quantity ?? "0");
  }

  String getTotalCharge() {
    double totalQuantity = 0;
    for (var element in allUnitList) {
      if (element.value.text != "0") {
        totalQuantity += AppConverter.formatDouble(element.value.text).toInt() * AppConverter.formatDouble(element.quantity ?? "0");
        loggerX("totalQuantity $totalQuantity");
      }
    }
    double totalAmount = totalQuantity * AppConverter.formatDouble(selectedAsset.category?.price ?? "0");
    loggerX("totalAmount $totalAmount");

    double charge = double.parse(this.charge?.fixedCharge ?? "0") + (totalAmount * double.parse(this.charge?.percentCharge ?? "0") / 100);
    loggerX("charge $charge");
    return "$currencySym${AppConverter.formatNumber(charge.toString())} $currency";
  }

  bool isSubmitLoading = false;
  Future<bool> redeemGold({required Map<String, dynamic> address}) async {
    try {
      isSubmitLoading = true;
      update();
      Map<String, dynamic> body = {};
      for (var element in allUnitList) {
        body["redeem_unit_quantity[${element.id ?? ""}]"] = element.value.text;
      }
      body["asset_id"] = selectedAsset.id;
      body["redeem_type"] = redeemType;
      address.forEach((key, value) {
        body[key] = value;
      });
      loggerX(body);
      ResponseModel responseModel = await repo.redeemGold(body);
      if (responseModel.statusCode == 200) {
        RedeemDataResponseModel model = RedeemDataResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.somethingWentWrong]);
          return true;
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
          return false;
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
        return false;
      }
    } catch (e) {
      printX(e);
      return false;
    } finally {
      isSubmitLoading = false;
      update();
    }
  }

//
  void resetUnitList() {
    for (var element in allUnitList) {
      element.value.text = "0";
    }
    update();
  }
}
