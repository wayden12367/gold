import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/deposit/deposit_method_response_model.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/sell/sell_gold_data_response_model.dart';
import 'package:viser_gold/data/model/sell/sell_gold_sucess_response_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/repo/sell/sell_gold_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';

import 'package:get/get.dart';

class SellGoldController extends GetxController {
  final SellGoldRepo repo;
  SellGoldController() : repo = SellGoldRepo();

  TextEditingController amountController = TextEditingController();
  TextEditingController gramController = TextEditingController();
  List<UserGoldCategory> goldCategories = [];
  List<Methods> gatewayCurrencies = [];
  Methods? selectedGatewayCurrency;
  GoldCharge? chargeLimit;
  GlobalUser? user;
  String? currency;
  String? currencySym;
  String sellType = AppStatus.TYPE_AMOUNT;

  bool isLoading = true;
  initData() async {
    currentPage = 0;
    pageController = PageController(initialPage: 0, viewportFraction: 1, keepPage: true);
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    sellType = AppStatus.TYPE_AMOUNT;
    update();
    await getSellGoldForm();
  }

  Future<void> getSellGoldForm() async {
    isLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.getGoldFormData();
      if (responseModel.statusCode == 200) {
        SellGoldFormResponseModel model = SellGoldFormResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          goldCategories = model.data?.categories ?? [];
          gatewayCurrencies = model.data?.gatewayCurrencies ?? [];
          chargeLimit = model.data?.chargeLimit;
          if (goldCategories.isNotEmpty) {
            selectedGoldCategory = goldCategories.first;
          }
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isLoading = false;
      update();
    }
  }

  selectGatewayCurrency(Methods currency) {
    if (currency != selectedGatewayCurrency) {
      selectedGatewayCurrency = currency;
      update();
    }
  }

  // select gold category
  UserGoldCategory selectedGoldCategory = UserGoldCategory(id: "-1");
  selectGoldCategory(UserGoldCategory category) {
    if (category != selectedGoldCategory) {
      selectedGoldCategory = category;
      update();
      if (sellType == AppStatus.TYPE_AMOUNT) {
        calculateGram(AppConverter.formatDouble(amountController.text));
      } else {
        calculateAmount(AppConverter.formatDouble(gramController.text));
      }
    }
  }

  void calculateGram(double value) {
    if (selectedGoldCategory.id != "-1") {
      gramController.text = (value / AppConverter.formatDouble(selectedGoldCategory.category?.price.toString() ?? "0")).toStringAsFixed(4);
      update();
    }
  }

  void calculateAmount(double value) {
    if (selectedGoldCategory.id != "-1") {
      amountController.text = (value * AppConverter.formatDouble(selectedGoldCategory.category?.price.toString() ?? "0")).toStringAsFixed(2);
      update();
    }
  }

  changeSellType(String type) {
    if (type != sellType) {
      sellType = type;
      update();
    }
  }

  int currentPage = 0;
  changePage(int index) {
    currentPage = index;
    pageController.animateToPage(index, duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
    update();
  }

  PageController pageController = PageController(initialPage: 0, viewportFraction: 1, keepPage: true);

  double getTotalAmount() {
    return AppConverter.formatDouble(amountController.text) + AppConverter.formatDouble(chargeLimit?.fixedCharge.toString() ?? "0") + AppConverter.formatDouble(chargeLimit?.vat.toString() ?? "0");
  }

  bool isValidForCheckout() {
    return AppConverter.formatDouble(amountController.text) >= AppConverter.formatDouble(chargeLimit?.minAmount.toString() ?? "0") && AppConverter.formatDouble(amountController.text) <= AppConverter.formatDouble(chargeLimit?.maxAmount.toString() ?? "0");
  }

  bool isConfirming = false;

  Future<void> confirmSell() async {
    if (isConfirming) return;
    if (amountController.text.isEmpty) {
      CustomSnackBar.error(errorList: [MyStrings.enterAmountMsg]);
      return;
    }

    isConfirming = true;
    update();

    try {
      ResponseModel responseModel = await repo.confirmSellGold(amount: amountController.text, assetId: selectedGoldCategory.id ?? "0");
      if (responseModel.statusCode == 200) {
        SellGoldSuccessResponseModel model = SellGoldSuccessResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          CustomSnackBar.success(successList: [MyStrings.goldSuccessfullySold]);
          Get.toNamed(RouteHelper.sellGoldSuccessScreen, arguments: model.data);
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isConfirming = false;
      update();
    }
  }

//
}
