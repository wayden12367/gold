import 'dart:convert';

import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/sell/sell_history_response_model.dart';
import 'package:viser_gold/data/repo/sell/sell_gold_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class SellHistoryController extends GetxController {
  SellGoldRepo repo;
  SellHistoryController({required this.repo});

  bool isLoading = true;
  String currency = "";
  String currencySym = "";
  int page = 0;
  String? nextPageUrl;
  Future<void> initData() async {
    isLoading = false;
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    page = 0;
    update();
    getSellHistory();
  }

  List<GiftHistory> history = [];
  //
  Future<void> getSellHistory() async {
    page = page + 1;
    if (page == 1) {
      isLoading = true;
      history = [];
    }
    update();
    try {
      ResponseModel responseModel = await repo.getSellGoldHistory(page: page);
      if (responseModel.statusCode == 200) {
        SellGoldHistoryResponseModel model = SellGoldHistoryResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          history.addAll(model.data?.sellHistories?.data ?? []);
          nextPageUrl = model.data?.sellHistories?.nextPageUrl;
          logInfo(history.length.toString());
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      printX(e);
    } finally {
      isLoading = false;
      update();
    }
  }

  bool hasNext() {
    return nextPageUrl != null && nextPageUrl!.isNotEmpty && nextPageUrl != 'null' ? true : false;
  }
}
