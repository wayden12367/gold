import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/authorization/authorization_response_model.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/gift/gift_history_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/repo/gift/gift_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class GiftController extends GetxController {
  final GiftRepo repo;
  GiftController() : repo = GiftRepo();
  //
  List<UserGoldCategory> goldCategories = [];
  GoldCharge? chargeLimit;
  String? currency;
  String? currencySym;
  bool isLoading = true;
  initData() async {
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    await getGiftGoldForm();
  }

  Future<void> getGiftGoldForm() async {
    isLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.getGiftGoldFormData();
      if (responseModel.statusCode == 200) {
        GiftGoldFormResponseModel model = GiftGoldFormResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          goldCategories = model.data?.assets ?? [];
          chargeLimit = model.data?.chargeLimit;
          if (goldCategories.isNotEmpty) {
            selectedGoldCategory = goldCategories.first;
          }
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [e.toString()]);
    } finally {
      isLoading = false;
      update();
    }
  }

  UserGoldCategory? selectedGoldCategory;
  updateSelectedGoldCategory(UserGoldCategory category) {
    if (category != selectedGoldCategory) {
      selectedGoldCategory = category;
      update();
    }
  }

  GlobalUser? recipientUser;
  TextEditingController recipientNameController = TextEditingController();

  bool isCheckingUser = false;
  Future<void> checkUser(String emailOrUsername) async {
    if (emailOrUsername.isEmpty) {
      return;
    }
    isCheckingUser = true;
    update();
    try {
      ResponseModel responseModel = await repo.checkUser(emailOrUsername);
      if (responseModel.statusCode == 200) {
        AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          recipientUser = model.data?.user;
          recipientNameController.text = recipientUser?.username ?? "";
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [e.toString()]);
    } finally {
      isCheckingUser = false;
      update();
    }
  }

  bool isSubmitLoading = false;
  Future<void> submitGiftGold(String amount) async {
    if (amount.isEmpty) {
      CustomSnackBar.error(errorList: [MyStrings.enterAmountMsg]);
      return;
    }
    if (selectedGoldCategory == null) {
      CustomSnackBar.error(errorList: ["Please select gold category"]);
      return;
    }
    if (recipientUser == null) {
      CustomSnackBar.error(errorList: ["Please select recipient"]);
      return;
    }
    try {
      isSubmitLoading = true;
      update();
      ResponseModel responseModel = await repo.submitGiftGold(amount: amount, goldCategoryId: selectedGoldCategory?.id ?? "", user: recipientUser?.username ?? "");
      if (responseModel.statusCode == 200) {
        AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          recipientNameController.text = "";
          Get.toNamed(RouteHelper.giftHistoryScreen);
          CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.success]);
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [e.toString()]);
    } finally {
      isSubmitLoading = false;
      update();
    }
  }

//
  List<GiftHistory> giftGoldHistory = [];
  bool isHistoryLoading = false;
  Future<void> getGiftGoldHistory() async {
    try {
      isHistoryLoading = true;
      update();
      ResponseModel responseModel = await repo.getGiftGoldHistory();
      if (responseModel.statusCode == 200) {
        GiftHistoryResponseModel model = GiftHistoryResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          giftGoldHistory = model.data?.giftHistory ?? [];
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      printX(e);
    } finally {
      isHistoryLoading = false;
      update();
    }
  }
}
