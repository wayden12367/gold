import 'dart:convert';

import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/auth/verification/email_verification_model.dart';
import 'package:viser_gold/data/model/authorization/authorization_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/repo/auth/auth_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class ForgetPasswordController extends GetxController {
  AuthRepo repo;
  ForgetPasswordController() : repo = Get.find<AuthRepo>();

  bool submitLoading = false;

  void submitForgetPassCode(email) async {
    submitLoading = true;
    update();
    try {
      String type = email.contains('@') ? 'email' : 'username';
      String responseEmail = await repo.forgetPassword(type, email);

      if (responseEmail.isNotEmpty) {
        Get.toNamed(RouteHelper.verifyForgetPasswordScreen, arguments: responseEmail);
      }
    } catch (e) {
      printX(e);
    } finally {
      submitLoading = false;
      update();
    }
  }

  //
  bool isResendLoading = false;
  void resendForgetPassCode(String email) async {
    isResendLoading = true;
    update();

    String type = 'email';
    await repo.forgetPassword(type, email);
    isResendLoading = false;
    update();
  }

  // verify code
  bool verifyLoading = false;
  void verifyForgetPasswordCode(String email, String value) async {
    try {
      if (value.isNotEmpty) {
        verifyLoading = true;
        update();

        EmailVerificationModel model = await repo.verifyForgetPassCode(value);

        if (model.code == 200) {
          Get.offAndToNamed(RouteHelper.resetPasswordScreen, arguments: [email, value]);
        } else {
          update();
          List<String> errorList = [MyStrings.verificationFailed];
          CustomSnackBar.error(errorList: errorList);
        }
      }
    } catch (e) {
      printX(e);
    } finally {
      verifyLoading = false;
      update();
    }
  }

  // reset password
  bool resetPasswordLoading = false;
  void resetPassword(String email, String password, String code) async {
    resetPasswordLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.resetPassword(email, password, code);
      if (responseModel.statusCode == 200) {
        AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == 'success') {
          repo.apiClient.logout();
          Get.offAndToNamed(RouteHelper.authenticationScreen);
          CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.somethingWentWrong]);
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message ?? MyStrings.somethingWentWrong]);
      }
    } catch (e) {
      printX(e);
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      resetPasswordLoading = false;
      update();
    }
  }
}
