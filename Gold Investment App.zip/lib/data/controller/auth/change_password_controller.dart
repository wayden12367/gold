import 'dart:convert';

import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/authorization/authorization_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/repo/account/change_password_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class ChangePasswordController extends GetxController {
  ChangePasswordRepo changePasswordRepo;
  ChangePasswordController({required this.changePasswordRepo});

  String? currentPass, password, confirmPass;

  bool isLoading = false;
  List<String> errors = [];

  addError({required String error}) {
    if (!errors.contains(error)) {
      errors.add(error);
      update();
    }
  }

  removeError({required String error}) {
    if (errors.contains(error)) {
      errors.remove(error);
      update();
    }
  }

  bool submitLoading = false;
  changePassword({required String currentPass, required String password}) async {
    submitLoading = true;
    update();
    ResponseModel responseModel = await changePasswordRepo.changePassword(currentPass, password);
    if (responseModel.statusCode == 200) {
      AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(responseModel.responseJson));
      if (model.status == "success") {
        Get.back();
        CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.success]);
      } else {
        CustomSnackBar.error(errorList: model.message?.error ?? []);
      }
    }

    submitLoading = false;
    update();
  }

  void clearData() {
    isLoading = false;
    errors.clear();
    currentPass = '';
    password = '';
    confirmPass = '';
  }
}
