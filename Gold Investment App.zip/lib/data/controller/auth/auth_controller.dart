import 'dart:convert';

import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/auth/login/login_response_model.dart';
import 'package:viser_gold/data/model/auth/sign_up_model/sign_up_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/repo/auth/auth_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import 'package:get/get.dart';

class AuthController extends GetxController {
  AuthRepo repo;
  AuthController() : repo = Get.find<AuthRepo>();

  bool isLoading = false;
  bool isSubmitLoading = false;

  Future<void> loginUser(String email, String password) async {
    isSubmitLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.loginUser(email, password);
      printX(responseModel.statusCode);
      if (responseModel.statusCode == 200) {
        LoginResponseModel model = LoginResponseModel.fromJson(jsonDecode(responseModel.responseJson));

        if (model.status == MyStrings.success) {
          CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.success]);
          RouteHelper.checkUserStatusAndGoToNextStep(model.data?.user, accessToken: model.data?.accessToken ?? '', isRemember: true, tokenType: model.data?.tokenType ?? '');
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isSubmitLoading = false;
      update();
    }
  }

  Future<void> registerUser(SignUpModel model) async {
    isSubmitLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.registerUser(model);
      printX(responseModel.statusCode);
      if (responseModel.statusCode == 200) {
        LoginResponseModel model = LoginResponseModel.fromJson(jsonDecode(responseModel.responseJson));

        if (model.status == MyStrings.success) {
          CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.success]);
          RouteHelper.checkUserStatusAndGoToNextStep(model.data?.user, accessToken: model.data?.accessToken ?? '', isRemember: true, tokenType: model.data?.tokenType ?? '');
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isSubmitLoading = false;
      update();
    }
  }
}
