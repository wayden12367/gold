import 'dart:convert';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/data/controller/profile/profile_controller.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/model/profile/profile_response_model.dart';
import 'package:get/get.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/general_setting/general_setting_response_model.dart';
import 'package:viser_gold/data/repo/menu_repo/menu_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';
import '../../model/authorization/authorization_response_model.dart';

class MyMenuController extends GetxController {
  ProfileController profileController;
  MenuRepo menuRepo;
  MyMenuController({required this.menuRepo, required this.profileController});

  bool logoutLoading = false;
  bool isLoading = true;
  bool noInternet = false;

  bool balTransferEnable = true;
  bool langSwitchEnable = true;
  GlobalUser? user;

  GeneralSettingResponseModel generalSettingResponseModel = GeneralSettingResponseModel();
  void loadData() async {
    isLoading = true;
    generalSettingResponseModel = menuRepo.apiClient.getGSData();
    update();
    await profileController.loadProfileInfo();
    await loadUserInfo();
    isLoading = false;
    update();
  }

  Future<void> loadUserInfo() async {
    final response = await menuRepo.loadProfileInfo();
    if (response.statusCode == 200) {
      ProfileResponseModel model = ProfileResponseModel.fromJson(jsonDecode(response.responseJson));
      if (model.status?.toLowerCase() == MyStrings.success.toLowerCase()) {
        user = model.data?.user ?? GlobalUser();
        update();
      }
    }
  }

  bool removeLoading = false;
  Future<void> removeAccount() async {
    removeLoading = true;
    update();

    final responseModal = await menuRepo.removeAccount();
    if (responseModal.statusCode == 200) {
      AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(responseModal.responseJson));
      if (model.status?.toLowerCase() == MyStrings.success) {
        await menuRepo.clearSharedPrefData();
        Get.offAllNamed(RouteHelper.authenticationScreen);
        CustomSnackBar.success(successList: model.message?.success ?? [MyStrings.accountDeletedSuccessfully]);
      } else {
        CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
      }
    } else {
      CustomSnackBar.error(errorList: [responseModal.message]);
    }

    removeLoading = false;
    update();
  }

  Future<void> logout() async {
    logoutLoading = true;
    update();

    try {
      await menuRepo.logout();
      CustomSnackBar.success(successList: [MyStrings.logoutSuccessMsg]);
      Get.offAllNamed(RouteHelper.authenticationScreen);
    } catch (e) {
      printX(e);
    } finally {
      logoutLoading = false;
      update();
    }
  }
//

  bool isVerifiedUser() {
    if (user?.ev == '0') {
      return false;
    } else if (user?.profileComplete == '0') {
      return false;
    } else if (user?.sv == '0') {
      return false;
    }
    return true;
  }
}
