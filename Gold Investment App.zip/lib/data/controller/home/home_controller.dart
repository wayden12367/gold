import 'dart:async';
import 'dart:convert';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/my_images.dart';
import 'package:viser_gold/data/model/dashboard/dashboard_response_model.dart';
import 'package:viser_gold/data/model/general_setting/general_setting_response_model.dart';
import 'package:viser_gold/data/model/gift/gift_gold_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/model/transctions/transaction_response_model.dart';
import 'package:viser_gold/data/repo/home/home_repo.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  HomeRepo homeRepo;
  HomeController({required this.homeRepo});
  String isKycVerified = '1';
  bool isLoading = true;
  String currency = "";
  String currencySym = "";
  String userImagePath = "";
  String sliderImagePath = "";
  GeneralSettingResponseModel generalSettingResponseModel = GeneralSettingResponseModel();

  List<Slider> sliders = [];
  List<String> imgList = [
    MyImages.goldBar,
    MyImages.coin,
    MyImages.car,
  ];

  int currentSlideIndex = 0;
  changeCurrentSlideIndex(int index) {
    currentSlideIndex = index;
    update();
  }

  Future<void> initialData({bool shouldLoad = true}) async {
    isLoading = shouldLoad ? true : false;
    currency = homeRepo.apiClient.getCurrencyOrUsername();
    currencySym = homeRepo.apiClient.getCurrencyOrUsername(isSymbol: true);
    generalSettingResponseModel = homeRepo.apiClient.getGSData();
    sliders = [];
    update();
    await loadInitialData();
    isLoading = false;
    update();
  }

  List<UserGoldCategory> assets = [];
  List<TransactionData> transactions = [];
  GlobalUser user = GlobalUser();
  Future<void> loadInitialData() async {
    try {
      ResponseModel responseModel = await homeRepo.getData();
      if (responseModel.statusCode == 200) {
        DashboardResponseModel model = DashboardResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          user = model.data?.user ?? GlobalUser();
          assets = model.data?.assets ?? [];
          sliders = model.data?.sliders ?? [];
          transactions = model.data?.transactions ?? [];
          userImagePath = model.data?.userImagePath ?? "";
          sliderImagePath = model.data?.sliderImagePath ?? "";
        }
      }
    } catch (e) {
      logDebug(e);
    } finally {
      isLoading = false;
      update();
    }
  }

  String getTotalAssetAmount() {
    if (assets.isEmpty) return "0.00";
    double totalAsset = 0;
    for (var asset in assets) {
      totalAsset += AppConverter.formatDouble(asset.quantity ?? "0", precision: 2) * AppConverter.formatDouble(asset.category?.price ?? "0", precision: 2);
    }
    return totalAsset.toString();
  }

  String getTotalAssetGram() {
    if (assets.isEmpty) return "0.00";
    double totalAsset = 0;
    for (var asset in assets) {
      totalAsset += AppConverter.formatDouble(asset.quantity ?? "0", precision: 2);
    }
    return totalAsset.toString();
  }
}
