import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/route/route.dart';
import 'package:viser_gold/core/utils/appStatus.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/data/model/buy/buy_gold_data_response_model.dart';
import 'package:viser_gold/data/model/buy/buy_gold_success_response_model.dart';
import 'package:viser_gold/data/model/buy/gold_catagori_model.dart';
import 'package:viser_gold/data/model/buy/gold_charges.dart';
import 'package:viser_gold/data/model/deposit/deposit_method_response_model.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/model/global/user/user_response_model.dart';
import 'package:viser_gold/data/repo/buy/buy_gold_repo.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';

import 'package:get/get.dart';

class BuyGoldController extends GetxController {
  final BuyGoldRepo repo;
  BuyGoldController() : repo = BuyGoldRepo();

  TextEditingController amountController = TextEditingController();
  TextEditingController gramController = TextEditingController();
  List<GoldCategory> goldCategories = [];
  List<Methods> gatewayCurrencies = [];
  Methods? selectedGatewayCurrency = Methods(id: -1);
  GoldCharge? chargeLimit;
  GlobalUser? user;
  String currency = "";
  String currencySym = "";
  String buyType = AppStatus.TYPE_AMOUNT;
  String gatewayImagePath = "";

  bool isLoading = true;
  initData() async {
    currentPage = 0;
    pageController = PageController(initialPage: 0, viewportFraction: 1, keepPage: true);
    currency = repo.apiClient.getCurrencyOrUsername(isCurrency: true);
    currencySym = repo.apiClient.getCurrencyOrUsername(isSymbol: true);
    buyType = AppStatus.TYPE_AMOUNT;
    gatewayImagePath = "";
    update();
    await getBuyGoldForm();
  }

  Future<void> getBuyGoldForm() async {
    isLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.getGoldFormData();
      if (responseModel.statusCode == 200) {
        BuyGoldFormResponseModel model = BuyGoldFormResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          user = model.data?.user;
          goldCategories = model.data?.categories ?? [];
          gatewayCurrencies = model.data?.gatewayCurrencies ?? [];
          chargeLimit = model.data?.chargeLimit;
          if (goldCategories.isNotEmpty) {
            selectedGoldCategory = goldCategories.first;
          }
          gatewayImagePath = model.data?.gatewayImage ?? "";
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isLoading = false;
      update();
    }
  }

  selectGatewayCurrency(Methods currency) {
    if (currency != selectedGatewayCurrency) {
      selectedGatewayCurrency = currency;
    }
    update();
    getTotalCharge();
    getTotalAmount();
  }

  // select gold category
  GoldCategory selectedGoldCategory = GoldCategory();
  selectGoldCategory(GoldCategory category) {
    if (category != selectedGoldCategory) {
      selectedGoldCategory = category;
      update();
      if (buyType == "1") {
        calculateGram(AppConverter.formatDouble(amountController.text));
      } else {
        calculateAmount(AppConverter.formatDouble(gramController.text));
      }
    }
  }

  void calculateGram(double value) {
    gramController.text = (value / AppConverter.formatDouble(selectedGoldCategory.price.toString())).toStringAsFixed(4);
    update();
  }

  void calculateAmount(double value) {
    amountController.text = (value * AppConverter.formatDouble(selectedGoldCategory.price.toString())).toStringAsFixed(2);
    update();
  }

  changeBuyType(String type) {
    if (type != buyType) {
      buyType = type;
      update();
    }
  }

  int currentPage = 0;
  changePage(int index) {
    currentPage = index;
    pageController.animateToPage(index, duration: Duration(milliseconds: 500), curve: Curves.easeInOut);
    update();
  }

  PageController pageController = PageController(initialPage: 0, viewportFraction: 1, keepPage: true);

  double getTotalAmount() {
    String totalCharge = AppConverter.sum(chargeLimit?.fixedCharge.toString() ?? "0", AppConverter.calculatePercentage(amountController.text, chargeLimit?.percentCharge.toString() ?? "0"));
    String totalVat = AppConverter.calculateVat(amountController.text, chargeLimit?.vat.toString() ?? "0");
    return AppConverter.formatDouble(amountController.text, precision: 2) + AppConverter.formatDouble(totalCharge, precision: 2) + AppConverter.formatDouble(totalVat, precision: 2);
  }

  String getTotalCharge() {
    return AppConverter.sum(selectedGatewayCurrency?.fixedCharge.toString() ?? "0", AppConverter.calculatePercentage(getTotalAmount().toString(), selectedGatewayCurrency?.percentCharge.toString() ?? "0"));
  }

  bool isValidForCheckout() {
    return AppConverter.formatDouble(amountController.text) >= AppConverter.formatDouble(chargeLimit?.minAmount.toString() ?? "0") && AppConverter.formatDouble(amountController.text) <= AppConverter.formatDouble(chargeLimit?.maxAmount.toString() ?? "0");
  }

  //
  bool isBuyNowLoading = false;
  Future<void> buyNow() async {
    if (amountController.text.isEmpty) {
      CustomSnackBar.error(errorList: [MyStrings.enterAmountMsg]);
      return;
    }
    if (selectedGatewayCurrency == null) {
      CustomSnackBar.error(errorList: [MyStrings.selectPaymentMethod]);
      return;
    }
    isBuyNowLoading = true;
    update();
    try {
      ResponseModel responseModel = await repo.buyGold(
        amount: amountController.text,
        goldCategoryId: selectedGoldCategory.id.toString(),
        currency: selectedGatewayCurrency?.currency ?? currency,
        gateway: selectedGatewayCurrency?.methodCode ?? "-1",
      );
      if (responseModel.statusCode == 200) {
        BuyGoldSuccessResponseModel model = BuyGoldSuccessResponseModel.fromJson(jsonDecode(responseModel.responseJson));
        if (model.status == "success") {
          if (model.data?.redirectUrl != null && model.data?.redirectUrl != "" && model.data?.redirectUrl != "null") {
            Get.toNamed(RouteHelper.webViewScreen, arguments: model.data?.redirectUrl.toString());
          } else {
            Get.toNamed(RouteHelper.buyGoldSuccessScreen, arguments: model.data);
          }
        } else {
          CustomSnackBar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong]);
        }
      } else {
        CustomSnackBar.error(errorList: [responseModel.message]);
      }
    } catch (e) {
      CustomSnackBar.error(errorList: [MyStrings.somethingWentWrong]);
    } finally {
      isBuyNowLoading = false;
      update();
    }
  }
}
