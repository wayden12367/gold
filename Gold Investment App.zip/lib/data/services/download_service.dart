import 'dart:io';
import 'package:downloadsfolder/downloadsfolder.dart';
import 'package:intl/intl.dart';
import 'package:dio/dio.dart';
import 'package:viser_gold/core/helper/string_format_helper.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:viser_gold/environment.dart';
import 'package:viser_gold/view/components/snack_bar/show_custom_snackbar.dart';

class DownloadService {
  static String? extractFileExtension(String value) {
    RegExp regExp = RegExp(r'\.([a-zA-Z0-9]+)$');
    Match? match = regExp.firstMatch(value);
    return match?.group(1);
  }

  static Future<void> downloadFile({
    required String mainUrl,
    String? fileName,
    String? accessToken,
  }) async {
    printX("Download Service call");

    Dio dio = Dio();

    try {
      // Request storage permission
      if (await Permission.storage.request().isDenied) {
        printX("❌ Storage permission denied.");
        return;
      }

      // Get the download directory
      // Directory? downloadsDir = Directory('/storage/emulated/0/Download');
      // if (!downloadsDir.existsSync()) {
      //   downloadsDir = await getExternalStorageDirectory();
      // }

      // Make a HEAD request to get the content-disposition header
      Response response = await dio.head(
        mainUrl,
        options: Options(headers: {"Authorization": "Bearer $accessToken"}),
      );

      String? contentDisposition = response.headers.value('content-disposition');
      String defaultFileName = "downloaded_file";
      String extension = "";

      // Log the headers for debugging
      loggerX(contentDisposition);
      loggerX(response.headers);

      // Extract filename from content-disposition if available
      if (contentDisposition != null) {
        extension = extractFileExtension(contentDisposition) ?? "";
        String timestamp = DateFormat('yyyyMMdd_HHmmss').format(DateTime.now());
        defaultFileName = "${Environment.appName}_$timestamp";
      }

      // If no extension was found, default to ".bin"
      if (extension.isEmpty) {
        extension = ".bin";
      }

      // Define the full file path
      Directory downloadDirectory = await getDownloadDirectory();
      String filePath = '${downloadDirectory.path}/$defaultFileName.$extension';

      // Download the file
      await dio.download(
        mainUrl,
        filePath,
        options: Options(headers: {"Authorization": "Bearer $accessToken"}),
        onReceiveProgress: (received, total) {
          if (total != -1) {
            printX("Download Progress: ${(received / total * 100).toStringAsFixed(2)}%");
          }
        },
      );

      printX('✅ File downloaded successfully: $filePath');
      CustomSnackBar.success(successList: [MyStrings.fileDownloadedSuccess]);
    } catch (e) {
      printX('❌ Error: $e');
    }
  }

}
