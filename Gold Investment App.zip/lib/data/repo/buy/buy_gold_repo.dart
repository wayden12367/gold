import 'package:viser_gold/core/utils/method.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:get/get.dart';

class BuyGoldRepo {
  ApiClient apiClient;
  BuyGoldRepo() : apiClient = ApiClient(sharedPreferences: Get.find());

  Future<ResponseModel> getGoldFormData() async {
    final url = UrlContainer.baseUrl + UrlContainer.buyGoldForm;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }

  Future<ResponseModel> getBuyGoldHistory({required int page}) async {
    final url = '${UrlContainer.baseUrl}${UrlContainer.buyGoldHistory}?page=$page';
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }

  Future<ResponseModel> buyGold({required String amount, required String goldCategoryId, required String currency, required String gateway}) async {
    final url = UrlContainer.baseUrl + UrlContainer.buyGoldStore;
    final response = await apiClient.request(
        url,
        Method.postMethod,
        {
          "gateway": gateway == "-1" ? "main" : gateway,
          "amount": amount,
          "category_id": goldCategoryId,
          "currency": currency,
        },
        passHeader: true);
    return response;
  }
}
