import 'package:viser_gold/core/utils/method.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:get/get.dart';

class SellGoldRepo {
  ApiClient apiClient;
  SellGoldRepo() : apiClient = ApiClient(sharedPreferences: Get.find());

  Future<ResponseModel> getGoldFormData() async {
    final url = UrlContainer.baseUrl + UrlContainer.sellGoldForm;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }

  Future<ResponseModel> confirmSellGold({
    required String amount,
    required String assetId,
  }) async {
    final url = UrlContainer.baseUrl + UrlContainer.sellGoldStore;
    final body = {
      "amount": amount,
      "asset_id": assetId,
    };
    final response = await apiClient.request(url, Method.postMethod, body, passHeader: true);
    return response;
  }

  Future<ResponseModel> getSellGoldHistory({required int page}) async {
    final url = '${UrlContainer.baseUrl}${UrlContainer.sellGoldHistory}?page=$page';
    final response = await apiClient.request(url, Method.getMethod, {"page": page}, passHeader: true);
    return response;
  }
}
