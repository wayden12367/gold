import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:get/get.dart';
import 'package:viser_gold/core/utils/method.dart';

class GiftRepo extends GetxService {
  final ApiClient apiClient;
  GiftRepo() : apiClient = ApiClient(sharedPreferences: Get.find());

  Future<ResponseModel> getGiftGoldFormData() async {
    final url = UrlContainer.baseUrl + UrlContainer.giftGoldForm;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }

  Future<ResponseModel> checkUser(String emailOrUsername) async {
    final url = UrlContainer.baseUrl + UrlContainer.giftGoldCheckRecipient;
    final response = await apiClient.request(url, Method.postMethod, {"user": emailOrUsername}, passHeader: true);
    return response;
  }

  Future<ResponseModel> submitGiftGold({required String amount, required String goldCategoryId, required String user}) async {
    final url = UrlContainer.baseUrl + UrlContainer.sendGift;
    final response = await apiClient.request(url, Method.postMethod, {"amount": amount, "asset_id": goldCategoryId, "user": user}, passHeader: true);
    return response;
  }

  Future<ResponseModel> getGiftGoldHistory() async {
    final url = UrlContainer.baseUrl + UrlContainer.giftGoldHistory;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }
}
