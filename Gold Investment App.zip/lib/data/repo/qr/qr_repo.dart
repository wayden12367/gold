import 'package:viser_gold/core/utils/method.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';

class QrCodeRepo {
  ApiClient apiClient;
  QrCodeRepo({required this.apiClient});

  Future<ResponseModel> checkUser(String emailOrUsername) async {
    final url = UrlContainer.baseUrl + UrlContainer.giftGoldCheckRecipient;
    final response = await apiClient.request(url, Method.postMethod, {"user": emailOrUsername}, passHeader: true);
    return response;
  }
}
