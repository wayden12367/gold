import 'dart:convert';
import 'dart:io';
import 'package:viser_gold/core/utils/method.dart';
import 'package:viser_gold/core/utils/my_strings.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/authorization/authorization_response_model.dart';
import 'package:viser_gold/data/model/global/formdata/global_keyc_formData.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:http/http.dart' as http;

class WithdrawRepo {
  ApiClient apiClient;
  WithdrawRepo({required this.apiClient});

  Future<dynamic> getAllWithdrawMethod() async {
    String url = '${UrlContainer.baseUrl}${UrlContainer.withdrawMethodUrl}';
    ResponseModel responseModel = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return responseModel;
  }

  Future<dynamic> getWithdrawConfirmScreenData(String trxId) async {
    String url = '${UrlContainer.baseUrl}${UrlContainer.withdrawConfirmScreenUrl}$trxId';
    ResponseModel responseModel = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return responseModel;
  }

  Future<dynamic> addWithdrawRequest(int methodCode, double amount, String? authMode) async {
    String url = '${UrlContainer.baseUrl}${UrlContainer.addWithdrawRequestUrl}';
    Map<String, dynamic> params = {'method_code': methodCode.toString(), 'amount': amount.toString()};

    if (authMode != null && authMode.isNotEmpty && authMode.toLowerCase() != MyStrings.selectOne.toLowerCase()) {
      params['auth_mode'] = authMode.toLowerCase();
    }

    ResponseModel responseModel = await apiClient.request(url, Method.postMethod, params, passHeader: true);
    return responseModel;
  }

  List<Map<String, String>> fieldValueList = [];
  List<DynamicFileValueKeeperModel> filesDataList = [];

  Future<dynamic> confirmWithdrawRequest(String trx, List<GlobalFormModel> list, String twoFactorCode) async {
    fieldValueList.clear();
    await modelToMap(list);
    String url = '${UrlContainer.baseUrl}${UrlContainer.withdrawRequestConfirm}';
    var request = http.MultipartRequest('POST', Uri.parse(url));

    //Field value map
    Map<String, String> finalFieldValueMap = {};

    for (var element in fieldValueList) {
      finalFieldValueMap.addAll(element);
    }
    request.headers.addAll(<String, String>{'Authorization': 'Bearer ${apiClient.token}'});

    for (var file in filesDataList) {
      request.files.add(
        http.MultipartFile(file.key, file.value.readAsBytes().asStream(), file.value.lengthSync(), filename: file.value.path.split('/').last),
      );
    }
    request.fields.addAll({'trx': trx});
    if (twoFactorCode.isNotEmpty) {
      request.fields.addAll({'authenticator_code': twoFactorCode});
    }
    request.fields.addAll(finalFieldValueMap);
    http.StreamedResponse response = await request.send();

    String jsonResponse = await response.stream.bytesToString();
    AuthorizationResponseModel model = AuthorizationResponseModel.fromJson(jsonDecode(jsonResponse));

    return model;
  }

  Future<ResponseModel> getAllWithdrawHistory(int page, {String searchText = ""}) async {
    String url = "${UrlContainer.baseUrl}${UrlContainer.withdrawHistoryUrl}?page=$page&search=$searchText";
    ResponseModel responseModel = await apiClient.request(url, Method.getMethod, null);
    return responseModel;
  }

  Future<dynamic> modelToMap(List<GlobalFormModel> list) async {
    for (var e in list) {
      if (e.type == 'checkbox') {
        if (e.cbSelected != null && e.cbSelected!.isNotEmpty) {
          for (int i = 0; i < e.cbSelected!.length; i++) {
            fieldValueList.add({'${e.label}[$i]': e.cbSelected![i]});
          }
        }
      } else if (e.type == 'file') {
        if (e.imageFile != null) {
          filesDataList.add(DynamicFileValueKeeperModel(e.label!, e.imageFile!));
        }
      } else if (e.type == 'select') {
        if (e.selectedValue != null && e.selectedValue.toString() != MyStrings.selectOne) {
          fieldValueList.add({e.label ?? '': e.selectedValue});
        }
      } else {
        if (e.selectedValue != null && e.selectedValue.toString().isNotEmpty) {
          fieldValueList.add({e.label ?? '': e.selectedValue});
        }
      }
    }
  }
}

class DynamicFileValueKeeperModel {
  String key;
  File value;
  DynamicFileValueKeeperModel(this.key, this.value);
}
