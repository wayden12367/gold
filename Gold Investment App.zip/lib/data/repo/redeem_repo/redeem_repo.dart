import 'package:viser_gold/core/utils/method.dart';
import 'package:viser_gold/core/utils/url_container.dart';
import 'package:viser_gold/data/model/global/response_model/response_model.dart';
import 'package:viser_gold/data/services/api_service.dart';
import 'package:get/get.dart';

class RedeemRepo {
  RedeemRepo() : apiClient = Get.find();
  ApiClient apiClient;
  //

  Future<ResponseModel> getRedeemData() async {
    final url = UrlContainer.baseUrl + UrlContainer.redeemData;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }

  Future<ResponseModel> redeemGold(Map<String, dynamic> body) async {
    final url = UrlContainer.baseUrl + UrlContainer.redeem;
    final response = await apiClient.request(url, Method.postMethod, body, passHeader: true);
    return response;
  }

  Future<ResponseModel> getRedeemHistory(int page) async {
    final url = UrlContainer.baseUrl + UrlContainer.redeemHistory;
    final response = await apiClient.request(url, Method.getMethod, null, passHeader: true);
    return response;
  }
}
